/* IV Infotech lead page v2: the only script. (1) the big play button on the video, (2) the three-tap tabs, (3) the sticky WhatsApp bar on phones.
   The only network traffic is the first-party beacon (a GET for e.gif on our own server: no cookies, no third party). (build_site_pages.py prefixes the
   ids and the class names for the ivinfotech.com build, so look elements up through $() / data attributes / classList only, never by a class selector.) */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };

  // ---- first-party beacons: a tiny GET for e.gif?e=<event> lands in OUR OWN web log (no cookie, no third party). Never blocks the page.
  var SRC = document.currentScript && document.currentScript.src;
  var BEACON = SRC ? SRC.replace(/page\.js.*$/, "e.gif") : "";
  var sent = {};
  var beacon = function (name, once) {
    if (!BEACON || (once && sent[name])) { return; }
    sent[name] = true;
    try {
      var url = BEACON + "?e=" + encodeURIComponent(name) + "&_=" + Date.now();
      if (window.fetch) { fetch(url, { method: "GET", keepalive: true, mode: "no-cors", cache: "no-store" }); } else { new Image().src = url; }
    } catch (err) { /* a beacon must never break the page */ }
  };

  // ---- three taps: tabs switch the example chat (data attributes only, so the ivinfotech.com build does not need to rewrite anything)
  var tabs = document.querySelectorAll("[data-step]");
  var panels = document.querySelectorAll("[data-panel]");
  Array.prototype.forEach.call(tabs, function (tab) {
    tab.addEventListener("click", function () {
      var n = tab.getAttribute("data-step");
      Array.prototype.forEach.call(tabs, function (t) {
        var on = t.getAttribute("data-step") === n;
        t.classList.toggle("on", on);
        t.setAttribute("aria-selected", on ? "true" : "false");
      });
      Array.prototype.forEach.call(panels, function (p) { p.classList.toggle("on", p.getAttribute("data-panel") === n); });
      beacon("calc", true);                                           // reuses the existing "interacted" event name so the follow-up view counts it
    });
  });

  // ---- video: a big play button (the tiny native triangle is hard to find); the native controls appear after the first tap
  var wrap = $("vwrap"), vid = $("demo-video"), vbtn = $("vplay");
  if (wrap && vid && vbtn) {
    vid.removeAttribute("controls");
    wrap.classList.add("vjs");
    vbtn.addEventListener("click", function () {
      beacon("play_button", true);
      vid.setAttribute("controls", "");
      wrap.classList.add("playing");
      var p = vid.play();
      if (p && p.catch) { p.catch(function () {}); }
    });
  }
  if (vid) {
    vid.addEventListener("play", function () { beacon("play", true); });
    vid.addEventListener("timeupdate", function () {
      if (!vid.duration) { return; }
      var p = vid.currentTime / vid.duration;
      if (p >= 0.25) { beacon("p25", true); }
      if (p >= 0.5) { beacon("p50", true); }
      if (p >= 0.75) { beacon("p75", true); }
    });
    vid.addEventListener("ended", function () { beacon("end", true); });
  }
  [["cta-hero", "cta_hero"], ["cta-final", "cta_final"]].forEach(function (pair) {
    var el = $(pair[0]);
    if (el) { el.addEventListener("click", function () { beacon(pair[1], false); }); }
  });
  var stickyEl = $("sticky");
  var stickyLink = stickyEl && stickyEl.querySelector("a");
  if (stickyLink) { stickyLink.addEventListener("click", function () { beacon("cta_sticky", false); }); }
  Array.prototype.forEach.call(document.querySelectorAll("details"), function (d) { d.addEventListener("toggle", function () { if (d.open) { beacon("faq", true); } }); });

  // ---- phones: show the sticky WhatsApp button only when no main button and no video is on screen
  var sticky = $("sticky"), hero = $("cta-hero"), fin = $("cta-final");
  if (sticky && hero && "IntersectionObserver" in window) {
    var visible = { hero: true, fin: false, vid: false };
    var apply = function () { sticky.classList.toggle("show", !visible.hero && !visible.fin && !visible.vid); };
    new IntersectionObserver(function (es) { visible.hero = es[0].isIntersecting; apply(); }).observe(hero);
    if (fin) new IntersectionObserver(function (es) { visible.fin = es[0].isIntersecting || es[0].boundingClientRect.top < 0; apply(); }).observe(fin);
    if (wrap) new IntersectionObserver(function (es) { visible.vid = es[0].isIntersecting; apply(); }, { threshold: 0.2 }).observe(wrap);
  }
})();
