# -*- coding: utf-8 -*-
"""wa.py - WhatsApp BSP API (Meta-Cloud-API-compatible, e.g. waba.fortius.in.net). Everything that sends/creates is DRY-RUN unless --live.

Subcommands
  templates [--name N]                  list templates + status (read-only)
  status --name N                       status of one template (read-only; BSP ignores ?name= so we filter client-side)
  create --spec spec.json [--live --approval CODE]      validate (+ upload video/image header, create) a MARKETING template; never deletes anything
  send-template --to NUM --template N [--lang en] [--body-param X ...] [--header-video-url URL | --header-image-url URL]
                [--url-suffix S] --lead NAME [--live --approval CODE]
  reply --to NUM --text T --inbound-at ISO --lead NAME [--live --approval CODE]    free-form text, only inside the 24h window

Safety in code: valid Indian mobile, not suppressed (local list AND the CRM's do-not-contact list on every live send), template
must be APPROVED, daily caps, IST send window, duplicate guard, no secrets/ids printed, each attempt logged.
(send-template, even without --live, makes ONE read-only call to the WhatsApp provider to look up the template's status;
it never contacts the CRM and sends nothing. Use --skip-remote-check, with AGENT_TEST_MODE=1, only in tests.) BSP quirks learned in the pilot: URL cannot be a header handle
(upload bytes via GET /app -> POST /{app}/uploads -> POST /{upload_id} -> handle 'h'); never delete by name.

Exit codes: 0 ok / dry-run, 1 failed (the provider clearly said no), 2 blocked before anything was sent, 3 UNKNOWN OUTCOME (the
provider did not answer in time, so the message MAY have been delivered: it is counted as sent, the duplicate guard blocks a repeat,
and nobody should retry before checking delivery - see "unknown outcome" in common.py).

Every LIVE action needs --approval CODE: a one-time code the OWNER granted on WhatsApp for exactly this action (see propose.py).
The tool asks the CRM (and fails closed if it cannot): not paused, code approved, same content (hash), not expired - then it
spends the code BEFORE sending. Dry-run never talks to the CRM. Exception: when config.json autonomy_stage >= 2, `reply`
to a lead who wrote first (verified in the CRM, never first-touch) does not need a code, but still obeys the pause flag.

spec.json example:
{"name":"iv_demo_v1","language":"en","category":"MARKETING",
 "header":{"format":"VIDEO","file":"path/to/video.mp4"},          # or {"format":"IMAGE","file":...} or omit
 "body":"Hi {{1}}, ... about {{2}} ... Tap YES.", "body_examples":["Acme team","Acme Heights"],
 "footer":"Reply STOP to opt out",
 "buttons":[{"type":"URL","text":"View your sample","url":"https://www.ivinfotech.com/campaign/{{1}}","example":"https://www.ivinfotech.com/campaign/abc123"},
            {"type":"QUICK_REPLY","text":"Yes, send the sample"},{"type":"QUICK_REPLY","text":"No, thanks"}]}
"""
import argparse
import datetime as dt
import json
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402


# ---------------- validation (pure, unit-tested) ----------------
def validate_spec(spec):
    errs = []
    name = spec.get("name", "")
    if not re.fullmatch(r"[a-z0-9_]{5,60}", name or ""):
        errs.append("name must be 5-60 chars of a-z 0-9 _")
    if spec.get("category", "MARKETING") != "MARKETING":
        errs.append("category must be MARKETING (never disguise a cold intro as UTILITY)")
    if not re.fullmatch(r"[a-z]{2}(_[A-Z]{2})?", spec.get("language", "en")):
        errs.append("language code looks wrong (e.g. en, hi, gu)")
    body = spec.get("body", "")
    if not body or len(body) > 1024:
        errs.append("body is required and must be <= 1024 chars")
    vars_ = [int(x) for x in re.findall(r"\{\{(\d+)\}\}", body)]
    if vars_:
        if sorted(set(vars_)) != list(range(1, max(vars_) + 1)):
            errs.append("body variables must be {{1}}, {{2}}, ... without gaps")
        if body.strip().startswith("{{") or body.strip().endswith("}}"):
            errs.append("body must not start or end with a variable")
        ex = spec.get("body_examples") or []
        if len(ex) != len(set(vars_)):
            errs.append(f"body_examples must have {len(set(vars_))} values (one per variable)")
    if len(spec.get("footer", "")) > 60:
        errs.append("footer must be <= 60 chars")
    h = spec.get("header")
    if h:
        if h.get("format") not in ("VIDEO", "IMAGE"):
            errs.append("header.format must be VIDEO or IMAGE")
        if not h.get("file"):
            errs.append("header.file is required")
    btns = spec.get("buttons", [])
    if len(btns) > 10:
        errs.append("max 10 buttons")
    qr = [b for b in btns if b.get("type") == "QUICK_REPLY"]
    urls = [b for b in btns if b.get("type") == "URL"]
    if len(urls) > 2:
        errs.append("max 2 URL buttons")
    for b in btns:
        if b.get("type") not in ("URL", "QUICK_REPLY", "PHONE_NUMBER"):
            errs.append(f"unsupported button type {b.get('type')}")
        if len(b.get("text", "")) > 25 or not b.get("text"):
            errs.append("button text required and <= 25 chars")
        if b.get("type") == "URL":
            if not str(b.get("url", "")).startswith("https://"):
                errs.append("URL button must be https")
            if "{{1}}" in b.get("url", "") and not b.get("example"):
                errs.append("URL button with {{1}} needs an example")
    if not any("stop" in b.get("text", "").lower() for b in qr) and "stop" not in spec.get("footer", "").lower():
        errs.append("give the lead an opt-out: a 'Stop' quick-reply button or 'STOP' in the footer")
    return errs


def build_components(spec, handle=None):
    comps = []
    h = spec.get("header")
    if h:
        comps.append({"type": "HEADER", "format": h["format"], "example": {"header_handle": [handle or "HANDLE_PLACEHOLDER"]}})
    b = {"type": "BODY", "text": spec["body"]}
    if spec.get("body_examples"):
        b["example"] = {"body_text": [spec["body_examples"]]}
    comps.append(b)
    if spec.get("footer"):
        comps.append({"type": "FOOTER", "text": spec["footer"]})
    if spec.get("buttons"):
        comps.append({"type": "BUTTONS", "buttons": [
            ({k: v for k, v in x.items() if k in ("type", "text", "url", "phone_number")} | ({"example": [x["example"]]} if x.get("example") else {}))
            for x in spec["buttons"]]})
    return comps


def build_send_components(body_params, header_video_url=None, header_image_url=None, url_suffix=None):
    comps = []
    if header_video_url:
        comps.append({"type": "header", "parameters": [{"type": "video", "video": {"link": header_video_url}}]})
    elif header_image_url:
        comps.append({"type": "header", "parameters": [{"type": "image", "image": {"link": header_image_url}}]})
    if body_params:
        comps.append({"type": "body", "parameters": [{"type": "text", "text": str(p)} for p in body_params]})
    if url_suffix:
        comps.append({"type": "button", "sub_type": "url", "index": "0", "parameters": [{"type": "text", "text": url_suffix}]})
    return comps


# ---------------- BSP client ----------------
NoRedirect = C.NoRedirect  # kept under the old name; the class itself now lives in common.py


class Bsp:
    def __init__(self):
        env = C.load_env()
        self.token = env.get("WHATSAPP_TOKEN", "")
        self.waba = env.get("WHATSAPP_WABA_ID", "")
        self.phone = env.get("WHATSAPP_PHONE_ID", "")
        self.base = (env.get("WHATSAPP_API_BASE_URL") or "https://waba.fortius.in.net").rstrip("/")
        self.ver = env.get("WHATSAPP_API_VERSION") or "v21.0"
        # https only; plain http is accepted solely for localhost (the offline tests run a fake server there)
        if not C.safe_base_url(self.base):
            raise SystemExit("BSP base URL must be https")
        self.scrub = C.Scrubber([self.token, self.waba, self.phone])
        self.opener = C.opener_for(self.base)
        self.timeout = C.http_timeout(C.DEFAULT_WA_TIMEOUT)  # AGENT_HTTP_TIMEOUT overrides (tests); default 90 s
        self.list_ok = True  # set by all_templates(): False when a page of the template list could not be read

    def need(self, *names):
        missing = [n for n in names if not getattr(self, n)]
        if missing:
            raise SystemExit("missing credentials in env: " + ", ".join(missing))

    def call(self, method, url, body=None, data=None, headers=None):
        """One request to the provider. Returns (http_code, dict). code 0 = no HTTP answer at all.
        The dict gets "_unknown": True when the request MAY already have been processed although we have no complete answer
        (read timeout, connection reset, closed connection, incomplete read, a gateway timeout ...). Errors that clearly happened
        BEFORE the request could be processed (DNS failure, connection refused, TLS certificate error, network unreachable)
        are NOT marked, so those are safe to retry. See "unknown outcome" in common.py."""
        h = {"Authorization": "Bearer " + self.token, "User-Agent": "ivinfotech-agent/1"}
        if headers:
            h.update(headers)
        if body is not None:
            data = json.dumps(body).encode()
            h["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, method=method, headers=h)
        try:
            with self.opener.open(req, timeout=self.timeout) as r:
                raw, code = r.read().decode("utf-8", "replace"), r.status
        except urllib.error.HTTPError as e:
            code = e.code
            try:
                raw = e.read().decode("utf-8", "replace")
            except Exception:
                raw = ""  # the status line arrived but the body did not: the status alone decides (see unknown_http_status)
        except Exception as e:
            out = {"_error": self.scrub(str(e) or type(e).__name__, 200)}
            if C.is_unknown_outcome(e):
                out["_unknown"] = True
            return 0, out
        try:
            res = json.loads(raw)
        except Exception:
            res = {"_raw": self.scrub(raw, 300)}
        if C.unknown_http_status(code):
            res = res if isinstance(res, dict) else {"_data": self.scrub(res, 300)}
            res["_unknown"] = True
        return code, res

    def all_templates(self):
        self.need("token", "waba")
        url, rows, pages = f"{self.base}/{self.ver}/{self.waba}/message_templates?limit=100", [], 0
        self.list_ok = True  # becomes False if any page could not be read: then "no such template" proves nothing
        while url and pages < 8:
            code, d = self.call("GET", url)
            if not (200 <= code < 300 and isinstance(d, dict) and isinstance(d.get("data"), list)):
                self.list_ok = False
            if not isinstance(d, dict):
                break
            if isinstance(d.get("data"), list):
                rows += [r for r in d["data"] if isinstance(r, dict)]
            nxt = (d.get("paging") or {}).get("next") if isinstance(d.get("paging"), dict) else None
            url = nxt if (isinstance(nxt, str) and nxt.startswith(self.base)) else None
            pages += 1
        return rows

    def template(self, name):
        for r in self.all_templates():
            if str(r.get("name")) == name:
                return r
        return None


def row_summary(r, scrub):
    hdr = next((c for c in r.get("components", []) if isinstance(c, dict) and c.get("type") == "HEADER"), {})
    q = r.get("quality_score")
    return (f"{scrub(str(r.get('name')), 60)} | {scrub(str(r.get('status')), 20)} | {scrub(str(r.get('category')), 20)} | "
            f"lang {r.get('language')} | header {hdr.get('format')} | quality {(q or {}).get('score') if isinstance(q, dict) else None}"
            + (f" | rejected: {scrub(str(r.get('rejected_reason')), 100)}" if r.get("rejected_reason") not in (None, "NONE") else ""))


# ---------------- commands ----------------
LIST_UNREADABLE = ("COULD NOT READ the template list from the provider (error or timeout). A template missing from this output is "
                   "NOT proof that it does not exist - try again before drawing a conclusion.")


def cmd_templates(a):
    b = Bsp()
    rows = b.all_templates()
    if a.name:
        rows = [r for r in rows if str(r.get("name")) == a.name]
    print(f"{len(rows)} template(s)")
    for r in rows:
        print(" ", row_summary(r, b.scrub))
    if not b.list_ok:
        # After an UNKNOWN create this is the command people use to check, so a failed lookup must never look like "not there".
        print(LIST_UNREADABLE)
        sys.exit(1)


def cmd_status(a):
    b = Bsp()
    r = b.template(a.name)
    if r:
        print(row_summary(r, b.scrub))
    elif not b.list_ok:
        print(LIST_UNREADABLE)
        sys.exit(1)
    else:
        print(f"template '{a.name}' not found")


def load_create_spec(spec_path):
    """Read and validate a template spec file. Returns (spec, errors, header_file_path or None).
    Shared by `create` and propose.py so both look at the same spec and compute the same approval hash."""
    spec = json.loads(Path(spec_path).read_text(encoding="utf-8"))
    spec.setdefault("category", "MARKETING")
    spec.setdefault("language", "en")
    errs = validate_spec(spec)
    header_path = None
    h = spec.get("header")
    if h and h.get("file"):
        p = Path(h["file"]) if Path(h["file"]).is_absolute() else Path(spec_path).resolve().parent / h["file"]
        if not p.exists():
            errs.append(f"header file not found: {p}")
        else:
            header_path = p
            if h["format"] == "VIDEO" and p.stat().st_size >= 16 * 1024 * 1024:
                errs.append("video must be < 16 MB")
        spec["_header_path"] = str(p)
    return spec, errs, header_path


def create_unknown_problems(name):
    """If an earlier `create` of this template name ended with an UNKNOWN outcome (the provider never answered), creating it
    again is refused until a human has looked. Shared by `create` and propose.py (so the owner is not even asked to approve it)."""
    earlier = C.recent_send("whatsapp_template_create", C.send_key("wa_create", name))
    if earlier and earlier.get("status") == "unknown":
        return [f"an earlier attempt to create template '{name}' (at {earlier.get('ts', '?')}) has an UNKNOWN outcome: it may already exist - "
                f"DO NOT re-create. Check:  python agent/tools/wa.py templates --name {name}  "
                "(if it is really missing, use a new template name and ask the owner for a new approval)"]
    return []


def cmd_create(a):
    spec, errs, header_path = load_create_spec(a.spec)
    print(f"== wa create [{C.banner(a.live)}]  name={spec.get('name')}")
    h = spec.get("header")
    if errs:
        print("BLOCKED (spec problems):")
        for e in errs:
            print("  -", e)
        C.log_event("wa_create_blocked", name=spec.get("name"), reasons=errs)
        sys.exit(2)
    print("spec valid. components preview:")
    print(json.dumps(build_components(spec), ensure_ascii=False, indent=1)[:1800])
    # The header file is read ONCE: these exact bytes are hashed (what the owner approves) and later uploaded (what is sent),
    # so the file cannot be swapped in between.
    header_blob = Path(header_path).read_bytes() if header_path else None
    ahash = C.wa_create_action_hash(spec, header_path, header_bytes=header_blob)
    if a.live:
        problems = C.live_gate_check(a.approval, ahash)
        if C.paused():
            problems.append("agent is PAUSED (agent/state/PAUSED exists) - the owner must resume it")
        problems += create_unknown_problems(spec.get("name"))
        if problems:
            print("BLOCKED:")
            for p in problems:
                print("  -", p)
            C.log_event("wa_create_blocked", name=spec.get("name"), reasons=problems)
            sys.exit(2)
    if not a.live:
        C.log_event("wa_create_dry_run", name=spec["name"])
        print("\n(dry-run: nothing uploaded or created)")
        return
    b = Bsp()
    b.need("token", "waba")
    existing = b.all_templates()
    if not b.list_ok:
        # A failed lookup used to look like "no such template", so creation went ahead blind. Now it stops BEFORE the code is spent.
        print("ABORT: could not read the template list from the provider, so I cannot tell whether this name already exists. Nothing was created and the approval code is still unused; try again later.")
        sys.exit(2)
    if any(str(r.get("name")) == spec["name"] for r in existing):
        print("ABORT: a template with this name already exists (never overwriting)")
        sys.exit(2)
    # Spend the one-time code BEFORE the first change at the BSP (the upload). No code = nothing is created.
    ok, why = C.consume_approval(a.approval, ahash)
    if not ok:
        print("BLOCKED:\n  -", why)
        C.log_event("wa_create_blocked", name=spec.get("name"), reasons=[why])
        sys.exit(2)
    print(f"   approval: {C.clean_approval_code(a.approval)} verified and used up (if a later step fails, ask the owner again)")
    handle = None
    if h:
        blob = header_blob
        ftype = "video/mp4" if h["format"] == "VIDEO" else ("image/png" if str(spec["_header_path"]).lower().endswith("png") else "image/jpeg")
        _, app = b.call("GET", f"{b.base}/{b.ver}/app?fields=id")
        app_id = app.get("id") if isinstance(app, dict) else None
        if not (app_id and re.fullmatch(r"[A-Za-z0-9_]+", str(app_id))):
            sys.exit("could not read app id from BSP")
        b.scrub.add(app_id)
        q = urllib.parse.urlencode({"file_length": len(blob), "file_type": ftype, "file_name": Path(spec["_header_path"]).name})
        _, up = b.call("POST", f"{b.base}/{b.ver}/{app_id}/uploads?{q}")
        sid = up.get("id") if isinstance(up, dict) else None
        if not (sid and str(sid).startswith("upload:")):
            sys.exit("upload session failed: " + b.scrub(up, 200))
        b.scrub.add(sid)
        _, fin = b.call("POST", f"{b.base}/{b.ver}/{sid}", data=blob, headers={"file_offset": "0", "Content-Type": "application/octet-stream"})
        handle = fin.get("h") if isinstance(fin, dict) else None
        if not handle:
            sys.exit("no upload handle: " + b.scrub(fin, 200))
        b.scrub.add(handle)
        print(f"uploaded {len(blob)//1024} KB -> handle received")
    body = {"name": spec["name"], "language": spec["language"], "category": "MARKETING", "components": build_components(spec, handle)}
    code, res = b.call("POST", f"{b.base}/{b.ver}/{b.waba}/message_templates", body=body)
    ok = 200 <= code < 300 and isinstance(res, dict) and res.get("id")
    if C.result_is_unknown(code, res, ok):
        # The provider may already have created the template although we never got its answer. Remember that (the check in the
        # live gate above then refuses a second create of this name) and tell the human to look, not to retry.
        C.record_send("whatsapp_template_create", C.send_key("wa_create", spec["name"]), status="unknown", name=spec["name"])
        C.log_event("wa_template_create_unknown", name=spec["name"], http=code, detail=b.scrub(res, 300), approval=C.clean_approval_code(a.approval))
        C.crm_log_activity(spec["name"], "whatsapp", "template_create_unknown",
                           f"UNKNOWN outcome: WhatsApp template '{spec['name']}' may have been created (the provider did not answer)", direction="internal")
        print(C.unknown_outcome_text(C.unknown_cause(code), "the template may have been created",
                                     f"Do NOT re-create it. Check first:  python agent/tools/wa.py templates --name {spec['name']}"))
        print("   detail:", b.scrub(res, 300))
        print("NOTE: the approval code was already used up. If the template really is missing, change the template name and ask the owner again (propose.py).")
        sys.exit(3)
    C.log_event("wa_template_created" if ok else "wa_template_create_failed", name=spec["name"], http=code, detail=b.scrub(res, 300),
                approval=C.clean_approval_code(a.approval))
    if ok:
        C.crm_log_activity(spec["name"], "whatsapp", "template_created", f"WhatsApp template '{spec['name']}' submitted for Meta approval", direction="internal")
    print("CREATED (submitted for Meta approval):" if ok else f"FAILED http {code}:", b.scrub(res, 400))
    if not ok:
        print("NOTE: the approval code was already used up; ask the owner again (propose.py) before retrying.")
    sys.exit(0 if ok else 1)


def _guard_send(to_raw, lead, key_parts, channel, live, ignore_window):
    problems = []
    to = C.norm_phone(to_raw)
    if not to:
        problems.append("recipient is not a valid Indian mobile number")
    if to and C.is_suppressed(to):
        problems.append("recipient is on the suppression list")
    if live and to:
        # The CRM records every STOP it receives, even if the operator never ran suppress.py. Fails closed.
        problems += C.crm_suppression_problems(to)
    ok, cap_msg = C.check_cap(channel)
    if not ok:
        problems.append(cap_msg)
    key = C.send_key(*key_parts, to)
    earlier = C.recent_send(channel, key) if to else None
    if earlier:
        problems.append(C.duplicate_problem(earlier, f"same message already sent in the last {C.config()['duplicate_guard_days']} days"))
    if live and not ignore_window and not C.in_send_window():
        problems.append(f"outside the send window {C.config()['send_window_ist']} IST")
    if live and C.paused():
        problems.append("agent is PAUSED (agent/state/PAUSED exists) - the owner must resume it")
    return to, key, cap_msg, problems


def cmd_send_template(a):
    to, key, cap_msg, problems = _guard_send(a.to, a.lead, ("wa_tpl", a.template), "whatsapp_template", a.live, a.ignore_window)
    print(f"== wa send-template [{C.banner(a.live)}]  template={a.template}  to={C.mask_phone(to) if to else '?'}  lead={a.lead or '-'}")
    print("   caps:", cap_msg)
    b = Bsp()
    if not a.skip_remote_check:
        r = b.template(a.template)
        if not r:
            problems.append("template not found" if b.list_ok else
                            "could not read the template list from the provider, so the template's status is unknown (nothing was sent)")
        elif str(r.get("status")) != "APPROVED":
            problems.append(f"template status is {r.get('status')}, not APPROVED")
    comps = build_send_components(a.body_param or [], a.header_video_url, a.header_image_url, a.url_suffix)
    payload = {"messaging_product": "whatsapp", "to": to, "type": "template",
               "template": {"name": a.template, "language": {"code": a.lang}, "components": comps}}
    # Owner-approval gate (live only): the hash covers recipient + template + language + every parameter and link.
    ahash = C.wa_template_action_hash(to, a.template, a.lang, a.body_param, a.header_video_url, a.header_image_url, a.url_suffix) if to else None
    if a.live and ahash:
        problems += C.live_gate_check(a.approval, ahash)
    if problems:
        print("BLOCKED:")
        for p in problems:
            print("  -", p)
        C.log_event("wa_send_blocked", lead=a.lead, to=C.mask_phone(to), template=a.template, reasons=problems)
        sys.exit(2)
    print("payload (components):", json.dumps(comps, ensure_ascii=False)[:600])
    if not a.live:
        C.log_event("wa_send_dry_run", lead=a.lead, to=C.mask_phone(to), template=a.template)
        print("\n(dry-run: nothing sent)")
        return
    b.need("token", "phone")
    # Spend the one-time code BEFORE sending. If this fails we do not send.
    ok, why = C.consume_approval(a.approval, ahash)
    if not ok:
        print("BLOCKED:\n  -", why)
        C.log_event("wa_send_blocked", lead=a.lead, to=C.mask_phone(to), template=a.template, reasons=[why])
        sys.exit(2)
    code_used = C.clean_approval_code(a.approval)
    print(f"   approval: {code_used} verified and used up")
    code, res = b.call("POST", f"{b.base}/{b.ver}/{b.phone}/messages", body=payload)
    wamid = ((res.get("messages") or [{}])[0].get("id")) if isinstance(res, dict) and isinstance(res.get("messages"), list) else None
    if C.result_is_unknown(code, res, 200 <= code < 300 and wamid):
        # No usable answer, but the provider may have delivered it. Count it as SENT (daily caps, duplicate guard) - the safe side.
        C.bump("whatsapp_template")
        C.record_send("whatsapp_template", key, status="unknown", lead=a.lead, to=C.mask_phone(to), template=a.template)
        C.log_event("wa_template_unknown", lead=a.lead, to=C.mask_phone(to), template=a.template, http=code, detail=b.scrub(res, 300), approval=code_used)
        C.crm_log_activity(a.lead or C.mask_phone(to), "whatsapp", "template_unknown",
                           f"UNKNOWN outcome: WhatsApp template '{a.template}' to {C.mask_phone(to)} may have been delivered (the provider did not answer)")
        print(C.unknown_outcome_text(C.unknown_cause(code)))
        print("   detail:", b.scrub(res, 300))
        print("   counted as sent today, and the same template to this number is now blocked by the duplicate guard.")
        print("NOTE: the approval code was already used up.")
        sys.exit(3)
    if 200 <= code < 300 and wamid:
        C.bump("whatsapp_template")
        C.record_send("whatsapp_template", key, lead=a.lead, to=C.mask_phone(to), template=a.template, wamid=wamid)
        C.log_event("wa_template_sent", lead=a.lead, to=C.mask_phone(to), template=a.template, wamid=wamid, approval=code_used)
        C.crm_log_activity(a.lead or C.mask_phone(to), "whatsapp", "template_sent", f"WhatsApp template '{a.template}' sent to {C.mask_phone(to)}")
        print("SENT  wamid recorded")
    else:
        C.log_event("wa_send_failed", lead=a.lead, to=C.mask_phone(to), template=a.template, http=code, detail=b.scrub(res, 300), approval=code_used)
        print("FAILED http", code, b.scrub(res, 300))
        print("NOTE: the approval code was already used up; ask the owner again (propose.py) before retrying.")
        sys.exit(1)


def reply_window_problems(inbound_at):
    """Free-form replies are only allowed inside the 24h window after the lead's last message. Shared with propose.py."""
    try:
        t = dt.datetime.fromisoformat(inbound_at)
        if t.tzinfo is None:
            t = t.replace(tzinfo=C.IST)
        hrs = (C.now_ist() - t).total_seconds() / 3600
        out = []
        if hrs > C.config()["template_window_hours"] - 0.25:
            out.append(f"last inbound message was {hrs:.1f}h ago: outside the 24h window, free-form reply not allowed (use an approved template)")
        if hrs < -0.1:
            out.append("inbound time is in the future")
        return out
    except Exception:
        return ["--inbound-at must be an ISO timestamp of the lead's last message"]


def reply_limit_problems(to, text):
    """Daily cap for replies, duplicate guard and a per-lead limit. Free-form replies used to have none of these, so a loop
    could message a lead (or every lead who ever wrote) without limit. Returns (key, rcpt, reasons)."""
    problems = []
    ok, cap_msg = C.check_reply_cap()
    if not ok:
        problems.append(cap_msg)
    key = C.send_key("wa_reply", to, C.send_key(text))
    rcpt = C.send_key("rcpt", to)
    earlier = C.recent_send("whatsapp_reply", key, days=1)
    if earlier:
        problems.append(C.duplicate_problem(earlier, "this exact reply was already sent to this number in the last 24 hours", what="reply"))
    per_lead = int(C.config().get("reply_per_lead_per_day", 6))
    if C.count_sends("whatsapp_reply", "rcpt", rcpt, hours=24) >= per_lead:
        problems.append(f"already {per_lead} replies to this number in the last 24 hours - hand the lead to a human instead")
    return key, rcpt, problems


def cmd_reply(a):
    to = C.norm_phone(a.to)
    problems = []
    key = rcpt = None
    if not to:
        problems.append("recipient is not a valid Indian mobile number")
    if to and C.is_suppressed(to):
        problems.append("recipient is on the suppression list")
    if to and a.live:
        # At EVERY autonomy stage, including 2 where no code is needed: a lead who said STOP is never answered. Fails closed.
        problems += C.crm_suppression_problems(to)
    problems += reply_window_problems(a.inbound_at)
    if not a.text.strip() or len(a.text) > 1500:
        problems.append("text required, <= 1500 chars")
    if to:
        key, rcpt, limit_problems = reply_limit_problems(to, a.text)
        problems += limit_problems
    if a.live and C.paused():
        problems.append("agent is PAUSED (agent/state/PAUSED exists) - the owner must resume it")
    # Owner-approval gate (live only). Stage 1 (default): a reply needs a code like any other send.
    # Stage 2+: no code needed, but only for a lead who really wrote first - checked in the CRM, because the
    # --inbound-at the operator passes is just a claim. This is what keeps "reply without asking" from becoming first-touch.
    needs_code = C.autonomy_stage() < 2
    ahash = C.wa_reply_action_hash(to, a.text) if to else None
    if a.live and ahash:
        problems += C.live_gate_check(a.approval, ahash, approval_required=needs_code)
        if not needs_code and not a.approval:
            problems += _lead_wrote_first_problems(to)
    print(f"== wa reply [{C.banner(a.live)}]  to={C.mask_phone(to) if to else '?'}  lead={a.lead or '-'}")
    if problems:
        print("BLOCKED:")
        for p in problems:
            print("  -", p)
        C.log_event("wa_reply_blocked", lead=a.lead, to=C.mask_phone(to), reasons=problems)
        sys.exit(2)
    print("text:", a.text[:500])
    if not a.live:
        C.log_event("wa_reply_dry_run", lead=a.lead, to=C.mask_phone(to))
        print("\n(dry-run: nothing sent)")
        return
    b = Bsp()
    b.need("token", "phone")
    code_used = None
    if a.approval:  # a code was given (always at stage 1): spend it BEFORE sending
        ok, why = C.consume_approval(a.approval, ahash)
        if not ok:
            print("BLOCKED:\n  -", why)
            C.log_event("wa_reply_blocked", lead=a.lead, to=C.mask_phone(to), reasons=[why])
            sys.exit(2)
        code_used = C.clean_approval_code(a.approval)
        print(f"   approval: {code_used} verified and used up")
    code, res = b.call("POST", f"{b.base}/{b.ver}/{b.phone}/messages", body={
        "messaging_product": "whatsapp", "to": to, "type": "text", "text": {"preview_url": True, "body": a.text}})
    wamid = ((res.get("messages") or [{}])[0].get("id")) if isinstance(res, dict) and isinstance(res.get("messages"), list) else None
    if C.result_is_unknown(code, res, 200 <= code < 300 and wamid):
        # No usable answer, but the provider may have delivered it: count it (reply cap + per-lead limit) and block the same text.
        C.bump("whatsapp_reply", counts_toward_total=False)
        C.record_send("whatsapp_reply", key, status="unknown", lead=a.lead, to=C.mask_phone(to), rcpt=rcpt)
        C.log_event("wa_reply_unknown", lead=a.lead, to=C.mask_phone(to), http=code, detail=b.scrub(res, 300), approval=code_used)
        C.crm_log_activity(a.lead or C.mask_phone(to), "whatsapp", "reply_unknown",
                           f"UNKNOWN outcome: WhatsApp reply to {C.mask_phone(to)} may have been delivered (the provider did not answer)")
        print(C.unknown_outcome_text(C.unknown_cause(code)))
        print("   detail:", b.scrub(res, 300))
        print("   counted as sent today, and the same reply to this number is now blocked by the duplicate guard.")
        if code_used:
            print("NOTE: the approval code was already used up.")
        sys.exit(3)
    if 200 <= code < 300 and wamid:
        C.bump("whatsapp_reply", counts_toward_total=False)
        C.record_send("whatsapp_reply", key, lead=a.lead, to=C.mask_phone(to), rcpt=rcpt, wamid=wamid)
        C.log_event("wa_reply_sent", lead=a.lead, to=C.mask_phone(to), wamid=wamid, approval=code_used)
        C.crm_log_activity(a.lead or C.mask_phone(to), "whatsapp", "reply_sent", f"WhatsApp reply sent to {C.mask_phone(to)}")
        print("SENT  wamid recorded")
    else:
        C.log_event("wa_reply_failed", lead=a.lead, to=C.mask_phone(to), http=code, detail=b.scrub(res, 300), approval=code_used)
        print("FAILED http", code, b.scrub(res, 300))
        if code_used:
            print("NOTE: the approval code was already used up; ask the owner again (propose.py) before retrying.")
        sys.exit(1)


def _lead_wrote_first_problems(to):
    """Stage 2 only: the CRM must have an inbound message from this number inside the 24h window."""
    try:
        last = C.last_inbound_from(to)
    except C.CrmError as e:
        return ["cannot confirm in the CRM that this lead wrote first, so blocking (fail closed): " + str(e)]
    if last is None:
        return ["the CRM has no real inbound message from this number (reactions, auto-replies and STOP do not count) - a reply "
                "without approval is only for leads who wrote first"]
    hrs = (C.now_ist() - last).total_seconds() / 3600
    if hrs > C.config()["template_window_hours"] - 0.25:
        return [f"the lead's last message in the CRM is {hrs:.1f}h old: outside the 24h window"]
    return []


def main():
    C.start()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("templates"); p.add_argument("--name"); p.set_defaults(fn=cmd_templates)
    p = sub.add_parser("status"); p.add_argument("--name", required=True); p.set_defaults(fn=cmd_status)
    p = sub.add_parser("create"); p.add_argument("--spec", required=True); p.add_argument("--live", action="store_true")
    p.add_argument("--approval", default="", help="one-time code the owner approved on WhatsApp for exactly this template (see propose.py)")
    p.set_defaults(fn=cmd_create)
    p = sub.add_parser("send-template")
    p.add_argument("--to", required=True); p.add_argument("--template", required=True); p.add_argument("--lang", default="en")
    p.add_argument("--body-param", action="append"); p.add_argument("--header-video-url"); p.add_argument("--header-image-url")
    p.add_argument("--url-suffix"); p.add_argument("--lead", default=""); p.add_argument("--live", action="store_true")
    p.add_argument("--approval", default="", help="one-time code the owner approved on WhatsApp for exactly this message (see propose.py)")
    p.add_argument("--ignore-window", action="store_true", help="OWNER ONLY (works only with AGENT_OWNER_OVERRIDE=1 in the environment)")
    p.add_argument("--skip-remote-check", action="store_true", help="tests only (works only with AGENT_TEST_MODE=1): do not query template status")
    p.set_defaults(fn=cmd_send_template)
    p = sub.add_parser("reply")
    p.add_argument("--to", required=True); p.add_argument("--text", required=True); p.add_argument("--inbound-at", required=True)
    p.add_argument("--lead", default=""); p.add_argument("--live", action="store_true")
    p.add_argument("--approval", default="", help="one-time code the owner approved on WhatsApp (not needed at autonomy stage 2 for a lead who wrote first)")
    p.set_defaults(fn=cmd_reply)
    a = ap.parse_args()
    if getattr(a, "ignore_window", False):
        C.require_override("--ignore-window", "AGENT_OWNER_OVERRIDE")
    if getattr(a, "skip_remote_check", False):
        C.require_override("--skip-remote-check", "AGENT_TEST_MODE")
    a.fn(a)


if __name__ == "__main__":
    main()
