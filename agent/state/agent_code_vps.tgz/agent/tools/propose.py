# -*- coding: utf-8 -*-
"""propose.py - ask the OWNER to approve one exact live action, over WhatsApp.

What it does:
  1. builds the same "action hash" the send tool will check (recipient + subject/template + body + links),
  2. asks the CRM for an approval request (POST /approvals) - the CRM invents the one-time code,
  3. tells the owner on WhatsApp (via notify_owner.py; email if the 24h window is closed) with the COMPLETE message and the code:
     "Reply OK <CODE> to approve, NO <CODE> to skip",
  4. prints the code for the session log.
The owner's reply is read by the CRM webhook, never by this tool. This tool cannot approve anything: it can only ask.
Then run the SAME send command again with  --live --approval <CODE>  (send_email.py / wa.py).

WHAT THE OWNER SEES (the point of an approval): everything the code covers, nothing cut. The full recipient address / number, the
subject, the whole text, every link on its own line, and for a WhatsApp template the real text Meta will deliver (fetched from the
provider, with the parameters filled in). The words "typed by the agent" mark the two things nobody verifies (the lead label and
the reason). If the complete message does not fit in one owner message (3500 characters), the proposal is REFUSED - shorten the
draft; an approval for text the owner could not read in full is worthless.

Use the same arguments you will give the send tool - any change (even one word of the body) needs a new proposal.
It refuses to ask for things the send tool would block anyway (bad or suppressed recipient - including the CRM's do-not-contact
list, duplicate, cap reached, paused), when the CRM cannot route the owner's reply (owner_routing is not "enabled"), and when
the owner already answered NO to the very same action. Asking twice for the same action returns the existing code instead of
messaging the owner again.

Usage:
  propose.py email       --to X --subject S --body-file F [--reply-to R] --lead L [--reason WHY]
  propose.py wa-template --to NUM --template N [--lang en] [--body-param X ...] [--header-video-url U | --header-image-url U] [--url-suffix S] --lead L
  propose.py wa-reply    --to NUM --text T --inbound-at ISO --lead L
  propose.py wa-create   --spec spec.json
  all:  [--ttl-hours 1..48]  [--dry-run  (show the hash + the owner message; no CRM, no provider call, nothing sent)]
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402
import crm  # noqa: E402
import notify_owner  # noqa: E402
import wa  # noqa: E402

MAX_CHARS = notify_owner.MAX_APPROVAL_CHARS
# "Valid till 31 Dec 23:59 IST." - used to measure the message before the real expiry time is known
_EXPIRY_PLACEHOLDER = "31 Dec 23:59 IST"


class TemplateLookupError(Exception):
    """The WhatsApp template could not be read from the provider."""


# ---------------- one builder per action ----------------
# Each returns (plan, problems). A plan is a dict:
#   channel/title     what kind of action (for the log and the owner message)
#   to_full/to_masked who gets it: the owner sees the FULL one (they are trusted), the terminal/log shows the masked one
#   head              lines shown before the text   (e.g. "Subject: ...")
#   preview           the text itself, complete
#   tail              lines shown after the text    (e.g. footer, buttons)
#   links             every link the lead would see, one per line in the owner message
#   hash              the action hash the send tool will verify
#   recipient         what to look up in the CRM do-not-contact list (None for template creation)
def _plan_email(a):
    problems = []
    to = C.norm_email(a.to)
    body = None
    if not to:
        problems.append("recipient is not a single valid email address")
    elif C.is_suppressed(to):
        problems.append("recipient is on the suppression list")
    p = Path(a.body_file)
    if not p.exists():
        problems.append("body file not found")
    else:
        body = p.read_text(encoding="utf-8")
    if len(a.subject) > 150 or "\n" in a.subject:
        problems.append("subject must be one line, <= 150 chars")
    if a.subject.lower().startswith(("re:", "fwd:", "fw:")):
        problems.append("subject must not fake a reply/forward")
    earlier = C.recent_send("email", C.send_key("email", to, a.subject)) if to else None
    if earlier:
        problems.append(C.duplicate_problem(earlier, f"same email already sent in the last {C.config()['duplicate_guard_days']} days", what="email"))
    ok, cap_msg = C.check_cap("email")
    if not ok:
        problems.append(cap_msg)
    if problems:
        return None, problems
    reply_to = C.norm_email(a.reply_to) or ""
    shown_body = body.replace("\r\n", "\n").strip()   # exactly what the hash covers
    head = [f"Subject: {a.subject}"]
    if reply_to:
        head.append(f"Reply-To: {reply_to}")
    return {
        "channel": "email", "title": "EMAIL", "recipient": to,
        "to_full": to, "to_masked": C.mask_email(to),
        "head": head, "preview": shown_body,
        "tail": ["(Our sender name, postal address and an opt-out line are added automatically.)"],
        "links": C.urls_in(a.subject, shown_body),
        "hash": C.email_action_hash(to, a.subject, body, a.reply_to),
    }, []


def _find_template(name, lang):
    """The template row from the WhatsApp provider (read-only), or None. Raises TemplateLookupError if we cannot ask."""
    try:
        b = wa.Bsp()
        rows = b.all_templates()
    except SystemExit as e:        # missing credentials / unsafe base URL
        raise TemplateLookupError(str(e))
    mine = [r for r in rows if str(r.get("name")) == name]
    if not mine and not b.list_ok:
        raise TemplateLookupError("the provider's template list could not be read (error or timeout)")
    exact = [r for r in mine if str(r.get("language")) == lang]
    return (exact or mine or [None])[0]


def render_template(row, params, header_video_url, header_image_url, url_suffix):
    """The message exactly as the lead will get it, built from the provider's own template text + our parameters.
    Returns (head_lines, body_text, tail_lines, links, problems)."""
    problems, head, tail, links = [], [], [], []
    comps = {str(c.get("type", "")).upper(): c for c in (row.get("components") or []) if isinstance(c, dict)}
    if str(row.get("status")) != "APPROVED":
        problems.append(f"template status is {row.get('status')}, not APPROVED (the send would be blocked)")

    template_body = str((comps.get("BODY") or {}).get("text") or "")
    if not template_body:
        problems.append("the provider returned no BODY text for this template, so the owner could not be shown the message")
    variables = sorted({int(n) for n in re.findall(r"\{\{(\d+)\}\}", template_body)})
    if template_body and variables != list(range(1, len(params) + 1)):
        problems.append(f"template needs {len(variables)} body parameter(s) but {len(params)} --body-param were given")
    body_text = re.sub(r"\{\{(\d+)\}\}", lambda m: params[int(m.group(1)) - 1] if 0 < int(m.group(1)) <= len(params) else m.group(0),
                       template_body)

    fmt = str((comps.get("HEADER") or {}).get("format") or "").upper()
    if fmt == "VIDEO":
        if not header_video_url:
            problems.append("the template has a VIDEO header but no --header-video-url was given")
        else:
            head.append("Header video: " + header_video_url)
            links.append(header_video_url)
    elif fmt == "IMAGE":
        if not header_image_url:
            problems.append("the template has an IMAGE header but no --header-image-url was given")
        else:
            head.append("Header image: " + header_image_url)
            links.append(header_image_url)
    elif header_video_url or header_image_url:
        problems.append("a header URL was given but the template has no video/image header")
    if header_video_url and header_image_url:
        problems.append("give a header video OR a header image, not both")

    footer = str((comps.get("FOOTER") or {}).get("text") or "")
    if footer:
        tail.append("Footer: " + footer)
    suffix_used = False
    for b in (comps.get("BUTTONS") or {}).get("buttons") or []:
        if not isinstance(b, dict):
            continue
        kind, text = str(b.get("type", "")).upper(), str(b.get("text", ""))
        if kind == "URL":
            url = str(b.get("url", ""))
            if "{{1}}" in url:
                if not url_suffix:
                    problems.append("the template's link button needs --url-suffix")
                else:
                    suffix_used = True
                url = url.replace("{{1}}", url_suffix or "{{1}}")
            tail.append(f"Button [{text}] opens: {url}")
            links.append(url)
        elif kind == "PHONE_NUMBER":
            tail.append(f"Button [{text}] calls: {b.get('phone_number', '?')}")
        else:
            tail.append(f"Button [{text}]")
    if url_suffix and not suffix_used:
        problems.append("--url-suffix was given but the template has no link button that uses it")
    return head, body_text, tail, links + C.urls_in(body_text), problems


def _plan_wa_template(a, dry_run=False):
    to, _key, _cap, problems = wa._guard_send(a.to, a.lead, ("wa_tpl", a.template), "whatsapp_template", False, True)
    if problems:
        return None, problems
    params = [str(p) for p in (a.body_param or [])]
    head = [f"Template: {a.template} ({a.lang})"]
    tail, links = [], []
    if dry_run:
        # offline: we do not ask the provider in a dry-run, so say so loudly instead of showing a partial message
        preview = "(dry-run: the real text of the template is fetched from the WhatsApp provider when you propose for real)\n" + \
                  "\n".join(f"{{{{{i}}}}} = {v}" for i, v in enumerate(params, 1))
        for u in (a.header_video_url, a.header_image_url):
            if u:
                head.append("Header: " + u)
                links.append(u)
    else:
        try:
            row = _find_template(a.template, a.lang)
        except TemplateLookupError as e:
            return None, ["cannot read the template text from the WhatsApp provider, so the owner could not be shown the message: " + str(e)]
        if row is None:
            return None, [f"template '{a.template}' not found at the WhatsApp provider"]
        extra_head, preview, tail, links, tpl_problems = render_template(
            row, params, a.header_video_url, a.header_image_url, a.url_suffix)
        if tpl_problems:
            return None, tpl_problems
        head += extra_head
    return {
        "channel": "whatsapp_template", "title": "WHATSAPP TEMPLATE (first touch)", "recipient": to,
        "to_full": "+" + to, "to_masked": C.mask_phone(to),
        "head": head, "preview": preview, "tail": tail, "links": links,
        "hash": C.wa_template_action_hash(to, a.template, a.lang, a.body_param, a.header_video_url, a.header_image_url, a.url_suffix),
    }, []


def _plan_wa_reply(a):
    problems = []
    to = C.norm_phone(a.to)
    if not to:
        problems.append("recipient is not a valid Indian mobile number")
    elif C.is_suppressed(to):
        problems.append("recipient is on the suppression list")
    problems += wa.reply_window_problems(a.inbound_at)
    if not a.text.strip() or len(a.text) > 1500:
        problems.append("text required, <= 1500 chars")
    if to:
        problems += wa.reply_limit_problems(to, a.text)[2]
    if problems:
        return None, problems
    return {
        "channel": "whatsapp_reply", "title": "WHATSAPP REPLY", "recipient": to,
        "to_full": "+" + to, "to_masked": C.mask_phone(to),
        "head": [], "preview": a.text.strip(), "tail": [], "links": C.urls_in(a.text),
        "hash": C.wa_reply_action_hash(to, a.text),
    }, []


def _plan_wa_create(a):
    spec, errs, header_path = wa.load_create_spec(a.spec)
    if errs:
        return None, errs
    unknown = wa.create_unknown_problems(spec.get("name"))
    if unknown:
        return None, unknown
    blob = Path(header_path).read_bytes() if header_path else None
    clean = {k: v for k, v in spec.items() if not str(k).startswith("_")}
    head = [f"Template name: {spec['name']}", f"Language: {spec['language']}   Category: {spec.get('category', 'MARKETING')}"]
    if spec.get("header"):
        h = spec["header"]
        head.append(f"Header: {h.get('format')} file {Path(spec['_header_path']).name} ({len(blob) // 1024} KB, sha256 {hashlib.sha256(blob).hexdigest()[:12]}...)")
    else:
        head.append("Header: none")
    tail, links = [], []
    if spec.get("body_examples"):
        tail.append("Body examples: " + " | ".join(str(x) for x in spec["body_examples"]))
    if spec.get("footer"):
        tail.append("Footer: " + spec["footer"])
    for b in spec.get("buttons") or []:
        line = f"Button [{b.get('text')}] ({b.get('type')})"
        if b.get("url"):
            line += " opens: " + b["url"]
            links.append(b["url"])
        if b.get("example"):
            line += "  example: " + str(b["example"])
        if b.get("phone_number"):
            line += " calls: " + str(b["phone_number"])
        tail.append(line)
    other = {k: v for k, v in clean.items() if k not in ("name", "language", "category", "header", "body", "body_examples", "footer", "buttons")}
    if other:
        tail.append("Other fields in the spec: " + json.dumps(other, ensure_ascii=False))
    return {
        "channel": "whatsapp_template_create", "title": "CREATE WHATSAPP TEMPLATE (submit to Meta)", "recipient": None,
        "to_full": "the WhatsApp Business account", "to_masked": "the WhatsApp Business account",
        "head": head, "preview": spec["body"], "tail": tail, "links": links + C.urls_in(spec["body"]),
        "hash": C.wa_create_action_hash(spec, header_path, header_bytes=blob),
    }, []


# ---------------- the owner message ----------------
def build_owner_message(plan, code, expires_text, reason="", lead="", masked=False):
    """Plain text with EVERYTHING the code approves, nothing cut. masked=True is only for printing in the terminal / chat log."""
    who = plan["to_masked"] if masked else plan["to_full"]
    lines = [f"APPROVAL NEEDED [{code}]", plan["title"], f"To: {who}"]
    if lead:
        lines.append("Lead label (typed by the agent, not checked): " + " ".join(lead.split())[:120])
    lines += plan["head"]
    if reason:
        lines.append("Agent's reason (typed by the agent, not checked): " + " ".join(reason.split())[:300])
    if plan["links"]:
        lines.append("Links the lead will see:")
        lines += ["  " + u for u in plan["links"]]
    lines += ["--- text ---", plan["preview"], "--- end of text ---"]
    lines += plan["tail"]
    lines.append("This code approves exactly the text above and nothing else.")
    lines.append(f"Reply OK {code} to approve, NO {code} to skip.")
    if expires_text:
        lines.append(f"Valid till {expires_text}.")
    return "\n".join(lines)


def _expiry_text(expires_at):
    t = C.parse_ts(expires_at)
    return t.astimezone(C.IST).strftime("%d %b %H:%M IST") if t else ""


# ---------------- "already asked?" memory ----------------
def _proposals_path():
    return C.STATE / "proposals.jsonl"


def _remember(action_hash, code, expires_at):
    with open(_proposals_path(), "a", encoding="utf-8") as f:
        f.write(json.dumps({"hash": action_hash, "code": code, "expires_at": expires_at, "ts": C.now_ist().isoformat(timespec="seconds")}) + "\n")


def _existing_proposal(action_hash):
    """(code, status) of an earlier, still-valid proposal for exactly this action, or (None, None)."""
    p = _proposals_path()
    if not p.exists():
        return None, None
    now = C.dt.datetime.now(C.dt.timezone.utc)
    for line in reversed(p.read_text(encoding="utf-8").splitlines()):
        try:
            r = json.loads(line)
        except ValueError:
            continue
        exp = C.parse_ts(r.get("expires_at"))
        if r.get("hash") != action_hash or exp is None or exp <= now or not C.clean_approval_code(r.get("code")):
            continue
        try:
            status = str(crm.approval(r["code"]).get("status", "")).lower()
        except (C.CrmError, ValueError):
            return None, None      # cannot tell; the normal path will fail clearly if the CRM is really down
        if status in ("pending", "approved", "rejected"):
            return r["code"], status
    return None, None


# ---------------- main ----------------
def main():
    C.start()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--lead", default="", help="business / lead name (shown to the owner, marked as typed by the agent)")
    common.add_argument("--reason", default="", help="one line: why this lead, why now (shown to the owner, marked as typed by the agent)")
    common.add_argument("--ttl-hours", type=int, default=None, help="how long the owner has to answer (1-48; default set by the CRM)")
    common.add_argument("--dry-run", action="store_true", help="show the hash and the owner message only; no CRM call, no provider call, nothing sent")
    sub = ap.add_subparsers(dest="kind", required=True)
    p = sub.add_parser("email", parents=[common])
    p.add_argument("--to", required=True); p.add_argument("--subject", required=True); p.add_argument("--body-file", required=True)
    p.add_argument("--reply-to", default=""); p.set_defaults(plan=_plan_email)
    p = sub.add_parser("wa-template", parents=[common])
    p.add_argument("--to", required=True); p.add_argument("--template", required=True); p.add_argument("--lang", default="en")
    p.add_argument("--body-param", action="append"); p.add_argument("--header-video-url"); p.add_argument("--header-image-url")
    p.add_argument("--url-suffix"); p.set_defaults(plan=_plan_wa_template)
    p = sub.add_parser("wa-reply", parents=[common])
    p.add_argument("--to", required=True); p.add_argument("--text", required=True); p.add_argument("--inbound-at", required=True)
    p.set_defaults(plan=_plan_wa_reply)
    p = sub.add_parser("wa-create", parents=[common])
    p.add_argument("--spec", required=True); p.set_defaults(plan=_plan_wa_create)
    a = ap.parse_args()

    if a.kind == "wa-template":
        plan, problems = _plan_wa_template(a, dry_run=a.dry_run)
    else:
        plan, problems = a.plan(a)
    print(f"== propose [{a.kind}]{' DRY-RUN' if a.dry_run else ''}")

    if not problems and not a.dry_run:
        # No point asking the owner while everything is paused or the CRM could not hear the answer. Local checks first (offline).
        has_budget, cap = notify_owner.budget_left()
        if not has_budget:
            # a runaway loop must not pile up approvals the owner will never see
            problems.append(f"daily limit of {cap} owner messages reached - not asking the owner again today")
        elif C.paused():
            problems.append("agent is PAUSED (agent/state/PAUSED exists) - nothing can be sent until the owner resumes")
        else:
            try:
                health = crm.health()
                if C.flag_is_paused(health.get("paused")) is not False:
                    problems.append("the owner paused all sending (CRM flag) - not asking for approvals now")
                if health.get("owner_routing") != "enabled":
                    problems.append(f"the CRM cannot receive the owner's answer (owner_routing = {health.get('owner_routing')!r}); "
                                    "the CRM needs OWNER_WHATSAPP_NUMBERS and a webhook secret - ask the owner to finish the setup")
                if plan.get("recipient"):
                    problems += C.crm_suppression_problems(plan["recipient"])
            except C.CrmError as e:
                problems.append("cannot reach the CRM: " + str(e))

    # The owner message must be complete: measure it now (with a stand-in code) and refuse if it does not fit.
    if not problems:
        measured = build_owner_message(plan, "ABCDE", _EXPIRY_PLACEHOLDER, a.reason, a.lead)
        if len(measured) > MAX_CHARS:
            problems.append(f"the complete message the owner must read is {len(measured)} characters (limit {MAX_CHARS}). "
                            "Shorten the draft: an approval for text the owner cannot read in full is worthless")

    if problems:
        print("NOT PROPOSED:")
        for x in problems:
            print("  -", x)
        C.log_event("proposal_blocked", action=a.kind, lead=getattr(a, "lead", ""), reasons=problems)
        sys.exit(2)

    print(f"   {plan['title']} to {plan['to_masked']}")
    print(f"   action hash: {plan['hash'][:16]}...")
    if a.dry_run:
        print("-- owner message (example code ABCDE; the owner sees the recipient in full, here it is masked) --")
        print(build_owner_message(plan, "ABCDE", "", a.reason, a.lead, masked=True))
        print("\n(dry-run: no approval created, owner not contacted)")
        return

    old_code, old_status = _existing_proposal(plan["hash"])
    if old_status == "rejected":
        print(f"NOT PROPOSED: the owner already answered NO to this exact action (code {old_code}). Change the content and ask again.")
        C.log_event("proposal_blocked", action=a.kind, lead=a.lead, reasons=["owner already rejected this exact action"])
        sys.exit(2)
    if old_code:
        print(f"ALREADY PROPOSED: code {old_code} (status: {old_status}) - the owner is not messaged again.")
        if old_status == "approved":
            print(f"Next: the owner approved it. Run the same send command with  --live --approval {old_code}")
        else:
            print(f"Next: wait for the owner's reply, then run the same send command with  --live --approval {old_code}")
        return

    summary = f"{plan['title']} to {plan['to_masked']}: " + " ".join((plan["head"][:1] + [plan["preview"]])).replace("\n", " ")
    try:
        ap_row = crm.create_approval(plan["hash"], summary[:300], a.ttl_hours)
    except (C.CrmError, ValueError) as e:
        print("NOT PROPOSED: could not create the approval:", e)
        C.log_event("proposal_failed", action=a.kind, lead=a.lead, detail=str(e)[:200])
        sys.exit(1)
    code, expires_at = ap_row.get("code"), ap_row.get("expires_at")
    if not C.clean_approval_code(code):
        print("NOT PROPOSED: the CRM did not return a usable code")
        sys.exit(1)
    _remember(plan["hash"], code, expires_at)
    C.log_event("proposal_created", action=a.kind, lead=a.lead, code=code, action_hash=plan["hash"][:12], expires_at=expires_at)
    print(f"APPROVAL CODE: {code}   (expires {expires_at})")

    message = build_owner_message(plan, code, _expiry_text(expires_at), a.reason, a.lead)
    try:
        res = notify_owner.notify(message, max_chars=MAX_CHARS, allowed_codes=[code])
    except ValueError as e:  # cannot happen after the length check above; kept so a bug never hides the code we just created
        res = {"ok": False, "detail": str(e)}
    print("   owner notification:", res["detail"])
    if not res["ok"] and res.get("unknown"):
        # The provider did not answer in time: the owner's WhatsApp may well have arrived. Do not claim it failed.
        print(f"WARNING: approval {code} exists in the CRM. The owner notification has an UNKNOWN outcome (it may have been delivered). "
              "Do not assume it failed and do not send it again blindly: ask the owner in chat whether the request arrived.")
        sys.exit(3)
    if not res["ok"]:
        print(f"WARNING: approval {code} exists in the CRM but the owner was NOT notified. Tell the owner in chat, or run notify_owner.py.")
        sys.exit(1)
    print(f"Next: when the owner replies OK {code}, run the same send command with  --live --approval {code}")
    print(f"      (check the state any time with: python agent/tools/crm.py approval {code})")


if __name__ == "__main__":
    main()
