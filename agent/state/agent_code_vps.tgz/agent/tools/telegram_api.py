# -*- coding: utf-8 -*-
"""telegram_api.py - a minimal Telegram Bot API client (standard library only), used by the Telegram lane and by the owner tools
(notify_owner.py, send_owner_file.py) when OWNER_CHANNEL=telegram.

Settings (process environment or the env file, never printed):
  TELEGRAM_BOT_TOKEN   from @BotFather
  TELEGRAM_OWNER_ID    the owner's numeric Telegram user id; the bot talks to this ONE person only
  OWNER_CHANNEL        "telegram" makes notify_owner.py / send_owner_file.py use this instead of WhatsApp
Every call has a timeout. Errors never contain the bot token. A result has "_unknown": True when the request MAY have been processed
although no usable answer came back (so a possibly-delivered message is never blindly repeated).
"""
import json
import os
import sys
import urllib.error
import urllib.request
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402


def token():
    return C.get_env("TELEGRAM_BOT_TOKEN")


def owner_id():
    try:
        return int(C.get_env("TELEGRAM_OWNER_ID"))
    except (TypeError, ValueError):
        return None


def configured():
    return bool(token() and owner_id())


def base_url():
    """https://api.telegram.org. TELEGRAM_API_BASE exists only so the offline tests can point at a fake server on this computer."""
    override = C.get_env("TELEGRAM_API_BASE") if os.environ.get("AGENT_TEST_MODE") == "1" else ""
    return (override or "https://api.telegram.org").rstrip("/")


def call(method, params=None, file=None, timeout=20):
    """One Bot API request. file = (field, filename, mime, bytes) sends multipart (params become form fields).
    Returns (http_code, dict). code 0 = no HTTP answer at all."""
    tok, base = token(), base_url()
    scrub = C.Scrubber([tok])
    if not tok:
        return 0, {"_error": "TELEGRAM_BOT_TOKEN is not set"}
    if not C.safe_base_url(base):
        return 0, {"_error": "Telegram API base must be https"}
    url = "%s/bot%s/%s" % (base, tok, method)
    headers = {"User-Agent": "ivinfotech-agent/1"}
    if file is None:
        data = json.dumps(params or {}).encode("utf-8")
        headers["Content-Type"] = "application/json"
    else:
        boundary = "----ivagent" + uuid.uuid4().hex
        parts = [('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n%s\r\n' % (boundary, k, v)).encode("utf-8") for k, v in (params or {}).items()]
        field, filename, mime, blob = file
        safe = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in filename)[:80]
        parts.append(('--%s\r\nContent-Disposition: form-data; name="%s"; filename="%s"\r\nContent-Type: %s\r\n\r\n' % (boundary, field, safe, mime)).encode("utf-8"))
        parts += [blob, ("\r\n--%s--\r\n" % boundary).encode("utf-8")]
        data = b"".join(parts)
        headers["Content-Type"] = "multipart/form-data; boundary=" + boundary
    req = urllib.request.Request(url, data=data, method="POST", headers=headers)
    try:
        with C.opener_for(base).open(req, timeout=timeout) as r:
            code, raw = r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        code = e.code
        try:
            raw = e.read().decode("utf-8", "replace")
        except Exception:
            raw = ""
    except Exception as e:
        out = {"_error": scrub(str(e) or type(e).__name__, 200)}
        if C.is_unknown_outcome(e):
            out["_unknown"] = True
        return 0, out
    try:
        res = json.loads(raw)
    except ValueError:
        res = {"_raw": scrub(raw, 200)}
    res = res if isinstance(res, dict) else {"_data": scrub(str(res), 200)}
    if C.unknown_http_status(code):
        res["_unknown"] = True
    return code, res


def ok(code, res):
    return 200 <= code < 300 and res.get("ok") is True


def send_message(text, chat_id=None):
    """(ok, detail, unknown) - plain text to the owner, no markup (nothing in the text is ever interpreted as HTML / Markdown)."""
    cid = chat_id or owner_id()
    if not (token() and cid):
        return False, "Telegram is not configured (TELEGRAM_BOT_TOKEN / TELEGRAM_OWNER_ID)", False
    code, res = call("sendMessage", {"chat_id": cid, "text": text, "disable_web_page_preview": True})
    if ok(code, res):
        return True, "sent on Telegram", False
    if C.result_is_unknown(code, res, False):
        return False, "Telegram send has no usable answer (http %s) %s" % (code, res.get("_error", "")), True
    return False, "Telegram refused the message (http %s) %s" % (code, str(res.get("description") or res.get("_error") or "")[:150]), False


def typing(chat_id=None):
    """Shows 'typing...' to the owner for ~5 s. Best effort, short timeout, never raises."""
    try:
        call("sendChatAction", {"chat_id": chat_id or owner_id(), "action": "typing"}, timeout=4)
    except Exception:
        pass
