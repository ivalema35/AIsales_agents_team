# -*- coding: utf-8 -*-
"""send_email.py - one email via Resend. DRY-RUN unless --live.

Safety enforced here: valid single recipient, not suppressed, no duplicate within N days, daily caps,
IST send window, sender identity + postal address + opt-out line + List-Unsubscribe header added automatically,
no secrets printed. Every attempt is logged to agent/state/events.jsonl.

LIVE also needs --approval CODE: a one-time code the OWNER granted on WhatsApp for exactly this email (same recipient,
subject and body). The tool asks the CRM (fails closed if it cannot): not paused, code approved, same content, not expired,
then spends the code BEFORE sending. Dry-run never talks to the CRM.

Exit codes: 0 ok / dry-run, 1 failed (Resend clearly said no), 2 blocked before anything was sent, 3 UNKNOWN OUTCOME (Resend did not
answer in time, so the email MAY have been delivered: it is counted as sent, the duplicate guard blocks a repeat, nobody should
retry before checking delivery - see "unknown outcome" in common.py).

Usage:
  python agent/tools/send_email.py --to owner@example.com --subject "..." --body-file draft.txt --lead "Shree Infra"            (preview)
  python agent/tools/send_email.py --to ... --subject "..." --body-file draft.txt --lead "..." --live --approval K7P2M      (send)
"""
import argparse
import html
import json
import re
import sys
import urllib.error
import urllib.request

from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402

URL_RE = re.compile(r"(https?://[^\s<>\"]+)")


def signature_line(from_name, address):
    """Sender identity line without repeated words: the configured sender name and the postal address often already
    contain the company name (e.g. "Ronak from IVinfotech" + "IVinfotech, T-332, ...")."""
    parts = []
    for p in (from_name, "Ivinfotech", re.sub(r"^\s*i\.?v\.?\s*infotech\s*,?\s*", "", address or "", flags=re.I)):
        p = (p or "").strip().strip(",")
        if p and p.lower() not in ", ".join(parts).lower():
            parts.append(p)
    return ", ".join(parts)


def build_bodies(body_text, from_name, address):
    footer = (
        f"\n\n--\n{signature_line(from_name, address)}" +
        "\nIf you would rather not hear from us, just reply \"stop\" and we will not write again."
    )
    text = body_text.strip() + footer
    paras = [p for p in re.split(r"\n\s*\n", text) if p.strip()]
    h = []
    for p in paras:
        esc = html.escape(p).replace("\n", "<br>")
        esc = URL_RE.sub(lambda m: f'<a href="{m.group(1)}">{m.group(1)}</a>', esc)
        h.append(f"<p>{esc}</p>")
    return text, "<div style=\"font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.5\">" + "".join(h) + "</div>"


def resend_base(env):
    """Resend API address. RESEND_API_BASE_URL exists only so the offline tests can point at a fake server on this computer."""
    return (env.get("RESEND_API_BASE_URL") or "https://api.resend.com").rstrip("/")


def resend_send(env, payload):
    """POST one email to Resend. Returns (http_code, dict). Also used by notify_owner.py for the owner's email fallback.
    code 0 = no HTTP answer at all. The dict gets "_unknown": True when the email MAY already have been handed to Resend although
    we have no complete answer (read timeout, connection reset, gateway timeout ...). DNS failure, connection refused, TLS
    certificate errors and "network unreachable" happen before anything is sent and are NOT marked. See "unknown outcome" in common.py."""
    base = resend_base(env)
    if not C.safe_base_url(base):
        return 0, {"_error": "RESEND_API_BASE_URL must be https"}
    scrub = C.Scrubber([env.get("RESEND_API_KEY", "")])
    req = urllib.request.Request(
        base + "/emails", data=json.dumps(payload).encode("utf-8"), method="POST",
        headers={"Authorization": "Bearer " + env["RESEND_API_KEY"], "Content-Type": "application/json", "User-Agent": "ivinfotech-agent/1"})
    try:
        with C.opener_for(base).open(req, timeout=C.http_timeout(C.DEFAULT_RESEND_TIMEOUT)) as r:
            code, raw = r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        code = e.code
        try:
            raw = e.read().decode("utf-8", "replace")
        except Exception:
            raw = ""  # status arrived, body did not: the status alone decides (see unknown_http_status)
    except Exception as e:
        out = {"_error": scrub(str(e) or type(e).__name__, 200)}
        if C.is_unknown_outcome(e):
            out["_unknown"] = True
        return 0, out
    try:
        res = json.loads(raw)
    except Exception:
        res = {"raw": scrub(raw, 200)}
    res = res if isinstance(res, dict) else {"raw": scrub(str(res), 200)}
    if C.unknown_http_status(code):
        res["_unknown"] = True
    return code, res


def main():
    C.start()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--to", required=True)
    ap.add_argument("--subject", required=True)
    ap.add_argument("--body-file", required=True, help="plain-text body (no footer; footer is added)")
    ap.add_argument("--lead", default="", help="business / lead name for the log")
    ap.add_argument("--reply-to", default="")
    ap.add_argument("--live", action="store_true", help="actually send (needs --approval)")
    ap.add_argument("--approval", default="", help="one-time code the owner approved on WhatsApp for exactly this email (see propose.py)")
    ap.add_argument("--ignore-window", action="store_true",
                    help="OWNER ONLY: ignore the IST send window (works only with AGENT_OWNER_OVERRIDE=1 in the environment)")
    a = ap.parse_args()
    if a.ignore_window:
        C.require_override("--ignore-window", "AGENT_OWNER_OVERRIDE")

    env = C.load_env()
    scrub = C.Scrubber([env.get("RESEND_API_KEY", "")])
    to = C.norm_email(a.to)
    problems = []
    if not to:
        problems.append("recipient is not a single valid email address")
    if to and C.is_suppressed(to):
        problems.append("recipient is on the suppression list")
    if a.live and to:
        # The CRM's own do-not-contact list (it records every STOP it receives, even if the operator forgot to run suppress.py).
        problems += C.crm_suppression_problems(to)
    body_path = Path(a.body_file)
    body_raw = None
    if not body_path.exists():
        problems.append("body file not found")
    else:
        body_raw = body_path.read_text(encoding="utf-8")
    if len(a.subject) > 150 or "\n" in a.subject:
        problems.append("subject must be one line, <= 150 chars")
    if a.subject.lower().startswith(("re:", "fwd:", "fw:")):
        problems.append("subject must not fake a reply/forward")
    key = C.send_key("email", to, a.subject)
    earlier = C.recent_send("email", key) if to else None
    if earlier:
        problems.append(C.duplicate_problem(earlier, f"same email already sent in the last {C.config()['duplicate_guard_days']} days", what="email"))
    ok, cap_msg = C.check_cap("email")
    if not ok:
        problems.append(cap_msg)
    if a.live and not a.ignore_window and not C.in_send_window():
        problems.append(f"outside the send window {C.config()['send_window_ist']} IST")
    if a.live and C.paused():
        problems.append("agent is PAUSED (agent/state/PAUSED exists) - the owner must resume it")
    from_email = env.get("RESEND_FROM_EMAIL", "")
    from_name = env.get("RESEND_FROM_NAME", "Ivinfotech")
    if a.live and not env.get("RESEND_API_KEY"):
        problems.append("RESEND_API_KEY missing")
    if a.live and not C.safe_base_url(resend_base(env)):
        problems.append("RESEND_API_BASE_URL must be https")
    if not from_email:
        problems.append("RESEND_FROM_EMAIL missing")

    # The owner-approval gate (live only). The hash covers recipient + subject + body (+ reply-to), so a code that was
    # approved for another email is useless here.
    ahash = C.email_action_hash(to, a.subject, body_raw, a.reply_to) if (to and body_raw is not None) else None
    if a.live and ahash:
        problems += C.live_gate_check(a.approval, ahash)

    print(f"== send_email [{C.banner(a.live)}]")
    print(f"   to:      {C.mask_email(to) if to else '?'}   lead: {a.lead or '-'}")
    print(f"   subject: {a.subject}")
    print(f"   caps:    {cap_msg}")
    if problems:
        print("BLOCKED:")
        for p in problems:
            print("  -", p)
        C.log_event("email_blocked", lead=a.lead, to=C.mask_email(to), reasons=problems)
        sys.exit(2)

    text, html_body = build_bodies(body_raw, from_name, env.get("COMPANY_PHYSICAL_ADDRESS", ""))
    print("-- text preview --")
    print(text[:1500])
    if not a.live:
        C.log_event("email_dry_run", lead=a.lead, to=C.mask_email(to), subject=a.subject)
        print("\n(dry-run: nothing sent)")
        return

    # Spend the one-time code BEFORE sending. If this fails we do not send (no code = no email).
    ok, why = C.consume_approval(a.approval, ahash)
    if not ok:
        print("BLOCKED:\n  -", why)
        C.log_event("email_blocked", lead=a.lead, to=C.mask_email(to), reasons=[why])
        sys.exit(2)
    code_used = C.clean_approval_code(a.approval)
    print(f"   approval: {code_used} verified and used up")

    payload = {
        "from": f"{from_name} <{from_email}>",
        "to": [to],
        "subject": a.subject,
        "text": text,
        "html": html_body,
        "headers": {"List-Unsubscribe": f"<mailto:{from_email}?subject=unsubscribe>"},
    }
    if a.reply_to and C.norm_email(a.reply_to):
        payload["reply_to"] = C.norm_email(a.reply_to)
    code, res = resend_send(env, payload)
    if C.result_is_unknown(code, res, 200 <= code < 300 and res.get("id")):
        # No usable answer, but Resend may have accepted and sent it. Count it as SENT (daily caps, duplicate guard) - the safe side.
        C.bump("email")
        C.record_send("email", key, status="unknown", lead=a.lead, to=C.mask_email(to), subject=a.subject)
        C.log_event("email_unknown", lead=a.lead, to=C.mask_email(to), subject=a.subject, http=code, detail=scrub(res, 300), approval=code_used)
        C.crm_log_activity(a.lead or C.mask_email(to), "email", "email_unknown",
                           f"UNKNOWN outcome: email to {C.mask_email(to)} may have been delivered (the provider did not answer): {a.subject}")
        print(C.unknown_outcome_text(C.unknown_cause(code)))
        print("   detail:", scrub(res, 300))
        print("   (delivery status: Resend dashboard > Emails, or ask the recipient)")
        print("   counted as sent today, and the same email (same recipient + subject) is now blocked by the duplicate guard.")
        print("NOTE: the approval code was already used up.")
        sys.exit(3)
    if 200 <= code < 300 and res.get("id"):
        C.bump("email")
        C.record_send("email", key, lead=a.lead, to=C.mask_email(to), provider_id=res["id"], subject=a.subject)
        C.log_event("email_sent", lead=a.lead, to=C.mask_email(to), subject=a.subject, provider_id=res["id"], approval=code_used)
        C.crm_log_activity(a.lead or C.mask_email(to), "email", "email_sent", f"Email sent to {C.mask_email(to)}: {a.subject}")
        print(f"SENT  id={res['id']}")
    else:
        C.log_event("email_failed", lead=a.lead, to=C.mask_email(to), http=code, detail=scrub(res, 300), approval=code_used)
        print("FAILED http", code, scrub(res, 300))
        print("NOTE: the approval code was already used up; ask the owner again (propose.py) before retrying.")
        sys.exit(1)


if __name__ == "__main__":
    main()
