# -*- coding: utf-8 -*-
"""heartbeat_check.py - one cheap look (no model) that tells a worker whether there is ANY work for it.

Two workers use it:
  * the OPERATOR lane (agent/fastlane/operator.py, a persistent headless Claude): default mode, `collect()`
  * the DESKTOP heartbeat (scheduled task, a new Claude session per run, so it runs rarely): `--desktop`
The split is by what the work needs. A line in heartbeat_todo.md that ends with the tag [needs-desktop] (Apify connector, Mobbin,
ssh to the VPS, a live send ...) and an owner-approved code that is not used yet belong to the DESKTOP; everything else belongs to the
OPERATOR lane.

It prints either the single word IDLE, or one "WORK: ..." line per reason (and "NOTICE: ..." lines for things worth a log line but not a
run). Reasons:
  * the owner-inbox has a message nobody handled (when the WhatsApp fast lane is alive only messages older than 3 minutes count:
    the fast lane answers the others itself) - operator mode only
  * heartbeat_todo.md has an open line: starts with "- [" and is not DONE / CANCELLED (tagged [needs-desktop] -> desktop mode, else operator)
  * a lead replied (CRM inbound feed has an id newer than agent/state/heartbeat.json last_inbound_id) - operator mode only
  * an approval the owner granted in the last 12 hours is still unused (status "approved") - desktop mode only
It sends nothing and acks nothing; its only write is one "idle" line in heartbeat.log every 30 minutes (command line use only).
Exit code is 0 in every case; a CRM problem is printed as "ATTENTION: ..."

Usage:  python agent/tools/heartbeat_check.py [--desktop]
"""
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402

STUCK_SECONDS = 180
FASTLANE_FRESH_SECONDS = 30
DESKTOP_TAG = "[needs-desktop]"


def fastlane_alive():
    try:
        d = json.loads((C.STATE / "fastlane" / "alive.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    return bool(d.get("claude_ready")) and time.time() - float(d.get("ts", 0)) < FASTLANE_FRESH_SECONDS


def open_todo_lines():
    """[(line, needs_desktop)] for every open line of heartbeat_todo.md."""
    try:
        lines = (C.STATE / "heartbeat_todo.md").read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for ln in lines:
        s = ln.strip()
        if s.startswith("- [") and "CANCELLED" not in s.upper():
            out.append((s[:140], DESKTOP_TAG in s.lower()))
    return out


def last_inbound_id():
    try:
        return int(json.loads((C.STATE / "heartbeat.json").read_text(encoding="utf-8")).get("last_inbound_id", 0))
    except (OSError, ValueError, TypeError):
        return 0


def recent_proposal_codes(hours=12):
    """Codes from proposal_created events of the last `hours` (the tail of events.jsonl is enough)."""
    try:
        lines = (C.STATE / "events.jsonl").read_text(encoding="utf-8").splitlines()[-400:]
    except OSError:
        return []
    cutoff, codes = time.time() - hours * 3600, []
    for ln in lines:
        try:
            e = json.loads(ln)
        except ValueError:
            continue
        if e.get("kind") != "proposal_created" or not e.get("code"):
            continue
        ts = C.parse_ts(e.get("ts"), naive_tz=C.IST)
        if ts is not None and ts.timestamp() > cutoff:
            codes.append(str(e["code"]))
    return codes[-10:]


def collect(desktop=False):
    """{"attention": str|None, "work": [str], "notice": [str], "fastlane_alive": bool}. Read-only."""
    res = {"attention": None, "work": [], "notice": [], "fastlane_alive": False}
    try:
        code, _ = C.crm_call("GET", "/health", timeout=8)
    except C.CrmError as e:
        res["attention"] = "CRM unreachable (%s)" % str(e)[:120]
        return res
    if code != 200:
        res["attention"] = "CRM health answered HTTP %s" % code
        return res
    alive = fastlane_alive()
    res["fastlane_alive"] = alive
    work = res["work"]
    if not alive:
        res["notice"].append("the WhatsApp fast lane is NOT running or its Claude is not ready")

    if not desktop:
        try:
            code, d = C.crm_call("GET", "/owner-inbox?since_id=0&limit=50&unprocessed=1", timeout=8)
            items = d.get("items") if code == 200 and isinstance(d.get("items"), list) else []
        except C.CrmError:
            items = []
        for it in items:
            ts = C.parse_ts(it.get("received_at"))
            age = (time.time() - ts.timestamp()) if ts is not None else None
            if not alive or (age is not None and age > STUCK_SECONDS):
                work.append("owner message #%s is unhandled%s" % (it.get("id"), "" if alive else " (fast lane down: you answer it)"))

    for ln, needs_desktop in open_todo_lines():
        if needs_desktop == desktop:
            work.append("to-do: " + ln)

    if not desktop:
        try:
            code, d = C.crm_call("GET", "/inbound?since_id=%d&limit=1" % last_inbound_id(), timeout=8)
            if code == 200 and d.get("items"):
                work.append("a lead replied (inbound id > %d)" % last_inbound_id())
        except C.CrmError:
            pass
    else:
        for c in recent_proposal_codes():
            try:
                code, d = C.crm_call("GET", "/approvals/" + c, timeout=8)
            except C.CrmError:
                continue
            if code == 200 and d.get("status") == "approved":
                work.append("approval %s was granted by the owner and is not used yet" % c)
    return res


def log_idle(detail, every=1800):
    """The only thing this script writes: one 'idle' line in heartbeat.log at most every 30 minutes, so the log proves the
    heartbeat is alive without a tool call (and a line) for every run."""
    stamp = C.STATE / ".heartbeat_idle_logged"
    try:
        last = float(stamp.read_text())
    except (OSError, ValueError):
        last = 0.0
    if time.time() - last < every:
        return
    try:
        with open(C.STATE / "heartbeat.log", "a", encoding="utf-8") as f:
            f.write("%s idle (cheap check: nothing to do; %s)\n" % (time.strftime("%Y-%m-%dT%H:%MZ", time.gmtime()), detail))
        stamp.write_text(str(time.time()))
    except OSError:
        pass


def main():
    C.start()
    desktop = "--desktop" in sys.argv[1:]
    r = collect(desktop=desktop)
    if r["attention"]:
        print("ATTENTION: " + r["attention"])
        return
    if not r["work"]:
        print("IDLE")
        log_idle("%s mode, fast lane %s" % ("desktop" if desktop else "operator", "alive" if r["fastlane_alive"] else "DOWN"))
    for w in r["work"]:
        print("WORK: " + w)
    for n in r["notice"]:
        print("NOTICE: " + n)


if __name__ == "__main__":
    main()
