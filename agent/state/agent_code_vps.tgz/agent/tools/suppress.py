# -*- coding: utf-8 -*-
"""suppress.py - the local do-not-contact list (agent/state/suppression.txt). Thin CLI over common.py.

  add VALUE [--reason R] [--source S]   put a phone number or email on the list (do this FIRST when a lead says STOP /
                                        "band karo" / "nahi chahiye" / complains; then confirm once and never contact again)
  check VALUE                           exit code 0 = not suppressed, 1 = SUPPRESSED
  list                                  everything on the list (numbers/emails are masked)

send_email.py and wa.py read this list and refuse to contact anybody on it. There is deliberately no "remove" command:
the agent can only make contact rules stricter. Only the owner removes a line, by editing the file.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402


def _masked(key):
    return C.mask_phone(key) if key.isdigit() else C.mask_email(key)


def cmd_add(a):
    # only real phone numbers / emails: a typo must not silently create a useless entry that looks like protection
    value = C.norm_phone(a.value) or C.norm_email(a.value)
    if not value:
        print("ERROR: give one valid Indian mobile number or one email address")
        return 2
    added = C.add_suppression(value, a.reason, a.source)
    print(("ADDED to the suppression list: " if added else "already on the suppression list: ") + _masked(value))
    if added:
        C.crm_log_activity(_masked(value), "suppression", "suppressed", f"{_masked(value)} added to do-not-contact ({a.reason or 'no reason given'})", direction="internal")
    return 0


def cmd_check(a):
    value = C.norm_phone(a.value) or C.norm_email(a.value)
    if value and C.is_suppressed(value):
        print("SUPPRESSED: " + _masked(value))
        return 1
    print("not suppressed: " + (_masked(value) if value else "<not a valid number or email>"))
    return 0


def cmd_list(a):
    rows = C.list_suppressed()
    print(f"{len(rows)} entr{'y' if len(rows) == 1 else 'ies'}")
    for r in rows:
        print(f"  {_masked(r['key'])} | {r['reason']} | {r['source']} | {r['ts']}")
    return 0


def main():
    C.start()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("add")
    p.add_argument("value")
    p.add_argument("--reason", default="")
    p.add_argument("--source", default="agent")
    p.set_defaults(fn=cmd_add)
    p = sub.add_parser("check")
    p.add_argument("value")
    p.set_defaults(fn=cmd_check)
    sub.add_parser("list").set_defaults(fn=cmd_list)
    a = ap.parse_args()
    sys.exit(a.fn(a))


if __name__ == "__main__":
    main()
