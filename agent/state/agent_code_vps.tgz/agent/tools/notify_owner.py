# -*- coding: utf-8 -*-
"""notify_owner.py - send the OWNER a short message (approval requests, alerts, questions).

The recipient is fixed: owner_numbers[0] in agent/config.json (WhatsApp) or OWNER_EMAIL (email). There is no --to option,
so this tool cannot be used to message anybody else.

How it chooses the channel (the owner's WhatsApp "24h window" rules):
  1. CRM says the owner wrote to us within the last 24h  -> WhatsApp free-form text.
  2. Otherwise (window closed, CRM unreachable, or the WhatsApp send fails) -> email via Resend to OWNER_EMAIL, and it
     says so. It NEVER sends a WhatsApp template to the owner (a cold template would cost money and risk the number).
Messages: 1-1000 characters, plain text, numbered options where the owner has to choose.

This tool can NOT be used to write an approval request. A message that contains "OK <5-character code>" (or YES / APPROVE /
NO / SKIP ... plus a code made of the approval-code letters) is refused: approval requests come only from propose.py, which
shows the owner EXACTLY what the code approves. Otherwise a free-text message could ask the owner to approve one thing
while the code belongs to another.

UNKNOWN OUTCOME: if the WhatsApp provider accepted the request but its answer never reached us (read timeout, dropped connection),
the message MAY have been delivered. It is counted against the owner-message limit, logged as owner_notify_unknown, and the email
fallback is still tried (a duplicate to the owner is harmless, silence is worse). If there is no email fallback the result says
"WhatsApp send timed out and MAY have been delivered - do not assume it failed". Exit codes: 0 delivered by some channel,
1 not delivered / refused, 3 nothing is known to have worked but the WhatsApp send MAY have arrived.

Unlike the tools that message leads, this one acts without --live, because its only possible effect is a message to the
owner. Use --dry-run to preview. Daily limit: config daily_caps.owner_notify (default 40) so a loop cannot spam the owner.

Usage:
  python agent/tools/notify_owner.py --text "Lead X replied: wants a price. 1) I hand off to you  2) I ask one more question"
  python agent/tools/notify_owner.py --text-file msg.txt [--dry-run]
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402
import send_email  # noqa: E402  (resend_send)
import wa  # noqa: E402  (Bsp client)

MAX_CHARS = 1000
WA_UNKNOWN_TEXT = "WhatsApp send timed out and MAY have been delivered - do not assume it failed"
EMAIL_UNKNOWN_TEXT = "email send timed out and MAY have been delivered - do not assume it failed"
# Approval requests (propose.py) must show everything the owner approves, so they may be longer. WhatsApp allows 4096.
MAX_APPROVAL_CHARS = 3500

# "OK K7M2Q", "yes k7m2q", "NO K7M2Q" ... : an approve / reject word followed by something that could be an approval code
# (5 characters of the code alphabet - see the CRM: no 0, O, 1, I, L). The CRM treats the owner's reply with such a word as a decision.
_APPROVAL_CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
_APPROVAL_LIKE = re.compile(
    r"\b(?:ok|yes|haan|approve|approved|no|skip|reject|nahi|cancel)\s+([" + _APPROVAL_CODE_ALPHABET + r"]{5})\b", re.IGNORECASE)


def owner_window_open():
    """(is_open, reason). Asks the CRM whether the owner wrote to us in the last 24h. Any doubt means closed."""
    try:
        d = C.crm_json("GET", "/owner-last-seen")
    except C.CrmError as e:
        return False, "WhatsApp window is closed or unknown: cannot ask the CRM (" + str(e) + ")"
    if d.get("within_24h") is not True:
        return False, "WhatsApp window is closed: the owner has not written to us in the last 24h"
    seen = C.parse_ts(d.get("last_inbound_at"), naive_tz=C.IST)
    if seen is not None and (C.now_ist() - seen).total_seconds() / 3600 > C.config()["template_window_hours"] - 0.25:
        return False, "WhatsApp window is closed: the CRM's last owner message is older than 24h"
    return True, "window open"


def owner_channel():
    """Where the owner is reached: "whatsapp" (default) or "telegram" (OWNER_CHANNEL in the env file / environment)."""
    return "telegram" if (C.get_env("OWNER_CHANNEL") or "").strip().lower() == "telegram" else "whatsapp"


def _send_telegram(text):
    """Plain text to the owner on Telegram. Returns (ok, detail, unknown) like _send_whatsapp."""
    import telegram_api as T  # noqa: E402  (same folder)
    return T.send_message(text)


def _send_whatsapp(text):
    """Free-form TEXT only (never a template). Returns (ok, detail, unknown).
    unknown=True means the provider never gave a usable answer, so the message MAY have been delivered."""
    owner = C.owner_phone()
    if not owner:
        return False, "no valid owner number in config.json owner_numbers", False
    try:
        b = wa.Bsp()
    except SystemExit as e:
        return False, str(e), False
    if not b.token or not b.phone:
        return False, "WhatsApp credentials missing in env", False
    code, res = b.call("POST", f"{b.base}/{b.ver}/{b.phone}/messages", body={
        "messaging_product": "whatsapp", "to": owner, "type": "text", "text": {"preview_url": False, "body": text}})
    wamid = ((res.get("messages") or [{}])[0].get("id")) if isinstance(res, dict) and isinstance(res.get("messages"), list) else None
    ok = 200 <= code < 300 and wamid
    if ok:
        return True, "sent on WhatsApp to " + C.mask_phone(owner), False
    if C.result_is_unknown(code, res, ok):
        return False, f"WhatsApp send has no usable answer (http {code}) " + b.scrub(res, 150), True
    return False, f"WhatsApp send failed (http {code}) " + b.scrub(res, 150), False


def _send_email(text, why_not_whatsapp, wa_unknown=False):
    """Returns (ok, detail, unknown). unknown=True: the email request got no usable answer, so it MAY have been delivered."""
    owner_email = C.norm_email(C.get_env("OWNER_EMAIL"))
    env = C.load_env()
    if not owner_email:
        if wa_unknown:
            return False, "no email fallback: OWNER_EMAIL is not set", False
        return False, "WhatsApp is not possible (" + why_not_whatsapp + ") and OWNER_EMAIL is not set: the owner was NOT notified", False
    if not env.get("RESEND_API_KEY") or not env.get("RESEND_FROM_EMAIL"):
        if wa_unknown:
            return False, "no email fallback: Resend is not configured", False
        return False, "WhatsApp is not possible (" + why_not_whatsapp + ") and Resend is not configured: the owner was NOT notified", False
    first_line = text.strip().splitlines()[0][:80]
    if wa_unknown:
        why_line = "(Sent by email as well because the WhatsApp send timed out and may or may not have reached you - you could get this twice.)"
    else:
        why_line = "(Sent by email because the WhatsApp 24h window with you is closed. Send any message to the business WhatsApp number to reopen it.)"
    body = text.strip() + "\n\n--\n" + why_line
    payload = {"from": f"{env.get('RESEND_FROM_NAME', 'Ivinfotech agent')} <{env['RESEND_FROM_EMAIL']}>", "to": [owner_email],
               "subject": "Ivinfotech agent: " + first_line, "text": body}
    scrub = C.Scrubber([env.get("RESEND_API_KEY", "")])
    code, res = send_email.resend_send(env, payload)
    ok = 200 <= code < 300 and res.get("id")
    if ok:
        if wa_unknown:
            return True, "sent by email to " + C.mask_email(owner_email) + " as a fallback. " + WA_UNKNOWN_TEXT + " (the owner may get it twice)", False
        return True, "sent by email to " + C.mask_email(owner_email) + " - WhatsApp not used. " + why_not_whatsapp, False
    if C.result_is_unknown(code, res, ok):
        return False, f"{EMAIL_UNKNOWN_TEXT} (http {code}) " + scrub(res, 150), True
    return False, f"email to the owner failed (http {code}) " + scrub(res, 150), False


def budget_left():
    """(has_budget, cap): how many messages per day the agent may send to the owner (config daily_caps.owner_notify)."""
    cap = int(C.config()["daily_caps"].get("owner_notify", 40))
    return C.used_today("owner_notify") < cap, cap


def record_outgoing(text, channel, allowed_codes=(), source=None):
    """Every message the owner is sent goes into agent/state/owner_outbox.jsonl, so the OTHER half of the system can see it: the
    owner has ONE WhatsApp chat but two workers write into it (the desktop operator and the fast lane). Found 2026-10-15: the owner
    answered "Haa, 3 bar video aaya" to a message only the desktop operator had sent, and the fast lane had no idea what he meant.
    source = who sent it ("fastlane", "fastlane-child" or "operator"); default: env AGENT_SOURCE, else "operator".
    Approval requests are not copied (they carry a code); best effort: a logging problem never blocks a message."""
    shown = "[approval request sent - see propose.py]" if allowed_codes else str(text)[:800]
    rec = {"ts": C.now_ist().isoformat(timespec="seconds"), "source": source or os.environ.get("AGENT_SOURCE") or "operator",
           "channel": channel, "text": shown}
    try:
        with open(C.STATE / "owner_outbox.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except OSError:
        pass


def notify(text, dry_run=False, max_chars=MAX_CHARS, allowed_codes=(), source=None):
    """Returns {"ok": bool, "channel": "whatsapp" | "email" | "none" | "dry-run", "detail": str}. Raises ValueError for a bad message.
    max_chars / allowed_codes are for propose.py only: it may send a longer message, and it may name the ONE approval code it
    just created. Any other "OK <code>"-looking text is refused (see the module docstring)."""
    text = str(text or "").strip()
    if not text or len(text) > max_chars:
        raise ValueError(f"owner message must be 1-{max_chars} characters (it is {len(text)})")
    allowed = {str(c).upper() for c in allowed_codes}
    for m in _APPROVAL_LIKE.finditer(text):
        if m.group(1).upper() not in allowed:
            raise ValueError("this message asks the owner to reply 'OK <code>'. Approval requests come only from propose.py "
                             "(it shows exactly what the code approves). Rephrase without 'OK' / 'yes' / 'no' followed by a 5-letter code.")
    if dry_run:
        return {"ok": True, "channel": "dry-run",
                "detail": "dry-run: would send on WhatsApp if the owner's 24h window is open, otherwise by email (no CRM or network used)"}
    has_budget, cap = budget_left()
    if not has_budget:
        return {"ok": False, "channel": "none", "detail": f"daily limit of {cap} owner messages reached; the owner was NOT notified"}
    via = owner_channel()
    # Telegram has no 24h window: the bot may write to the owner at any time. WhatsApp needs the window (the CRM tells).
    is_open, why = (True, "") if via == "telegram" else owner_window_open()
    wa_failure = why
    wa_unknown = False
    if is_open:
        ok, detail, wa_unknown = (_send_telegram if via == "telegram" else _send_whatsapp)(text)
        if ok:
            C.bump("owner_notify", counts_toward_total=False)
            C.log_event("owner_notified", via=via, chars=len(text))
            record_outgoing(text, via, allowed_codes, source)
            return {"ok": True, "channel": via, "detail": detail}
        wa_failure = detail
        if wa_unknown:
            # The message MAY be on the owner's phone. Count it against the daily limit like a delivered one (the safe side) and
            # still try the email below: a duplicate to the owner is harmless, silence is worse.
            C.bump("owner_notify", counts_toward_total=False)
            C.log_event("owner_notify_unknown", via=via, chars=len(text), detail=detail[:200])
    ok, detail, email_unknown = _send_email(text, wa_failure, wa_unknown)
    if ok:
        C.bump("owner_notify", counts_toward_total=False)
        C.log_event("owner_notified", via="email", chars=len(text), detail=detail[:200])
        record_outgoing(text, "email", allowed_codes, source)
    elif email_unknown:
        C.bump("owner_notify", counts_toward_total=False)  # the email MAY have arrived: count it, like a delivered one
        C.log_event("owner_notify_unknown", via="email", chars=len(text), detail=detail[:200])
    elif not wa_unknown:
        C.log_event("owner_notify_failed", via="none", chars=len(text), detail=detail[:200])
    if not ok and wa_unknown:
        # Nothing is KNOWN to have worked, but do not tell the caller "the owner was NOT notified": the WhatsApp message may be there.
        detail = WA_UNKNOWN_TEXT + " (" + detail + ")"
    return {"ok": bool(ok), "channel": "email" if ok else "none", "detail": detail, "unknown": bool(wa_unknown or email_unknown)}


def main():
    C.start()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--text")
    g.add_argument("--text-file")
    ap.add_argument("--dry-run", action="store_true", help="preview only: nothing is sent, no CRM call")
    a = ap.parse_args()
    text = Path(a.text_file).read_text(encoding="utf-8") if a.text_file else a.text
    try:
        r = notify(text, dry_run=a.dry_run)
    except ValueError as e:
        print("ERROR:", e)
        sys.exit(2)
    print(f"== notify_owner [{r['channel']}]")
    if r.get("unknown") and not r["ok"]:
        print(C.unknown_outcome_text("the provider did not answer in time", "the owner may already have received this message",
                                     "Do not assume it failed: ask the owner (chat/phone) whether it arrived before sending it again"))
    print("   " + r["detail"])
    print("-- message --")
    print(text.strip())
    sys.exit(0 if r["ok"] else (3 if r.get("unknown") else 1))


if __name__ == "__main__":
    main()
