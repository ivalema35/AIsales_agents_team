# -*- coding: utf-8 -*-
"""Shared helpers for the agent's tools: env loading, config, masking, event log, daily caps, suppression, duplicate guard.

Design rule: the tools are the agent's HANDS and the only place where safety is enforced in code
(dry-run by default, caps, suppression, send window, duplicate guard, no secrets in output).
The BRAIN (judgement) is Claude in the session — there is no LLM call anywhere in here.
"""
import datetime as dt
import errno
import hashlib
import hmac
import http.client
import json
import os
import re
import socket
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STATE = Path(os.environ.get("AGENT_STATE_DIR") or (ROOT / "agent" / "state"))
STATE.mkdir(parents=True, exist_ok=True)
# The agent's own settings file is agent/.env (CRM address + agent key + the provider keys the tools need).
# If it does not exist yet the old shared file backend/.env is used, so nothing breaks - but see crm_only_secret_names():
# the CRM's webhook secrets must never be in whichever file this is.
_AGENT_ENV = ROOT / "agent" / ".env"
ENV_FILE = Path(os.environ.get("AGENT_ENV_FILE") or (_AGENT_ENV if _AGENT_ENV.exists() else ROOT / "backend" / ".env"))
CONFIG_FILE = Path(os.environ.get("AGENT_CONFIG_FILE") or (ROOT / "agent" / "config.json"))
IST = dt.timezone(dt.timedelta(hours=5, minutes=30))

DEFAULT_CONFIG = {
    # "owner_notify" is NOT outbound to leads: it only limits how many messages per day the agent may send to the OWNER
    # (protects the owner's phone from a runaway loop). It does not count toward total_outbound.
    "daily_caps": {"total_outbound": 20, "email": 20, "whatsapp_template": 10, "owner_notify": 40,
                   # free-form replies to leads who wrote first. NOT part of total_outbound (that is the cold-outreach
                   # budget; replying to an interested lead must not be blocked by it), but capped on its own so a loop can't spam
                   "whatsapp_reply": 30},
    # at most this many free-form replies to ONE lead in 24 hours (a real conversation is a handful of messages)
    "reply_per_lead_per_day": 6,
    "send_window_ist": ["09:30", "19:00"],
    "duplicate_guard_days": 14,
    "template_window_hours": 24,
    # Autonomy stage (see CLAUDE.md). 1 = every live send needs an owner-approved code (SAFE DEFAULT, used when the key is
    # missing or unreadable). 2 = free-form replies to leads who wrote first inside the 24h window need no code.
    # Email, template sends and template creation ALWAYS need a code in the code below, whatever the stage.
    # Only the owner raises this, by editing config.json.
    "autonomy_stage": 1,
}


def utf8_stdout():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


# ---------- the CRM's own secrets must never be on this machine ----------
# These two let a caller forge "a message from the owner's phone" to the CRM webhook, i.e. approve anything. They belong ONLY
# in the CRM's .env on the server. If they are visible to the agent's tools (process environment or env file), a prompt-injected
# agent could read them and approve its own requests. So every tool refuses to run while they are present.
CRM_ONLY_SECRETS = ("WHATSAPP_APP_SECRET", "WHATSAPP_WEBHOOK_SECRET")


def crm_only_secret_names():
    """Names (never values) of CRM-only secrets that this machine can see, in the process environment or the env file."""
    in_file = load_env()
    return [n for n in CRM_ONLY_SECRETS if (os.environ.get(n) or "").strip() or (in_file.get(n) or "").strip()]


def start():
    """Call first thing in every tool's main(): UTF-8 output + the safety tripwire above."""
    utf8_stdout()
    found = crm_only_secret_names()
    if found:
        print("REFUSING TO RUN: " + ", ".join(found) + " found in the agent's environment / env file (" + str(ENV_FILE.name) + ").")
        print("These are the CRM webhook secrets. With them the owner's approval could be faked, so they must exist ONLY in the")
        print("CRM server's .env. Remove them from this machine's env file / environment (and rotate them if this file was shared).")
        sys.exit(3)


def require_override(flag, env_var):
    """Some flags exist only for the owner or for tests. They do nothing unless the matching environment variable is set,
    so the command line the owner sees in the permission prompt visibly contains the override. (A guard against slips and
    against a model that only copies commands; an operator who can set environment variables can still set it.)"""
    if os.environ.get(env_var) != "1":
        print(f"BLOCKED: {flag} is disabled. It is owner-only/test-only: set {env_var}=1 for this one command if you really mean it.")
        sys.exit(2)


def load_env():
    """KEY=VALUE file (never printed). Process environment overrides the file."""
    cfg = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                cfg[k.strip()] = v.strip().strip('"').strip("'")
    for k in list(cfg):
        if k in os.environ:
            cfg[k] = os.environ[k]
    return cfg


def config():
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if CONFIG_FILE.exists():
        try:
            user = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            for k, v in user.items():
                if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                    cfg[k].update(v)
                else:
                    cfg[k] = v
        except Exception as e:
            print("WARNING: config.json unreadable, using defaults:", e)
    return cfg


def get_env(name, default=""):
    """One setting: the real process environment first, then the env file. Never printed.
    (load_env() only lets the process environment override keys that are already in the file; this also accepts
    settings that exist only in the environment, like AGENT_CRM_URL / AGENT_API_KEY.)"""
    v = os.environ.get(name)
    if v and v.strip():
        return v.strip()
    return load_env().get(name, default)


def autonomy_stage():
    """1 unless config.json says a higher whole number. Anything unreadable means 1 (the safest stage)."""
    try:
        return max(1, int(config().get("autonomy_stage", 1)))
    except (TypeError, ValueError):
        return 1


def owner_phone():
    """The owner's WhatsApp number (91XXXXXXXXXX) from config.json owner_numbers[0], or None."""
    nums = config().get("owner_numbers") or []
    return norm_phone(nums[0]) if nums else None


def now_ist():
    return dt.datetime.now(IST)


def today_key():
    return now_ist().strftime("%Y-%m-%d")


# ---------- masking / scrubbing ----------
def mask_phone(p):
    d = re.sub(r"\D", "", str(p or ""))
    return ("+" + d[:2] + " ******" + d[-4:]) if len(d) >= 8 else "<phone>"


def mask_email(e):
    e = str(e or "")
    if "@" not in e:
        return "<email>"
    u, d = e.split("@", 1)
    return (u[:2] + "***@" + d) if u else "***@" + d


class Scrubber:
    def __init__(self, secrets=()):
        self.secrets = [s for s in secrets if s and len(str(s)) >= 6]

    def add(self, s):
        if s and len(str(s)) >= 6:
            self.secrets.append(str(s))

    def __call__(self, x, limit=700):
        s = x if isinstance(x, str) else json.dumps(x, ensure_ascii=False)
        for sec in self.secrets:
            s = s.replace(sec, "<redacted>")
        s = re.sub(r"[A-Za-z0-9+/=_:-]{40,}", "<redacted-long>", s)
        return s[:limit]


# ---------- event log ----------
def log_event(kind, **fields):
    rec = {"ts": now_ist().isoformat(timespec="seconds"), "kind": kind}
    rec.update(fields)
    with open(STATE / "events.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


# ---------- daily caps ----------
def _counters():
    p = STATE / "counters.json"
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def used_today(channel):
    return int(_counters().get(today_key(), {}).get(channel, 0))


def check_cap(channel):
    """Return (ok, reason). Both the channel cap and the total outbound cap must have headroom."""
    caps = config()["daily_caps"]
    ch_cap = int(caps.get(channel, 0))
    tot_cap = int(caps.get("total_outbound", 0))
    ch_used, tot_used = used_today(channel), used_today("total_outbound")
    if ch_used >= ch_cap:
        return False, f"daily cap reached for {channel}: {ch_used}/{ch_cap}"
    if tot_used >= tot_cap:
        return False, f"daily total outbound cap reached: {tot_used}/{tot_cap}"
    return True, f"{channel} {ch_used}/{ch_cap}, total {tot_used}/{tot_cap} used today"


def check_reply_cap():
    """Return (ok, reason) for ONE more free-form WhatsApp reply today. Replies have their own cap (config daily_caps.whatsapp_reply)
    and do not use up the cold-outreach total_outbound budget. Without a cap, a loop could message every lead who ever wrote."""
    cap = int(config()["daily_caps"].get("whatsapp_reply", 30))
    used = used_today("whatsapp_reply")
    if used >= cap:
        return False, f"daily cap reached for WhatsApp replies: {used}/{cap}"
    return True, f"WhatsApp replies {used}/{cap} used today"


def bump(channel, counts_toward_total=True):
    c = _counters()
    day = c.setdefault(today_key(), {})
    day[channel] = int(day.get(channel, 0)) + 1
    if counts_toward_total:
        day["total_outbound"] = int(day.get("total_outbound", 0)) + 1
    (STATE / "counters.json").write_text(json.dumps(c, indent=1), encoding="utf-8")


# ---------- send window ----------
def in_send_window():
    a, b = config()["send_window_ist"]
    t = now_ist().strftime("%H:%M")
    return a <= t <= b


# ---------- identifiers ----------
def norm_phone(s):
    """Indian numbers -> '91XXXXXXXXXX'. Returns None when it does not look like a valid mobile."""
    d = re.sub(r"\D", "", str(s or ""))
    if len(d) == 12 and d.startswith("91"):
        d = d[2:]
    elif len(d) == 11 and d.startswith("0"):
        d = d[1:]
    if len(d) == 10 and d[0] in "6789":
        return "91" + d
    return None


EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")


def norm_email(s):
    s = str(s or "").strip().lower()
    return s if EMAIL_RE.match(s) and "," not in s and ";" not in s and " " not in s else None


def _ident(value):
    p = norm_phone(value)
    return p if p else (norm_email(value) or str(value).strip().lower())


# ---------- suppression (do-not-contact) ----------
def _supp_path():
    return STATE / "suppression.txt"


def is_suppressed(value):
    key = _ident(value)
    p = _supp_path()
    if not p.exists():
        return False
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.split("|")[0] == key:
            return True
    return False


def list_suppressed():
    """All entries as dicts {key, reason, source, ts} (key is the raw phone/email; mask it before showing it)."""
    p = _supp_path()
    out = []
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            parts = line.split("|") + ["", "", ""]
            if parts[0]:
                out.append({"key": parts[0], "reason": parts[1], "source": parts[2], "ts": parts[3]})
    return out


def add_suppression(value, reason="", source="agent"):
    key = _ident(value)
    if is_suppressed(key):
        return False
    # the file is "key|reason|source|time" one entry per line, so line breaks and "|" must not appear inside a field
    reason = re.sub(r"[|\r\n]+", " ", str(reason))[:200]
    source = re.sub(r"[|\r\n]+", " ", str(source))[:50]
    with open(_supp_path(), "a", encoding="utf-8") as f:
        f.write(f"{key}|{reason}|{source}|{now_ist().isoformat(timespec='seconds')}\n")
    log_event("suppression_added", ident=mask_phone(key) if key.isdigit() else mask_email(key), reason=reason)
    return True


# ---------- duplicate guard ----------
def recent_send(channel, key, days=None):
    """The NEWEST record in sends.jsonl for this channel+key inside the window (a dict), or None.
    A record has status "unknown" when the provider never answered (see is_unknown_outcome): the message MAY have gone out,
    so it blocks a repeat exactly like a normal send does. Records without a status are normal successful sends."""
    days = config()["duplicate_guard_days"] if days is None else days
    p = STATE / "sends.jsonl"
    if not p.exists():
        return None
    cutoff = now_ist() - dt.timedelta(days=days)
    newest = None
    for line in p.read_text(encoding="utf-8").splitlines():
        try:
            r = json.loads(line)
            hit = r.get("channel") == channel and r.get("key") == key and dt.datetime.fromisoformat(r["ts"]) >= cutoff
        except Exception:
            continue
        if hit:
            newest = r
    return newest


def sent_recently(channel, key, days=None):
    return recent_send(channel, key, days) is not None


def duplicate_problem(rec, sent_text, what="message"):
    """The reason text for the duplicate guard, given the record recent_send() found.
    sent_text is the usual wording ('same email already sent in the last 14 days'). If the earlier attempt had an UNKNOWN
    outcome the text says so, because then 'already sent' would be a guess and the operator must check delivery first."""
    if rec and rec.get("status") == "unknown":
        return (f"an earlier attempt to send this same {what} (at {rec.get('ts', '?')}) has an UNKNOWN outcome: the provider did not "
                "answer, so it may already have been delivered - DO NOT retry. Check the delivery status / ask the recipient first")
    return sent_text


def record_send(channel, key, **meta):
    rec = {"ts": now_ist().isoformat(timespec="seconds"), "channel": channel, "key": key}
    rec.update(meta)
    with open(STATE / "sends.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def count_sends(channel, field, value, hours=24):
    """How many sends of this channel in the last `hours` have record_send(..., field=value). Used for 'max N replies per lead per day'."""
    p = STATE / "sends.jsonl"
    if not p.exists():
        return 0
    cutoff = now_ist() - dt.timedelta(hours=hours)
    n = 0
    for line in p.read_text(encoding="utf-8").splitlines():
        try:
            r = json.loads(line)
            if r.get("channel") == channel and r.get(field) == value and dt.datetime.fromisoformat(r["ts"]) >= cutoff:
                n += 1
        except Exception:
            continue
    return n


def send_key(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:16]


def paused():
    """Kill switch: if agent/state/PAUSED exists, every LIVE send is blocked (the owner's 'STOP ALL' creates it; delete it to resume)."""
    return (STATE / "PAUSED").exists()


def banner(live):
    return "LIVE" if live else "DRY-RUN (nothing is sent; add --live to perform)"


# ---------- safe HTTP helpers ----------
def _is_loopback_url(url):
    host = urllib.parse.urlsplit(str(url or "")).hostname or ""
    return host in ("127.0.0.1", "localhost", "::1")


def safe_base_url(url):
    """True for https:// URLs. Plain http:// is accepted ONLY when it points at this same computer AND AGENT_TEST_MODE=1 is set
    (the offline tests run a fake server there). So a bearer token or API key can never travel unencrypted to another machine,
    and nobody can quietly point the CRM / provider address at a fake local server: doing so needs a visible AGENT_TEST_MODE=1
    in the command line the owner is asked to allow."""
    url = str(url or "")
    return url.startswith("https://") or (
        os.environ.get("AGENT_TEST_MODE") == "1" and url.startswith("http://") and _is_loopback_url(url))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    """Never follow redirects: an Authorization header must not be forwarded to some other host."""

    def redirect_request(self, *a, **k):
        return None


def opener_for(url):
    handlers = [NoRedirect()]
    if _is_loopback_url(url):
        handlers.append(urllib.request.ProxyHandler({}))  # a local fake server must never go through a system proxy
    return urllib.request.build_opener(*handlers)


# ---------- "unknown outcome": the request may have reached the provider, but we did not read a complete answer ----------
# A WhatsApp / email provider can accept and DELIVER a message and still never get its HTTP answer back to us (slow gateway, dropped
# connection). That is NOT a failure we may retry: a retry would message the lead twice. Every send tool therefore sorts a failed
# call into one of three groups:
#   * clean success   -> 2xx with a message id
#   * definite failure -> the provider (or the network, before the request left) clearly said no: safe to fix and retry
#   * UNKNOWN          -> may already have been processed: treat as sent (counters, duplicate guard) and tell a human to check
# Rule of thumb: an error is "safe" ONLY when we positively know the request could not have been processed. Anything we do not
# recognise counts as unknown (the cost is one manual check; the cost of the other mistake is a double message to a lead).
DEFAULT_WA_TIMEOUT = 90       # seconds for one WhatsApp provider call
DEFAULT_RESEND_TIMEOUT = 40   # seconds for one Resend call


def http_timeout(default):
    """Seconds to wait for the WhatsApp / Resend provider. AGENT_HTTP_TIMEOUT overrides the default (the offline tests use 1).
    Anything that is not a sensible number is ignored, so a typo can never switch the timeout off."""
    try:
        v = float(get_env("AGENT_HTTP_TIMEOUT") or 0)
    except (TypeError, ValueError):
        return default
    return min(max(v, 0.1), 600.0) if v > 0 else default


# HTTP answers that still leave the outcome open: the server (or the gateway in front of it) gave up or crashed AFTER it got the
# request, so the message may have been handed on. 500 internal error, 502 bad gateway, 504 gateway timeout, 520/524 Cloudflare
# "unknown error" / "timeout after the connection was made". (Not here: 4xx = the provider refused the request; 503 and 521-523 /
# 525-526 = the service or the origin was not reached.)
UNKNOWN_HTTP_STATUSES = (500, 502, 504, 520, 524)

# OS error numbers that can only happen BEFORE a request was sent (nobody was listening / no route to the host).
_SAFE_ERRNO_NAMES = ("ECONNREFUSED", "ENETUNREACH", "EHOSTUNREACH", "ENETDOWN")
_SAFE_ERRNOS = {getattr(errno, n) for n in _SAFE_ERRNO_NAMES if hasattr(errno, n)} | {10061, 10051, 10065, 10050}  # + Windows (WSA) numbers


def unknown_http_status(code):
    try:
        return int(code) in UNKNOWN_HTTP_STATUSES
    except (TypeError, ValueError):
        return False


def is_unknown_outcome(exc):
    """Pure function. Given the exception a provider call raised, True when the request MAY already have been processed
    (a read/socket timeout, connection reset, remote disconnected, incomplete read, closed connection ...) and False only when the
    error clearly happened BEFORE the request could be processed (DNS lookup failed, connection refused, TLS certificate
    rejected, network or host unreachable, malformed address). Unrecognised errors count as unknown - see the rule above.

    About urllib: it wraps every error raised while it CONNECTS and WRITES the request (DNS, refused, TLS handshake, a connect
    timeout, a reset while sending ...) in a URLError, and lets errors raised while it WAITS FOR / READS the answer through
    unchanged. A URLError therefore means the request was never completely transmitted, so no server can have processed it;
    a bare timeout / reset / RemoteDisconnected / IncompleteRead means the request went out and the answer got lost."""
    if isinstance(exc, urllib.error.HTTPError):          # a complete HTTP answer: the status decides
        return unknown_http_status(exc.code)
    if isinstance(exc, urllib.error.URLError):           # failed while connecting / sending (see above): never processed
        return False
    if isinstance(exc, (socket.gaierror, socket.herror)):  # name lookup failed: nothing was sent
        return False
    if isinstance(exc, ssl.SSLCertVerificationError):    # the certificate was rejected during the handshake: nothing was sent
        return False
    if isinstance(exc, http.client.InvalidURL):          # malformed address, refused locally
        return False
    if isinstance(exc, (socket.timeout, TimeoutError)):  # includes "The read operation timed out"
        return True
    if isinstance(exc, ConnectionRefusedError):
        return False
    if isinstance(exc, (ConnectionError, http.client.HTTPException)):  # reset / aborted / broken pipe / RemoteDisconnected / IncompleteRead / BadStatusLine
        return True
    if isinstance(exc, ssl.SSLError):                    # other TLS errors (EOF, bad record ...) can happen after the request was written
        return True
    if isinstance(exc, OSError) and exc.errno in _SAFE_ERRNOS:
        return False
    return True


def result_is_unknown(code, res, ok):
    """After a provider call: True when it was NOT a clean success but the message may still have gone out.
    That is (a) the call itself said so (res['_unknown'], set by Bsp.call / resend_send for timeouts, resets, 5xx gateway errors)
    or (b) a 2xx answer without the message id we need: the provider accepted the request, we just cannot prove which message."""
    if ok:
        return False
    if isinstance(res, dict) and res.get("_unknown"):
        return True
    try:
        return 200 <= int(code) < 300
    except (TypeError, ValueError):
        return False


def unknown_cause(code):
    """Short plain-English cause for the UNKNOWN OUTCOME banner."""
    try:
        code = int(code)
    except (TypeError, ValueError):
        code = 0
    if 200 <= code < 300:
        return "the provider answered but gave back no message id"
    if code >= 500:
        return f"the provider (or its gateway) answered HTTP {code} while handling the request"
    return "the provider did not answer in time"


def unknown_outcome_text(cause="the provider did not answer in time", happened="the message may have been delivered",
                         advice="Check delivery status/ask the recipient first"):
    """The one clear sentence every send tool prints when the outcome is unknown (default wording = what the owner agreed)."""
    return f"UNKNOWN OUTCOME: {cause}; {happened}. DO NOT retry. {advice}"


def parse_ts(value, naive_tz=dt.timezone.utc):
    """ISO text -> timezone-aware datetime, or None if unreadable.
    Python 3.9's fromisoformat does not understand a trailing 'Z', so it is swapped for +00:00.
    A timestamp without a timezone is read in naive_tz (the caller picks the safe direction for its own check)."""
    try:
        t = dt.datetime.fromisoformat(str(value).strip().replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    return t if t.tzinfo else t.replace(tzinfo=naive_tz)


# ---------- action hash: "what exactly did the owner approve?" ----------
# canonical string = channel|recipient_normalised|subject_or_template|sha256(body_or_params_json)|extra
# An approval is stored in the CRM together with this hash, and a live send only works when the hash of what it is
# about to send is identical. So an approval for message A can never be used for another recipient/subject/content.
def _sha256(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _pipe_safe(s):
    # "|" separates the fields, so a "|" inside a field is escaped; otherwise two different messages could build the same string
    return str(s).replace("|", "\\|")


def action_hash(channel, recipient, subject_or_template, body_or_params, extra=""):
    if isinstance(body_or_params, str):
        body_text = body_or_params.replace("\r\n", "\n").strip()
    else:
        body_text = json.dumps(body_or_params, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    canonical = "|".join([
        _pipe_safe(channel), _pipe_safe(_ident(recipient)), _pipe_safe(subject_or_template), _sha256(body_text), _pipe_safe(extra)])
    return _sha256(canonical)


# One helper per live action. send_email.py / wa.py (to verify) and propose.py (to request) BOTH call these,
# so the two sides cannot drift apart.
def email_action_hash(to, subject, body_text, reply_to=""):
    return action_hash("email", to, subject, body_text, norm_email(reply_to) or "")


def wa_template_action_hash(to, template, lang, body_params, header_video_url, header_image_url, url_suffix):
    params = {"lang": lang or "en", "body_params": [str(p) for p in (body_params or [])],
              "header_video_url": header_video_url or "", "header_image_url": header_image_url or "",
              "url_suffix": url_suffix or ""}
    return action_hash("whatsapp_template", to, template, params)


def wa_reply_action_hash(to, text):
    return action_hash("whatsapp_reply", to, "reply", text)


def wa_create_action_hash(spec, header_path=None, header_bytes=None):
    """Creating a template has no recipient, so the 'recipient' slot is the fixed word 'waba'.
    The header file is represented by the sha256 of its bytes (not its path), so a different video needs a new approval.
    Pass header_bytes when the caller already read the file: the SAME bytes must then be uploaded, so the file cannot be swapped
    between 'what was hashed' and 'what was sent'."""
    clean = {k: v for k, v in spec.items() if not str(k).startswith("_")}
    clean.setdefault("category", "MARKETING")
    clean.setdefault("language", "en")
    extra = ""
    if header_path or header_bytes is not None:
        if header_bytes is None:
            header_bytes = Path(header_path).read_bytes()
        extra = hashlib.sha256(header_bytes).hexdigest()
        hdr = dict(clean.get("header") or {})
        hdr.pop("file", None)
        clean["header"] = hdr
    return action_hash("whatsapp_template_create", "waba", clean.get("name", ""), clean, extra)


# ---------- CRM client (agent API, contract v1) ----------
CRM_TIMEOUT = 15


class CrmError(Exception):
    """CRM not configured / unreachable / gave an unusable answer. The message never contains the API key."""


def crm_config():
    url = get_env("AGENT_CRM_URL").rstrip("/")
    key = get_env("AGENT_API_KEY")
    if not url or not key:
        raise CrmError("CRM is not configured (set AGENT_CRM_URL and AGENT_API_KEY)")
    if not safe_base_url(url):
        raise CrmError("AGENT_CRM_URL must start with https:// (plain http to localhost is accepted only in tests, with AGENT_TEST_MODE=1)")
    return url, key


def crm_call(method, path, body=None, timeout=CRM_TIMEOUT):
    """One request to the CRM. Returns (http_status, dict). Raises CrmError only when we got no usable HTTP answer
    (not configured, unreachable, timeout). 4xx/5xx come back as normal values so callers can tell 404 from 409."""
    url, key = crm_config()
    scrub = Scrubber([key])
    headers = {"Authorization": "Bearer " + key, "Accept": "application/json", "User-Agent": "ivinfotech-agent/1"}
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url + path, data=data, method=method, headers=headers)
    try:
        with opener_for(url).open(req, timeout=timeout) as r:
            code, raw = r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        code, raw = e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        raise CrmError("CRM unreachable: " + scrub(str(e), 200))
    try:
        parsed = json.loads(raw)
    except ValueError:
        parsed = {"_raw": scrub(raw, 200)}
    return code, (parsed if isinstance(parsed, dict) else {"_data": parsed})


def crm_json(method, path, body=None, timeout=CRM_TIMEOUT):
    """Like crm_call but any non-2xx answer becomes a CrmError with a plain explanation."""
    code, d = crm_call(method, path, body, timeout)
    if 200 <= code < 300:
        return d
    scrub = Scrubber([get_env("AGENT_API_KEY")])
    if code in (401, 403):
        why = "the CRM rejected the API key (check AGENT_API_KEY)"
    elif code == 503:
        why = "the agent API is switched off on the CRM (AGENT_API_KEY is not set there)"
    else:
        why = scrub(" ".join(str(x) for x in (d.get("error"), d.get("detail"), d.get("_raw")) if x) or "error", 200)
    raise CrmError(f"CRM answered HTTP {code}: {why}")


def crm_log_activity(lead_ref, channel, kind, summary, direction="out"):
    """Best-effort copy of a live action into the CRM ledger (agent_activity). Never raises and never blocks a send."""
    try:
        crm_json("POST", "/events", {"lead_ref": str(lead_ref or "-")[:200], "channel": channel, "direction": direction,
                                     "kind": kind, "summary": str(summary)[:500]}, timeout=5)
    except Exception:
        pass


# ---------- the approval gate for every LIVE send ----------
# Sequence used by every tool:  live_gate_check(...)  ->  (all local checks pass)  ->  consume_approval(...)  ->  send.
# The agent can only READ approvals here. Nothing in this file (or any tool) can set an approval to "approved":
# that happens only inside the CRM, when the owner's own WhatsApp message arrives through the verified webhook.
APPROVAL_CODE_RE = re.compile(r"^[A-Z0-9]{5}$")

_STATUS_TEXT = {
    "pending": "the owner has not approved this yet",
    "rejected": "the owner rejected this",
    "expired": "the approval has expired - ask again with propose.py",
    "consumed": "this approval code was already used (it works only once)",
}


def clean_approval_code(code):
    c = str(code or "").strip().upper()
    return c if APPROVAL_CODE_RE.match(c) else None


def flag_is_paused(v):
    """CRM flag value -> True / False / None (None = unreadable, which the caller treats as 'blocked')."""
    if v in (False, 0, "0", "false", "False", "no"):
        return False
    if v is True or v in (1, "1", "true", "True", "yes"):
        return True
    return None


def live_gate_check(code, expected_hash, approval_required=True):
    """Read-only. Returns a list of reasons the live send must be BLOCKED (empty list = cleared). Fails CLOSED:
    if the CRM cannot be reached or answers something unexpected, the send is blocked.
    approval_required=False (autonomy stage 2 replies) still checks the CRM pause flag, and still verifies a code if one is given."""
    problems = []
    try:
        http, flags = crm_call("GET", "/flags")
    except CrmError as e:
        return ["cannot check the CRM pause flag, so blocking (fail closed): " + str(e)]
    paused = flag_is_paused(flags.get("paused")) if http == 200 else None
    if paused is None:
        problems.append(f"CRM /flags gave no usable answer (HTTP {http}), so blocking (fail closed)")
    elif paused:
        problems.append("the owner paused all sending (CRM flag) - only the owner can resume, from WhatsApp")
    if not code and not approval_required:
        return problems
    c = clean_approval_code(code)
    if not c:
        problems.append("a live send needs --approval CODE (run propose.py; the owner approves it on WhatsApp)")
        return problems
    try:
        http, ap = crm_call("GET", f"/approvals/{c}")
    except CrmError as e:
        problems.append("cannot verify the approval, so blocking (fail closed): " + str(e))
        return problems
    if http == 404:
        problems.append("approval code not found")
        return problems
    if http != 200:
        problems.append(f"CRM could not check the approval (HTTP {http}), so blocking")
        return problems
    status = str(ap.get("status", "")).lower()
    if status != "approved":
        problems.append("approval is not usable: " + _STATUS_TEXT.get(status, f"status is '{status}', it must be 'approved'"))
    if not hmac.compare_digest(str(ap.get("action_hash", "")).lower().encode(), str(expected_hash).lower().encode()):
        problems.append("this approval was given for a different message/recipient/content (hash mismatch)")
    if status == "approved":
        # The CRM already reports a past expiry as 'expired'; this second look guards against a wrong answer.
        # A time without timezone is read as UTC: that can only make us MORE lenient by a few hours, and the CRM
        # still refuses to consume an expired code, so it stays safe.
        exp = parse_ts(ap.get("expires_at"))
        if exp is None:
            problems.append("approval has no readable expiry time, so blocking")
        elif exp <= dt.datetime.now(dt.timezone.utc):
            problems.append("approval has expired - ask again with propose.py")
    return problems


def consume_approval(code, expected_hash):
    """Spend the one-time code. Call this right BEFORE the send, never after. Returns (ok, reason).
    If this fails for any reason (including a timeout), the caller must NOT send; at worst a code is wasted and
    the operator asks again - that is deliberate (fail closed)."""
    c = clean_approval_code(code)
    if not c:
        return False, "no valid approval code to consume"
    try:
        http, d = crm_call("POST", f"/approvals/{c}/consume", {"action_hash": expected_hash})
    except CrmError as e:
        return False, "could not consume the approval, not sending: " + str(e)
    if http == 200 and d.get("status") == "consumed":
        return True, "approval consumed"
    return False, f"CRM refused to consume the approval (HTTP {http}: already used, expired or changed), not sending"


def inbound_for_phone(phone, limit=100):
    """The newest inbound WhatsApp items the CRM has from this phone (a list of dicts, newest first). Raises CrmError.
    The CRM filters by phone and sorts newest first; we filter again here, so a CRM that ignored the filter can never make
    us look at somebody else's messages."""
    items = crm_json("GET", f"/inbound?phone={urllib.parse.quote(phone)}&order=desc&limit={int(limit)}").get("items") or []
    mine = [it for it in items if isinstance(it, dict) and norm_phone(it.get("phone")) == phone]
    mine.sort(key=lambda it: int(it.get("id") or 0), reverse=True)
    return mine


# Items that do NOT prove "this lead wrote to us": a reaction (thumbs-up), an automatic out-of-office reply, and a STOP
# (somebody who says stop has not invited a conversation - they must never be contacted).
_NOT_A_REAL_MESSAGE_INTENTS = ("AUTO_REPLY", "STOP")


def last_inbound_from(phone):
    """Newest time the CRM saw a REAL inbound WhatsApp message from this phone (aware datetime) or None. Raises CrmError.
    Used at autonomy stage 2 to prove a free-form reply goes to a lead who really wrote first - the operator's own
    --inbound-at claim is not trusted. Reactions, auto-replies and STOP messages do not count.
    A time without timezone is read as IST here (the EARLIER reading), which can only make the 24h window stricter."""
    newest = None
    for it in inbound_for_phone(phone):
        if it.get("kind") == "reaction" or it.get("intent") in _NOT_A_REAL_MESSAGE_INTENTS:
            continue
        t = parse_ts(it.get("received_at"), naive_tz=IST)
        if t and (newest is None or t > newest):
            newest = t
    return newest


def crm_suppression_problems(value):
    """LIVE sends only. Asks the CRM whether this phone/email is on its do-not-contact list (STOP, unsubscribe, bounce - including
    a STOP the CRM saw that the operator never wrote into the local list). Returns a list of reasons to BLOCK (empty = fine).
    Fails CLOSED: if the CRM cannot answer, the send is blocked. A hit is also copied into the local suppression list, so the
    number stays blocked even when the CRM is offline later."""
    ident = _ident(value)
    param = "phone" if str(ident).isdigit() else "email"
    try:
        http, d = crm_call("GET", f"/suppressed?{param}={urllib.parse.quote(str(ident), safe='@')}")
    except CrmError as e:
        return ["cannot check the CRM do-not-contact list, so blocking (fail closed): " + str(e)]
    if http != 200 or not isinstance(d.get("suppressed"), bool):
        return [f"CRM do-not-contact check gave no usable answer (HTTP {http}), so blocking (fail closed)"]
    if d["suppressed"]:
        try:
            add_suppression(ident, "CRM do-not-contact: " + str(d.get("reason") or "?"), "crm")
        except Exception:
            pass
        return ["recipient is on the CRM do-not-contact list (STOP / unsubscribe / bounce) - never contact again"]
    return []


URL_IN_TEXT = re.compile(r"https?://[^\s<>\"']+", re.IGNORECASE)


def urls_in(*texts):
    """Every link found in the given texts, in order, without duplicates. The owner is shown this list so a link hidden at the end
    of a long message cannot slip through an approval."""
    seen, out = set(), []
    for t in texts:
        for u in URL_IN_TEXT.findall(str(t or "")):
            u = u.rstrip(").,;:!?")
            if u not in seen:
                seen.add(u)
                out.append(u)
    return out
