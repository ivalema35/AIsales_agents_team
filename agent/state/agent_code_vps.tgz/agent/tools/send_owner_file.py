# -*- coding: utf-8 -*-
"""send_owner_file.py - send the OWNER one video / image / PDF on WhatsApp (a file the agent made, with a short caption).

Like notify_owner.py: the recipient is fixed (owner_numbers[0] in agent/config.json), there is no --to option, so this tool cannot
message anybody else, and it needs no --live because its only possible effect is a message to the owner. It exists because
notify_owner.py can only send text, so "send me yesterday's video" had to be answered with a file path.

Safety rules enforced here:
  * only files inside agent/state/assets/ or agent/state/drafts/ (real path, symlinks resolved); nothing else on the PC can be sent
  * only these types, and the file's first bytes must really look like that type: .mp4 / .3gp video (16 MB max), .jpg / .jpeg / .png
    image (5 MB max), .pdf document (16 MB max)
  * only inside the owner's 24h WhatsApp window (the CRM says whether it is open); a closed window means NOTHING is sent (a media
    message outside the window would need a paid template). Unlike notify_owner.py there is no email fallback: a video does not fit in one.
  * counts against the same daily limit as notify_owner.py (config daily_caps.owner_notify)
  * the caption (max 900 chars) may not look like an approval request ("OK K7M2Q"): those come only from propose.py

How it works: step 1 uploads the file to the WhatsApp provider's media store (nothing is sent to anyone yet); step 2 sends one
message to the owner that points at that upload. If step 1 fails, nothing was sent. If step 2 gets no answer (timeout), the file MAY
have arrived: exit code 3, counted as sent, DO NOT retry before the owner confirms.

Exit codes: 0 sent / dry-run, 1 not delivered, 2 refused before anything was done, 3 unknown outcome (may have been delivered).

Usage:
  python agent/tools/send_owner_file.py --file agent/state/assets/riverview_heights/riverview_hi_kie_v3_final.mp4 --caption "Riverview Hindi video v3"
  python agent/tools/send_owner_file.py --file ... --dry-run          (checks everything, sends nothing, makes no network call)
"""
import argparse
import re
import sys
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402
import notify_owner as N  # noqa: E402  (window check, daily budget, approval-code look-alike filter)
import wa  # noqa: E402  (Bsp client)

MB = 1024 * 1024
MAX_CAPTION = 900
# extension -> (WhatsApp message type, MIME type, size limit in bytes)
TYPES = {
    ".mp4": ("video", "video/mp4", 16 * MB),
    ".3gp": ("video", "video/3gpp", 16 * MB),
    ".jpg": ("image", "image/jpeg", 5 * MB),
    ".jpeg": ("image", "image/jpeg", 5 * MB),
    ".png": ("image", "image/png", 5 * MB),
    ".pdf": ("document", "application/pdf", 16 * MB),
}


def allowed_roots():
    return [(C.STATE / "assets").resolve(), (C.STATE / "drafts").resolve()]


def looks_like(ext, head):
    """The first bytes must match the type the extension claims (a renamed file is refused)."""
    if ext in (".mp4", ".3gp"):
        return head[4:8] == b"ftyp"
    if ext in (".jpg", ".jpeg"):
        return head[:3] == b"\xff\xd8\xff"
    if ext == ".png":
        return head[:8] == b"\x89PNG\r\n\x1a\n"
    if ext == ".pdf":
        return head[:5] == b"%PDF-"
    return False


def check_file(path_text):
    """Returns (path, kind, mime, size). Raises ValueError with a plain reason when the file may not be sent."""
    raw = Path(str(path_text))
    try:
        p = (raw if raw.is_absolute() else C.ROOT / raw).resolve(strict=True)
    except (OSError, RuntimeError):
        raise ValueError("file not found")
    if not p.is_file():
        raise ValueError("not a file")
    if not any(root == p or root in p.parents for root in allowed_roots()):
        raise ValueError("only files inside agent/state/assets/ or agent/state/drafts/ can be sent")
    ext = p.suffix.lower()
    if ext not in TYPES:
        raise ValueError("file type %r is not allowed (allowed: %s)" % (ext, ", ".join(sorted(TYPES))))
    kind, mime, limit = TYPES[ext]
    size = p.stat().st_size
    if size == 0:
        raise ValueError("the file is empty")
    if size > limit:
        raise ValueError("the file is %.1f MB; WhatsApp allows at most %d MB for a %s" % (size / MB, limit // MB, kind))
    with open(p, "rb") as f:
        head = f.read(16)
    if not looks_like(ext, head):
        raise ValueError("the file's content does not look like a real %s file" % ext)
    return p, kind, mime, size


def check_caption(caption):
    cap = (caption or "").strip()
    if len(cap) > MAX_CAPTION:
        raise ValueError("caption is %d characters (max %d)" % (len(cap), MAX_CAPTION))
    if N._APPROVAL_LIKE.search(cap):
        raise ValueError("the caption looks like an approval request ('OK <code>'); approvals come only from propose.py")
    return cap


def multipart(fields, filename, mime, data):
    """A multipart/form-data body by hand (standard library only). Returns (bytes, content_type)."""
    boundary = "----ivagent" + uuid.uuid4().hex
    out = []
    for k, v in fields.items():
        out.append(('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n%s\r\n' % (boundary, k, v)).encode("utf-8"))
    safe_name = re.sub(r"[^A-Za-z0-9._-]", "_", filename)[:80]
    out.append(('--%s\r\nContent-Disposition: form-data; name="file"; filename="%s"\r\nContent-Type: %s\r\n\r\n' % (boundary, safe_name, mime)).encode("utf-8"))
    out.append(data)
    out.append(("\r\n--%s--\r\n" % boundary).encode("utf-8"))
    return b"".join(out), "multipart/form-data; boundary=" + boundary


def send_file_telegram(p, kind, mime, size, cap):
    """Same file to the owner on Telegram (no 24h window there). Returns {"ok", "unknown", "detail"} like send_file."""
    import telegram_api as T  # noqa: E402
    if not T.configured():
        return {"ok": False, "unknown": False, "detail": "Telegram is not configured (TELEGRAM_BOT_TOKEN / TELEGRAM_OWNER_ID)"}
    method, field = {"video": ("sendVideo", "video"), "image": ("sendPhoto", "photo"), "document": ("sendDocument", "document")}[kind]
    params = {"chat_id": T.owner_id()}
    if cap:
        params["caption"] = cap
    if kind == "video":
        params["supports_streaming"] = "true"
    code, res = T.call(method, params, file=(field, p.name, mime, p.read_bytes()), timeout=120)
    ok = T.ok(code, res)
    if ok or C.result_is_unknown(code, res, ok):
        C.bump("owner_notify", counts_toward_total=False)
        C.log_event("owner_file_sent" if ok else "owner_file_unknown", file_type=kind, name=p.name, mb=round(size / MB, 1), http=code, via="telegram")
        N.record_outgoing("[%s file %s%s] %s" % (kind, p.name, "" if ok else ", delivery unknown", cap), "telegram-file")
    if ok:
        return {"ok": True, "unknown": False, "detail": "sent %s (%s, %.1f MB) on Telegram" % (p.name, kind, size / MB)}
    if C.result_is_unknown(code, res, ok):
        return {"ok": False, "unknown": True, "detail": "the Telegram send has no usable answer (http %s) %s" % (code, res.get("_error", ""))}
    C.log_event("owner_file_failed", file_type=kind, name=p.name, http=code, via="telegram")
    return {"ok": False, "unknown": False, "detail": "Telegram refused the file (http %s) %s" % (code, str(res.get("description") or res.get("_error") or "")[:150])}


def send_file(path_text, caption="", dry_run=False):
    """Returns {"ok": bool, "detail": str, "unknown": bool}. Raises ValueError when the request itself is not allowed."""
    p, kind, mime, size = check_file(path_text)
    cap = check_caption(caption)
    if dry_run:
        return {"ok": True, "unknown": False, "detail": "dry-run: would send %s (%s, %.1f MB) to the owner on WhatsApp" % (p.name, kind, size / MB)}
    has_budget, cap_n = N.budget_left()
    if not has_budget:
        return {"ok": False, "unknown": False, "detail": "daily limit of %d owner messages reached; the owner was NOT sent the file" % cap_n}
    if N.owner_channel() == "telegram":
        return send_file_telegram(p, kind, mime, size, cap)
    is_open, why = N.owner_window_open()
    if not is_open:
        return {"ok": False, "unknown": False, "detail": why + ". Nothing was sent (a file needs the open window; ask the owner to write any message first)."}
    owner = C.owner_phone()
    if not owner:
        return {"ok": False, "unknown": False, "detail": "no valid owner number in config.json owner_numbers"}
    try:
        b = wa.Bsp()
    except SystemExit as e:
        return {"ok": False, "unknown": False, "detail": str(e)}
    if not b.token or not b.phone:
        return {"ok": False, "unknown": False, "detail": "WhatsApp credentials missing in env"}

    # step 1: upload (nothing reaches the owner yet; any failure here is safe to retry)
    body, ctype = multipart({"messaging_product": "whatsapp", "type": mime}, p.name, mime, p.read_bytes())
    code, res = b.call("POST", f"{b.base}/{b.ver}/{b.phone}/media", data=body, headers={"Content-Type": ctype})
    media_id = res.get("id") if isinstance(res, dict) else None
    if not (200 <= code < 300 and media_id):
        return {"ok": False, "unknown": False, "detail": "the provider did not accept the upload (http %s) %s. Nothing was sent." % (code, b.scrub(res, 200))}

    # step 2: the one message to the owner
    item = {"id": str(media_id)}
    if cap:
        item["caption"] = cap
    if kind == "document":
        item["filename"] = p.name[:80]
    code, res = b.call("POST", f"{b.base}/{b.ver}/{b.phone}/messages", body={
        "messaging_product": "whatsapp", "to": owner, "type": kind, kind: item})
    wamid = ((res.get("messages") or [{}])[0].get("id")) if isinstance(res, dict) and isinstance(res.get("messages"), list) else None
    ok = 200 <= code < 300 and bool(wamid)
    if ok or C.result_is_unknown(code, res, ok):
        C.bump("owner_notify", counts_toward_total=False)       # a possibly-delivered file counts like a delivered one
        C.log_event("owner_file_sent" if ok else "owner_file_unknown", file_type=kind, name=p.name, mb=round(size / MB, 1), http=code)
        N.record_outgoing("[%s file %s%s] %s" % (kind, p.name, "" if ok else ", delivery unknown", cap), "whatsapp-file")
    if ok:
        return {"ok": True, "unknown": False, "detail": "sent %s (%s, %.1f MB) on WhatsApp to %s" % (p.name, kind, size / MB, C.mask_phone(owner))}
    if C.result_is_unknown(code, res, ok):
        return {"ok": False, "unknown": True, "detail": "the file upload worked but the send has no usable answer (http %s) %s" % (code, b.scrub(res, 150))}
    C.log_event("owner_file_failed", file_type=kind, name=p.name, http=code)
    return {"ok": False, "unknown": False, "detail": "the provider refused the message (http %s) %s" % (code, b.scrub(res, 200))}


def main():
    C.start()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--file", required=True, help="a file inside agent/state/assets/ or agent/state/drafts/")
    ap.add_argument("--caption", default="", help="short text shown under the file (max 900 characters)")
    ap.add_argument("--dry-run", action="store_true", help="check everything, send nothing, no network call")
    a = ap.parse_args()
    try:
        r = send_file(a.file, a.caption, dry_run=a.dry_run)
    except ValueError as e:
        print("BLOCKED:", e)
        sys.exit(2)
    print("== send_owner_file [%s]" % ("dry-run" if a.dry_run else "whatsapp"))
    if r.get("unknown") and not r["ok"]:
        print(C.unknown_outcome_text("the provider did not answer in time", "the owner may already have received the file",
                                     "Ask the owner whether it arrived before sending it again"))
    print("   " + r["detail"])
    sys.exit(0 if r["ok"] else (3 if r.get("unknown") else 1))


if __name__ == "__main__":
    main()
