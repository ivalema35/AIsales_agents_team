# Stops the WhatsApp fast lane (if it is running) and starts it again, e.g. after its code changed.
# Usage (PowerShell):  powershell -NoProfile -ExecutionPolicy Bypass -File agent\fastlane\restart_fastlane.ps1
& (Join-Path $PSScriptRoot "stop_fastlane.ps1")
Start-Sleep -Seconds 2
& (Join-Path $PSScriptRoot "start_fastlane.ps1")
