# -*- coding: utf-8 -*-
"""operator_lane.py - the OPERATOR lane: the heartbeat's work done by ONE long-lived headless Claude instead of a new session per run.

Why: the scheduled heartbeat starts a brand-new Claude session every time. It has no memory of what it did a minute ago and every run
costs usage even when there is nothing to do. This program has no model inside. Every ~20 s it runs the cheap check
(heartbeat_check.collect: owner messages the fast lane did not handle, open lines in heartbeat_todo.md, lead replies) in plain code.
Only when there is work does it write ONE turn into a persistent Claude session (started on the first work, kept for hours, restarted
when its context gets big), so that session remembers its earlier jobs and idle time costs nothing.

Safety: the same locked-down session as the WhatsApp fast lane (dontAsk + allow-list, see fastlane.py), a little wider for working
files (agent/kb, agent/state/assets, heartbeat.json). It can NOT send to leads, deploy, read .env / secret files or edit the tools.
Work that needs more (Apify connector, Mobbin, ssh to the VPS, live sends) is tagged [needs-desktop] in heartbeat_todo.md for the
desktop operator (the scheduled task, now rare, `heartbeat_check.py --desktop`).

Loop protection: the same set of work lines is handed over at most `max_tries` times, `cooldown_seconds` apart; after that it is left
alone for `giveup_hours` and the owner is told once.

Run:     python agent/fastlane/operator_lane.py run          (start_fastlane.ps1 starts it together with the fast lane)
State:   agent/state/operator/  (alive.json, handed.json, recent.jsonl, operator.log, daemon.lock, child.pid, STOP)
Tests:   agent/tests/test_operator_lane.py
"""
import argparse
import hashlib
import json
import os
import queue
import sys
import threading
import time
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import fastlane as F  # noqa: E402  (Session, find_claude_cmd, lock helpers ...; also puts agent/tools on sys.path)
import common as C  # noqa: E402
import heartbeat_check as H  # noqa: E402
import notify_owner as N  # noqa: E402

OP = C.STATE / "operator"
OP.mkdir(parents=True, exist_ok=True)

DEFAULTS = {
    "poll_seconds": 20.0,
    "cooldown_seconds": 600,        # the same work is handed over again no sooner than this
    "max_tries": 3,
    "giveup_hours": 6,
    "turn_timeout_seconds": 1200,   # one job may take up to 20 minutes
    "stall_seconds": 600,           # Claude silent this long inside a turn -> restart it
    "model": "sonnet",
    "effort": "medium",
    "rotate_after_turns": 30,
    "rotate_after_hours": 12,
    "rotate_after_tokens": 150000,
    "respawn_seconds": 10.0,
}

# a little wider than the fast lane: working files the operator has to write
OP_ALLOW = F.ALLOW + [
    "Edit(./agent/state/heartbeat.json)", "Write(./agent/state/heartbeat.json)",
    "Write(./agent/state/assets/**)", "Edit(./agent/kb/**)", "Write(./agent/kb/**)",
]
OP_DENY = list(F.DENY) + ["Read(./agent/state/operator/**)"]


def now():
    return time.time()


def signature(work):
    return hashlib.sha1("\n".join(sorted(work)).encode("utf-8")).hexdigest()[:16]


class OperatorLane:
    def __init__(self, cfg=None):
        self.cfg = dict(DEFAULTS)
        self.cfg.update(cfg if cfg is not None else (C.config().get("operator") or {}))
        self.stop = threading.Event()
        self.session = None
        self.busy = False
        self.fresh = True                 # the next turn is the first of a new session (it also asks Claude to read memory.md)
        self.turn_started = 0.0
        self.turn_work = []
        self.session_tokens = 0
        self.paused_until = 0.0
        self.next_check = 0.0
        self.next_spawn = 0.0
        self.spawn_failures = 0
        self.attention_logged = 0.0
        self.handed = self.load_handed()
        self.last_work = 0

    # ---------------- small helpers ----------------
    def log(self, msg):
        path = OP / "operator.log"
        try:
            if path.exists() and path.stat().st_size > 2_000_000:
                os.replace(path, OP / "operator.log.1")
            with open(path, "a", encoding="utf-8") as f:
                f.write("%s %s\n" % (F.utcnow_iso(), msg))
        except OSError:
            pass
        if os.environ.get("FASTLANE_VERBOSE") == "1":
            print(msg, flush=True)

    def load_handed(self):
        try:
            return json.loads((OP / "handed.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def save_handed(self):
        cutoff = now() - 24 * 3600
        self.handed = {k: v for k, v in self.handed.items() if v.get("last", 0) > cutoff}
        F.atomic_write(OP / "handed.json", json.dumps(self.handed))

    def recent(self, n=6):
        try:
            return [json.loads(x) for x in (OP / "recent.jsonl").read_text(encoding="utf-8").splitlines()[-n:]]
        except (OSError, ValueError):
            return []

    def remember(self, work, result):
        rec = {"ts": F.utcnow_iso(), "work": [w[:120] for w in work][:5], "result": str(result)[:300]}
        try:
            with open(OP / "recent.jsonl", "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            lines = (OP / "recent.jsonl").read_text(encoding="utf-8").splitlines()
            if len(lines) > 60:
                F.atomic_write(OP / "recent.jsonl", "\n".join(lines[-30:]) + "\n")
        except OSError:
            pass

    def heartbeat_log(self, line):
        """The shared log the owner and the desktop operator read (same file the scheduled heartbeat writes to)."""
        try:
            with open(C.STATE / "heartbeat.log", "a", encoding="utf-8") as f:
                f.write("%s operator lane: %s\n" % (time.strftime("%Y-%m-%dT%H:%MZ", time.gmtime()), " ".join(str(line).split())[:300]))
        except OSError:
            pass

    # ---------------- the Claude session ----------------
    def spawn(self):
        cmd = F.find_claude_cmd()
        if not cmd:
            return self.spawn_failed("Claude Code program not found")
        env = os.environ.copy()
        env.pop("ANTHROPIC_API_KEY", None)
        env["PYTHONIOENCODING"] = "utf-8"
        env["AGENT_SOURCE"] = "operator"           # what it tells the owner is logged as the operator's (the fast lane shows it)
        sid = str(uuid.uuid4())
        try:
            if F.fake_claude_cmd():
                args = ["--session-id", sid]
            else:
                brief = (HERE / "operator_briefing.md").read_text(encoding="utf-8")
                args = F.claude_args(self.cfg, sid, brief, allow=OP_ALLOW, deny=OP_DENY)
            self.session = F.Session(cmd + args, str(C.ROOT), env)
        except Exception as e:
            return self.spawn_failed("%s: %s" % (type(e).__name__, str(e)[:160]))
        try:
            (OP / "child.pid").write_text(str(self.session.pid))
        except OSError:
            pass
        self.fresh, self.busy, self.session_tokens = True, False, 0
        self.log("claude started pid=%s session=%s" % (self.session.pid, sid[:8]))
        return True

    def spawn_failed(self, why):
        self.spawn_failures += 1
        wait = min(300.0, self.cfg["respawn_seconds"] * (2 ** min(self.spawn_failures - 1, 5)))
        self.next_spawn = now() + wait
        self.session = None
        self.log("cannot start claude (%s); retry in %.0fs" % (why, wait))
        return False

    def end_session(self, why):
        s, self.session = self.session, None
        self.busy = False
        if s:
            self.log("claude session ended: %s" % why)
            s.kill()

    def turn_text(self, work, notice):
        lines = []
        if self.fresh:
            lines.append("SESSION START. First read agent/memory.md and agent/state/heartbeat_todo.md (once; you keep this conversation afterwards).")
            rec = self.recent()
            if rec:
                lines.append("Context only, your most recent results from earlier sessions (oldest first):")
                for r in rec:
                    lines.append("- %s | %s => %s" % (r.get("ts", "")[:16], "; ".join(r.get("work", []))[:200], r.get("result", "")[:200]))
        lines.append("WORK ITEMS found by the cheap check:")
        lines += ["WORK: " + w for w in work]
        lines += ["NOTICE: " + n for n in notice]
        lines.append("Handle them as your briefing says. Final answer: one short line for the log, or NO_ACTION.")
        return "\n".join(lines)

    def start_turn(self, info, sig):
        rec = self.handed.get(sig, {"tries": 0})
        rec.update(tries=rec.get("tries", 0) + 1, last=now())
        self.handed[sig] = rec
        self.save_handed()
        try:
            self.session.send(self.turn_text(info["work"], info["notice"]))
        except Exception as e:
            self.log("could not write to claude: %s" % type(e).__name__)
            self.end_session("write failed")
            return
        self.fresh, self.busy, self.turn_started, self.turn_work = False, True, now(), list(info["work"])
        self.log("turn started: %d work item(s), try %d" % (len(info["work"]), rec["tries"]))

    def on_result(self, e):
        usage = e.get("usage") or {}
        keys = ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens")
        last_call = (usage.get("iterations") or [None])[-1]
        if isinstance(last_call, dict):
            self.session_tokens = sum(int(last_call.get(k) or 0) for k in keys)
        else:
            self.session_tokens = sum(int(usage.get(k) or 0) for k in keys) // max(1, int(e.get("num_turns") or 1))
        self.busy = False
        failed = bool(e.get("is_error")) or e.get("subtype") not in (None, "success")
        text = str(e.get("result") or "").strip()
        self.log("turn %s in %.0fs, %s tool calls..., %d tokens: %s" % ("FAILED" if failed else "done", now() - self.turn_started,
                                                                     int(e.get("num_turns") or 0), self.session_tokens, text[:120].replace("\n", " ")))
        self.remember(self.turn_work, ("FAILED: " if failed else "") + text)
        if failed:
            self.end_session("turn error")
        elif text and text.upper() != "NO_ACTION":
            self.heartbeat_log(text)

    def handle_event(self, e):
        self.session.last_event = now()
        t = e.get("type")
        if t == "result":
            self.on_result(e)
        elif t == "rate_limit_event":
            if (e.get("rate_limit_info") or {}).get("status") == "rejected":
                self.paused_until = now() + 1800
                self.log("usage limit reached: operator lane pauses for 30 minutes")

    def timeouts(self):
        if not (self.busy and self.session):
            return
        if now() - self.turn_started > self.cfg["turn_timeout_seconds"]:
            self.log("turn exceeded %ds: restarting claude" % self.cfg["turn_timeout_seconds"])
            self.end_session("turn timeout")
        elif now() - self.session.last_event > self.cfg["stall_seconds"]:
            self.log("claude silent for %ds inside a turn: restarting it" % (now() - self.session.last_event))
            self.end_session("stalled")

    def rotate_check(self):
        s = self.session
        if not s or self.busy:
            return
        if s.turns >= self.cfg["rotate_after_turns"] or now() - s.started > self.cfg["rotate_after_hours"] * 3600 \
                or self.session_tokens > self.cfg["rotate_after_tokens"]:
            self.end_session("rotation (turns=%d, tokens=%d)" % (s.turns, self.session_tokens))

    # ---------------- deciding when to work ----------------
    def check(self):
        self.next_check = now() + self.cfg["poll_seconds"]
        info = H.collect(desktop=False)
        if info["attention"]:
            if now() - self.attention_logged > 600:
                self.attention_logged = now()
                self.log("attention: " + info["attention"])
            return
        self.last_work = len(info["work"])
        if not info["work"]:
            return
        sig = signature(info["work"])
        rec = self.handed.get(sig)
        if rec:
            if rec.get("gaveup_until", 0) > now() or now() - rec.get("last", 0) < self.cfg["cooldown_seconds"]:
                return
            if rec.get("tries", 0) >= self.cfg["max_tries"]:
                rec["gaveup_until"] = now() + self.cfg["giveup_hours"] * 3600
                self.save_handed()
                self.tell_owner_gave_up(info["work"])
                return
        if self.session is None:
            if now() < self.next_spawn or os.environ.get("FASTLANE_NO_SPAWN"):
                return
            if not self.spawn():
                return
        self.start_turn(info, sig)

    def tell_owner_gave_up(self, work):
        self.log("gave up on: %s" % "; ".join(work)[:200])
        try:
            N.notify(F.tidy_outbound("Operator ne ye kaam %d baar try kiya par poora nahi hua, isliye ab rok diya: %s. Aap chaho to mujhse (desktop) karwa lo."
                                     % (self.cfg["max_tries"], "; ".join(w[:80] for w in work)[:300])), source="operator")
        except Exception as e:  # noqa: BLE001 - telling the owner must never crash the loop
            self.log("could not tell the owner: %s" % type(e).__name__)

    # ---------------- main loop ----------------
    def write_alive(self):
        s = self.session
        F.atomic_write(OP / "alive.json", json.dumps({
            "pid": os.getpid(), "ts": now(), "claude_pid": s.pid if s and s.alive() else None, "busy": bool(self.busy),
            "work_items": self.last_work, "session_tokens": self.session_tokens, "paused": now() < self.paused_until}))

    def run(self):
        F.kill_orphan(OP / "child.pid")
        self.log("operator lane starting (pid %d)" % os.getpid())
        last_alive = 0.0
        while not self.stop.is_set():
            if (OP / "STOP").exists():
                self.log("STOP file found: shutting down")
                break
            s = self.session
            if s is not None:
                try:
                    kind, payload = s.events.get(timeout=0.2)
                except queue.Empty:
                    kind = None
                if kind == "event":
                    self.handle_event(payload)
                elif kind == "exit":
                    self.log("claude exited with code %s" % payload)
                    lived = now() - s.started
                    self.end_session("exited %s" % payload)
                    if lived < 30:
                        self.spawn_failed("exited after %.0fs" % lived)
                self.timeouts()
                self.rotate_check()
            else:
                time.sleep(0.2)
            if not self.busy and now() >= self.next_check and now() >= self.paused_until:
                try:
                    self.check()
                except Exception as e:  # noqa: BLE001 - one bad check must not stop the lane
                    self.log("check failed: %s: %s" % (type(e).__name__, str(e)[:160]))
            if now() - last_alive >= 2:
                self.write_alive()
                last_alive = now()
        self.end_session("daemon stopping")
        for name in ("child.pid", "alive.json"):
            try:
                (OP / name).unlink()
            except OSError:
                pass
        self.log("operator lane stopped")


def main():
    C.start()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", nargs="?", default="run", choices=["run", "status"])
    a = ap.parse_args()
    if a.command == "status":
        try:
            d = json.loads((OP / "alive.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            print("operator lane: NOT running (no alive.json)")
            sys.exit(1)
        age = now() - float(d.get("ts", 0))
        print("operator lane: %s pid=%s busy=%s work_items=%s tokens=%s paused=%s" % (
            "RUNNING" if age < 15 else "STALE (%ds)" % age, d.get("pid"), d.get("busy"), d.get("work_items"), d.get("session_tokens"), d.get("paused")))
        sys.exit(0 if age < 15 else 1)
    lock = F.take_instance_lock(OP / "daemon.lock")
    if lock is None:
        print("operator lane is already running (daemon.lock is held). Not starting a second one.")
        sys.exit(1)
    try:
        (OP / "STOP").unlink()
    except OSError:
        pass
    lane = OperatorLane()
    try:
        lane.run()
    except KeyboardInterrupt:
        lane.end_session("interrupted")


if __name__ == "__main__":
    main()
