# -*- coding: utf-8 -*-
"""fastlane.py - the WhatsApp "fast lane": the owner writes on WhatsApp and gets an answer in seconds, not minutes.

What it is: a small always-on program on the office PC. It has NO model inside. It
  1. polls the CRM owner-inbox every few seconds (agent API, see agent/docs/AGENT_API_CONTRACT.md),
  2. writes every new message to a local ledger BEFORE acknowledging it to the CRM (so a crash never loses a message),
  3. answers STOP ALL / RESUME / "status" / "ping" itself, instantly and without a model,
  4. hands everything else to ONE long-lived, already-warm Claude Code process (headless, subscription login, stream-json),
  5. sends Claude's final answer to the owner on WhatsApp (through notify_owner.notify, so the 24h-window / email-fallback /
     daily-cap rules stay exactly the same), and tells the owner "got it" if the answer takes longer than a few seconds.

What it is NOT allowed to do: the Claude process it starts runs in "dontAsk" mode with a short allow-list (see CLAUDE_TOOLS /
ALLOW / DENY below): it can read, think, draft, run the CRM / notify / propose / suppress tools and dry-runs, but it can not
send anything to a lead, can not read the .env files or the webhook secret files, and can not edit the tools, config.json or
CLAUDE.md. Live sends stay behind the owner's own "OK CODE" on WhatsApp (verified by the CRM) AND the desktop operator.

Run:     python agent/fastlane/fastlane.py run            (see start_fastlane.ps1 / stop_fastlane.ps1)
Status:  python agent/fastlane/fastlane.py status
State:   agent/state/fastlane/  (alive.json, ledger.jsonl, recent.jsonl, fastlane.log, daemon.lock, child.pid)
Tests:   agent/tests/test_fastlane.py (a fake CRM + fake BSP + a fake Claude; nothing real is touched)
"""
import argparse
import collections
import json
import os
import queue
import random
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "tools"))
import common as C  # noqa: E402  (binds STATE / ENV / CONFIG from the environment on import)
import notify_owner as N  # noqa: E402

VERSION = 1
FL = C.STATE / "fastlane"
FL.mkdir(parents=True, exist_ok=True)

DEFAULTS = {
    "poll_seconds": 3.0,            # pause between two looks at the CRM inbox
    "poll_timeout": 6,              # seconds for one CRM request (the stock tools use 15)
    "ack_after_seconds": 18,        # no answer yet after this long -> send a short "got it" text (real turns take 4-14 s; at 10 s the
                                    # "got it" often arrived together with the answer - seen in the owner's first live chat)
    "turn_timeout_seconds": 300,    # one owner request may use at most this long in the fast lane
    "stall_seconds": 150,           # Claude silent for this long inside a turn -> restart it
    "model": "sonnet",
    "effort": "medium",
    "rotate_after_turns": 40,       # start a fresh Claude session after this many turns (context stays small and fast)
    "rotate_after_hours": 12,
    "rotate_after_tokens": 150000,  # ... or when one request already carries this many prompt tokens
    "max_batch": 10,                # owner messages handed to Claude in one turn
    "max_tries": 2,                 # a message that failed this many times is given up (and the owner is told)
    "stale_minutes": 10,            # older than this when first seen: Claude is told how old it is
    "respawn_seconds": 5.0,         # first wait before restarting a Claude that failed to start / crashed (doubles each time, max 120)
}

# ---- what the child Claude process may use (deterministic: anything not listed is refused, nobody is asked) ----
CLAUDE_TOOLS = "Bash,Read,Glob,Grep,Edit,Write,Task,WebSearch,WebFetch"
ALLOW = [
    "Read", "Glob", "Grep", "WebSearch", "WebFetch", "Task",
    "Edit(./agent/memory.md)", "Edit(./agent/state/heartbeat_todo.md)", "Write(./agent/state/heartbeat_todo.md)",
    "Edit(./agent/state/drafts/**)", "Write(./agent/state/drafts/**)", "Edit(./agent/state/leads/**)", "Write(./agent/state/leads/**)",
    "Bash(python agent/tools/crm.py *)", "Bash(python agent/tools/notify_owner.py *)", "Bash(python agent/tools/propose.py *)",
    "Bash(python agent/tools/suppress.py *)", "Bash(python agent/tools/wa.py *)", "Bash(python agent/tools/send_email.py *)",
    "Bash(python agent/tools/send_owner_file.py *)",     # a video / image / PDF to the OWNER only (fixed recipient, assets/drafts folders only)
]
DENY = [
    # secrets and the owner-only files
    "Read(./agent/.env)", "Read(./backend/.env)", "Read(./agent/state/.webhook_secret)", "Read(./agent/state/WEBHOOK_URL_TO_PASTE.txt)",
    "Read(./agent/state/.server_env_additions)", "Read(./agent/state/fastlane/**)",
    "Edit(./agent/config.json)", "Write(./agent/config.json)", "Edit(./CLAUDE.md)", "Write(./CLAUDE.md)",
    "Edit(./agent/tools/**)", "Write(./agent/tools/**)", "Edit(./agent/fastlane/**)", "Write(./agent/fastlane/**)",
    "Edit(./.claude/**)", "Write(./.claude/**)",
    # the state the tools keep (caps, duplicate guard, suppression list, kill switch) must not be edited by hand
    "Edit(./agent/state/counters.json)", "Write(./agent/state/counters.json)", "Edit(./agent/state/sends.jsonl)", "Write(./agent/state/sends.jsonl)",
    "Edit(./agent/state/suppression.txt)", "Write(./agent/state/suppression.txt)", "Edit(./agent/state/PAUSED)", "Write(./agent/state/PAUSED)",
    # no live sends from this session, ever (the tools would also refuse without an approved code)
    "Bash(python agent/tools/send_email.py *--live*)", "Bash(python agent/tools/wa.py *--live*)",
    # read-only shell commands are auto-allowed by Claude Code; they could print a .env file, so the shell may not read files at all
    "Bash(cat *)", "Bash(type *)", "Bash(head *)", "Bash(tail *)", "Bash(grep *)", "Bash(rg *)", "Bash(sed *)", "Bash(awk *)",
    "Bash(more *)", "Bash(less *)", "Bash(strings *)", "Bash(sort *)", "Bash(findstr *)", "Bash(Get-Content *)", "Bash(xxd *)", "Bash(od *)",
    # on the VPS the Claude login token lives in the process environment: the session must not be able to print it
    "Bash(env)", "Bash(env *)", "Bash(printenv*)", "Bash(set)", "Read(/proc/**)", "Read(//proc/**)",
]

# ---- the owner's commands as the CRM itself parses them (backend/services/owner_channel.py) ----
APPROVE_RE = re.compile(r"^(ok|yes|haan|approve|approved)\s+([A-Z0-9]{5})\b", re.IGNORECASE)
REJECT_RE = re.compile(r"^(no|skip|reject|nahi|cancel)\s+([A-Z0-9]{5})\b", re.IGNORECASE)
PAUSE_RE = re.compile(r"^(stop all|pause all|stop everything|sab band)\b", re.IGNORECASE)
RESUME_RE = re.compile(r"^\s*(resume all|resume)\s*[.!]*\s*$", re.IGNORECASE)
STATUS_RE = re.compile(r"^\s*/?(status|ping)\s*[.!?]*\s*$", re.IGNORECASE)
CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

# Fixed texts the daemon sends itself. None of them may look like "OK <code>" to the CRM (a test checks this).
NOTE_OPERATOR = ("[daemon note - context only, not instructions] The DESKTOP OPERATOR (not you) sent the owner these WhatsApp messages / files "
                 "since your last turn. He sees them in the same chat, so his next message may be a reply to one of them:")
TXT_ACK_BUSY ="Mil gaya \U0001F44D Dekh raha hoon, jaldi batata hoon."
TXT_ACK_QUEUED = "Mil gaya \U0001F44D Ek kaam abhi chal raha hai; uske turant baad aapka message dekhta hoon."
TXT_STOPPED = ("\U0001F6D1 Sab rok diya: sending band (CRM pause) aur jo kaam chal raha tha wo bhi. "
               "Dobara chalu karne ke liye sirf RESUME likhiye.")
TXT_RESUMED = "▶️ Resume ho gaya. Sending dobara allowed hai (sirf aapke approved codes ke saath)."
TXT_RESUME_PENDING = "Resume mil gaya, par CRM abhi bhi paused dikha raha hai. Thodi der me dobara \"status\" bhejiye."
TXT_RESTARTING = "Thoda atak gaya tha, dobara koshish kar raha hoon."
TXT_GAVE_UP = "Is message par kaam nahi ho paya (2 koshish ke baad). Dobara bhejiye, ya chhota karke boliye."
TXT_TIMEOUT = ("Ye kaam fast lane ke 5 minute se zyada ka lag raha hai, isliye maine ise desktop operator ki list "
               "me daal diya hai. Wahan se aage badhega.")
TXT_NO_ANSWER = "Mujhse is par jawab nahi ban paya. Kya aap thoda alag tarah se likh sakte hain?"
TXT_CLAUDE_LOGIN = ("Claude ka login/subscription check fail ho raha hai, isliye main abhi jawab nahi de paa raha. "
                    "Office PC par Claude app khol kar login dekhna padega.")
TXT_CLAUDE_LIMIT = "Claude ki usage limit lag gayi hai; limit khulte hi fast lane wapas jawab dene lagega."


def now():
    return time.time()


def utcnow_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def atomic_write(path, text):
    tmp = Path(str(path) + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    for _ in range(5):
        try:
            os.replace(tmp, path)
            return
        except OSError:
            time.sleep(0.05)


def tidy_inbound(text, limit=2000):
    """Owner text on its way to Claude: control characters out, length capped, continuation lines indented so each message
    stays visibly separate from the next tag."""
    s = CTRL_RE.sub(" ", str(text or "")).strip()
    if len(s) > limit:
        s = s[:limit] + " ...[cut]"
    return s.replace("\n", "\n  ")


def tidy_outbound(text, limit=950):
    """Claude's answer made safe for WhatsApp: no code fences, **bold** -> *bold*, never an 'OK ABCDE'-looking phrase
    (the CRM would read that as an approval), at most `limit` characters."""
    s = str(text or "").replace("```", "").strip()
    s = re.sub(r"\*\*(.+?)\*\*", r"*\1*", s)
    s = N._APPROVAL_LIKE.sub(lambda m: m.group(0)[:m.start(1) - m.start(0)].rstrip() + ", " + m.group(1), s)
    if len(s) > limit:
        cut = s[:limit - 40]
        for sep in ("\n", ". ", " "):
            i = cut.rfind(sep)
            if i > limit // 2:
                cut = cut[:i + (1 if sep == ". " else 0)]
                break
        s = cut.rstrip() + " ... (aur detail chahiye to boliye)"
    return s


# --------------------------------------------------------------------------------------------------
# The ledger: every owner message we took in, durable on disk (one JSON object per line, append-only)
#   recv  -> we saw it and stored it        try -> we handed it to Claude (counts the attempts)
#   acked -> the CRM knows we have it       done -> it is finished (answered, handled, ignored or given up)
# A message is "pending" until it is done. After a crash / restart, pending messages are handled again (at-least-once).
# --------------------------------------------------------------------------------------------------
class Ledger:
    def __init__(self, path):
        self.path = Path(path)
        self.lock = threading.Lock()
        self.items = {}      # wamid -> dict(id, kind, text, received_at, seen, tries, acked, done)
        self._load()

    def _load(self):
        if not self.path.exists():
            return
        for line in self.path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                e = json.loads(line)
            except ValueError:
                continue
            w = e.get("wamid")
            if not w:
                continue
            if e.get("ev") == "recv":
                self.items[w] = {"id": e.get("id"), "kind": e.get("kind"), "text": e.get("text"), "received_at": e.get("received_at"),
                                 "seen": e.get("seen"), "tries": 0, "acked": False, "done": None}
            elif w in self.items:
                it = self.items[w]
                if e["ev"] == "try":
                    it["tries"] += 1
                elif e["ev"] == "acked":
                    it["acked"] = True
                elif e["ev"] == "done":
                    it["done"] = e.get("how") or "done"
        self._compact()

    def _compact(self):
        """Keep the file small: drop finished messages older than 3 days (the file is rewritten only when it grew large)."""
        try:
            if self.path.stat().st_size < 400_000:
                return
        except OSError:
            return
        cutoff = now() - 3 * 86400
        keep = {w: it for w, it in self.items.items() if not it["done"] or (it.get("seen") or 0) > cutoff}
        lines = []
        for w, it in keep.items():
            lines.append(json.dumps({"ev": "recv", "wamid": w, "id": it["id"], "kind": it["kind"], "text": it["text"],
                                     "received_at": it["received_at"], "seen": it["seen"]}, ensure_ascii=False))
            lines += [json.dumps({"ev": "try", "wamid": w})] * it["tries"]
            if it["acked"]:
                lines.append(json.dumps({"ev": "acked", "wamid": w}))
            if it["done"]:
                lines.append(json.dumps({"ev": "done", "wamid": w, "how": it["done"]}))
        atomic_write(self.path, "\n".join(lines) + ("\n" if lines else ""))
        self.items = keep

    def _append(self, rec):
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())

    def known(self, wamid):
        return wamid in self.items

    def add(self, wamid, item):
        with self.lock:
            rec = {"id": item.get("id"), "kind": item.get("kind"), "text": item.get("text"),
                   "received_at": item.get("received_at"), "seen": now()}
            self._append(dict(rec, ev="recv", wamid=wamid))
            self.items[wamid] = dict(rec, tries=0, acked=False, done=None)

    def mark(self, wamid, ev, how=None):
        with self.lock:
            it = self.items.get(wamid)
            if not it:
                return
            if ev == "try":
                it["tries"] += 1
            elif ev == "acked":
                if it["acked"]:
                    return
                it["acked"] = True
            elif ev == "done":
                if it["done"]:
                    return
                it["done"] = how or "done"
            rec = {"ev": ev, "wamid": wamid}
            if how:
                rec["how"] = how
            self._append(rec)

    def pending(self):
        return [(w, it) for w, it in self.items.items() if not it["done"]]


# --------------------------------------------------------------------------------------------------
# Finding and starting the Claude Code program
# --------------------------------------------------------------------------------------------------
def fake_claude_cmd():
    """Tests only: a stand-in for Claude Code. Honoured ONLY together with AGENT_TEST_MODE=1, so a stray variable can never
    start the real program without its safety flags."""
    if os.environ.get("AGENT_TEST_MODE") == "1" and os.environ.get("FASTLANE_CLAUDE_CMD"):
        return json.loads(os.environ["FASTLANE_CLAUDE_CMD"])
    return None


def find_claude_cmd():
    """List of arguments that start Claude Code. Newest bundled version of the desktop app first (its folder name changes
    on every app update, so this is looked up again on every start)."""
    if fake_claude_cmd():
        return fake_claude_cmd()
    explicit = os.environ.get("FASTLANE_CLAUDE_EXE", "")
    if explicit and Path(explicit).exists():
        return [explicit]
    found = []
    for root in claude_search_roots():
        for p in (root / "Claude" / "claude-code").glob("*/*/claude.exe"):
            try:
                ver = tuple(int(x) for x in p.parent.parent.name.split("."))
            except ValueError:
                ver = (0,)
            found.append((ver, str(p)))
    if found:
        return [sorted(found)[-1][1]]
    home = Path(os.environ.get("USERPROFILE") or Path.home())
    for p in (home / ".local" / "bin" / "claude.exe", home / ".claude" / "local" / "claude.exe"):
        if p.exists():
            return [str(p)]
    which = shutil.which("claude")
    return [which] if which else None


def claude_search_roots():
    """Folders that may contain Claude\\claude-code\\<version>\\<hash>\\claude.exe. The desktop app is a Store (MSIX) app: a
    program started from its built-in terminal can see %APPDATA% redirected into the app's package folder, so the plain
    %APPDATA% is not enough (found on 2026-10-15: Python there saw no 'Claude' folder under %APPDATA% at all)."""
    home = Path(os.environ.get("USERPROFILE") or Path.home())
    roots = []
    if os.environ.get("APPDATA"):
        roots.append(Path(os.environ["APPDATA"]))
    roots.append(home / "AppData" / "Roaming")
    local = Path(os.environ.get("LOCALAPPDATA") or (home / "AppData" / "Local"))
    roots += sorted((local / "Packages").glob("Claude_*/LocalCache/Roaming"))
    seen, out = set(), []
    for r in roots:
        if str(r).lower() not in seen:
            seen.add(str(r).lower())
            out.append(r)
    return out


def claude_args(cfg, session_id, briefing, allow=None, deny=None):
    """Everything after the program name. One persistent session: JSON lines in, JSON lines out.
    allow / deny default to this lane's lists; operator_lane.py passes its own (a little wider) lists."""
    return ["-p", "--input-format", "stream-json", "--output-format", "stream-json", "--verbose",
            "--model", cfg["model"], "--effort", cfg["effort"], "--session-id", session_id,
            "--permission-mode", "dontAsk", "--permission-prompts", "none",
            "--tools", CLAUDE_TOOLS, "--strict-mcp-config", "--disable-slash-commands", "--setting-sources", "project",
            "--allowedTools", ",".join(ALLOW if allow is None else allow), "--disallowedTools", ",".join(DENY if deny is None else deny),
            "--append-system-prompt", briefing]


class Session:
    """One Claude Code child process. Reader threads turn its output into events on self.events:
    ("event", dict) for every JSON line, ("stderr", str), ("exit", returncode)."""

    def __init__(self, cmd, cwd, env):
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        self.p = subprocess.Popen(cmd, cwd=cwd, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  text=True, encoding="utf-8", errors="replace", bufsize=1, creationflags=flags)
        self.events = queue.Queue()
        self.started = now()
        self.last_event = now()
        self.turns = 0
        self.stderr_tail = collections.deque(maxlen=15)
        threading.Thread(target=self._read_out, daemon=True).start()
        threading.Thread(target=self._read_err, daemon=True).start()

    def _read_out(self):
        for line in self.p.stdout:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if isinstance(e, dict):
                self.events.put(("event", e))
        self.events.put(("exit", self.p.wait()))

    def _read_err(self):
        for line in self.p.stderr:
            self.stderr_tail.append(line.strip()[:300])
            self.events.put(("stderr", line.strip()[:300]))

    @property
    def pid(self):
        return self.p.pid

    def alive(self):
        return self.p.poll() is None

    def send(self, text):
        msg = {"type": "user", "message": {"role": "user", "content": text}}
        self.p.stdin.write(json.dumps(msg, ensure_ascii=False) + "\n")
        self.p.stdin.flush()
        self.turns += 1

    def kill(self):
        """Stop the child and everything it started (on Windows taskkill /T takes the whole tree)."""
        if self.alive():
            try:
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(self.p.pid), "/T", "/F"], capture_output=True, timeout=15)
                else:
                    self.p.kill()
            except Exception:
                try:
                    self.p.kill()
                except Exception:
                    pass
        for stream in (self.p.stdin, self.p.stdout, self.p.stderr):
            try:
                stream.close()
            except Exception:
                pass


def kill_orphan(pidfile):
    """If a previous daemon was killed hard, its Claude child may still run. Kill it (only if the pid still looks like ours)."""
    try:
        pid = int(Path(pidfile).read_text().strip())
    except Exception:
        return
    try:
        if os.name == "nt":
            out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"], capture_output=True, text=True, timeout=15).stdout.lower()
            if "claude" in out or "python" in out:
                subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, timeout=15)
        else:
            os.kill(pid, 9)
    except Exception:
        pass
    try:
        Path(pidfile).unlink()
    except OSError:
        pass


def take_instance_lock(path):
    """Only one daemon at a time (two would answer every message twice). The lock disappears by itself when the process dies."""
    f = open(path, "a+")
    try:
        if os.name == "nt":
            import msvcrt
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        return None
    return f


# --------------------------------------------------------------------------------------------------
# The daemon
# --------------------------------------------------------------------------------------------------
class Daemon:
    TAG = "WA"                            # how Claude sees an owner message: [WA#12 text] ... (the Telegram lane uses TG)
    BRIEFING = "briefing.md"

    def __init__(self, cfg=None):
        self.cfg = dict(DEFAULTS)
        self.cfg.update((cfg if cfg is not None else (C.config().get("fastlane") or {})))
        self.ledger = Ledger(FL / "ledger.jsonl")
        self.incoming = queue.Queue()     # items the poller found, for the main loop
        self.outbox = queue.Queue()       # texts for the owner, for the sender thread
        self.stop = threading.Event()
        self.started = now()
        self.session = None
        self.ready = False                # the session finished its start-up turn
        self.startup_turn = False
        self.busy = False
        self.batch = []                   # [(wamid, item)] handed to Claude in the running turn
        self.pending = collections.deque()  # [(wamid, item)] waiting for the next turn
        self.turn_started = 0.0
        self.turn_tools = 0
        self.last_ack_text = 0.0
        self.acked_text_for = set()       # wamids that already got a "got it" text
        self.last_poll_ok = 0.0
        self.poll_failures = 0
        self.spawn_failures = 0
        self.next_spawn = 0.0
        self.alerts = {}
        self.sent_owner = 0
        self.session_tokens = 0
        self.usage = None                 # last Claude usage reading: {"window", "used" (0..1), "resets_at" (epoch)}
        self.outbox_pos = 0               # how far we have read agent/state/owner_outbox.jsonl (what the desktop operator sent the owner)
        self.recent_path = FL / "recent.jsonl"
        self.send_lock = threading.Lock()

    # ---------------- logging / alerts ----------------
    def log(self, msg):
        line = f"{utcnow_iso()} {msg}"
        path = FL / "fastlane.log"
        try:
            if path.exists() and path.stat().st_size > 2_000_000:
                os.replace(path, FL / "fastlane.log.1")
            with open(path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass
        if os.environ.get("FASTLANE_VERBOSE") == "1":
            print(line, flush=True)

    def say(self, text, kind="reply", wamids=(), once_key=None, every=0, received=None):
        """Queue a text for the owner (the sender thread does the slow network part)."""
        if once_key:
            if now() - self.alerts.get(once_key, 0) < every:
                return
            self.alerts[once_key] = now()
        self.outbox.put({"text": text, "kind": kind, "wamids": list(wamids), "received": received, "queued": now()})

    # ---------------- sender thread ----------------
    def sender_loop(self):
        while True:
            job = self.outbox.get()
            if job is None:
                return
            try:
                self._send_one(job)
            except Exception as e:  # never let the sender thread die
                self.log(f"sender error: {type(e).__name__}: {str(e)[:200]}")

    def _send_one(self, job):
        text = tidy_outbound(job["text"])
        result = None
        for attempt in range(3):
            try:
                with self.send_lock:
                    result = N.notify(text, source="fastlane")
            except ValueError as e:
                self.log(f"notify refused the text ({str(e)[:80]}); sending a plain fallback")
                text = TXT_NO_ANSWER
                continue
            if result.get("ok") or result.get("unknown"):
                break
            self.log(f"notify failed ({result.get('detail', '')[:120]}); attempt {attempt + 1}")
            if "daily limit" in str(result.get("detail", "")):
                break
            time.sleep(3)
        ok = bool(result and (result.get("ok") or result.get("unknown")))
        if ok:
            self.sent_owner += 1
        for w in job["wamids"]:
            self.ledger.mark(w, "done", "answered" if ok else "send_failed")
        latency = None
        if job.get("received"):
            r = C.parse_ts(job["received"])
            if r is not None:
                latency = round(time.time() - r.timestamp(), 1)
        C.log_event("fastlane_sent", msg_kind=job["kind"], ok=ok, chars=len(text), via=(result or {}).get("channel"),
                    latency_s=latency, detail=(None if ok else str((result or {}).get("detail", ""))[:120]))
        self.log(f"sent {job['kind']} ok={ok} via={(result or {}).get('channel')} chars={len(text)} latency={latency}")
        if job["kind"] == "reply" and ok:
            self._remember(job)

    def _remember(self, job):
        """Short rolling memory for a restarted session: what the owner asked and what we answered."""
        owner_texts = [self.ledger.items[w]["text"] for w in job["wamids"] if w in self.ledger.items]
        rec = {"ts": utcnow_iso(), "owner": [str(t)[:300] for t in owner_texts], "reply": job["text"][:400]}
        try:
            with open(self.recent_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            lines = self.recent_path.read_text(encoding="utf-8").splitlines()
            if len(lines) > 60:
                atomic_write(self.recent_path, "\n".join(lines[-30:]) + "\n")
        except OSError:
            pass

    # ---------------- poller thread ----------------
    def poller_loop(self):
        delay = 0.0
        while not self.stop.is_set():
            if self.stop.wait(delay):
                return
            try:
                code, d = C.crm_call("GET", "/owner-inbox?since_id=0&limit=50&unprocessed=1", timeout=self.cfg["poll_timeout"])
                if code != 200:
                    raise RuntimeError(f"CRM answered HTTP {code}")
                items = d.get("items")
                if not isinstance(items, list):
                    raise RuntimeError("CRM answer has no items list")
                if self.poll_failures:
                    self.log(f"CRM reachable again after {self.poll_failures} failed polls")
                self.poll_failures = 0
                self.last_poll_ok = now()
                for it in items:
                    self._take_in(it)
                delay = self.cfg["poll_seconds"] * random.uniform(0.85, 1.15)
            except Exception as e:  # unreachable, timeout, 5xx, 401 ... all the same: wait, back off, keep trying
                self.poll_failures += 1
                if self.poll_failures in (1, 5) or self.poll_failures % 60 == 0:
                    self.log(f"poll failed ({self.poll_failures}x): {type(e).__name__}: {str(e)[:160]}")
                delay = min(60.0, 3.0 * (2 ** min(self.poll_failures, 5))) * random.uniform(0.85, 1.15)

    def _take_in(self, it):
        wamid = it.get("wamid") or ("id:%s" % it.get("id"))
        item = {"id": it.get("id"), "kind": it.get("kind") or "text", "text": it.get("text") or "", "received_at": it.get("received_at")}
        if not self.ledger.known(wamid):
            self.ledger.add(wamid, item)          # on disk first ...
            self.incoming.put((wamid, item))
            self.log(f"new owner message #{item['id']} kind={item['kind']} ({len(item['text'])} chars)")
        if not self.ledger.items[wamid]["acked"]:  # ... then tell the CRM we have it (retried on the next poll if this fails)
            try:
                code, _ = C.crm_call("POST", f"/owner-inbox/{int(item['id'])}/ack", {}, timeout=self.cfg["poll_timeout"])
                if code in (200, 404):
                    self.ledger.mark(wamid, "acked")
            except Exception as e:
                self.log(f"ack failed for #{item['id']}: {type(e).__name__}; will retry")

    # ---------------- claude session ----------------
    def briefing_text(self):
        return (HERE / self.BRIEFING).read_text(encoding="utf-8")

    def spawn(self):
        cmd = find_claude_cmd()
        if not cmd:
            looked = "; ".join("%s=%s" % (r, (r / "Claude" / "claude-code").is_dir()) for r in claude_search_roots())
            self.spawn_failed("Claude Code program not found on this PC (looked in: %s)" % looked[:400])
            return
        env = os.environ.copy()
        env.pop("ANTHROPIC_API_KEY", None)         # the subscription login must be used, never a stray API key
        env["PYTHONIOENCODING"] = "utf-8"
        env["AGENT_SOURCE"] = "fastlane-child"     # messages its tools send to the owner are logged as ours (see record_outgoing)
        sid = str(uuid.uuid4())
        try:
            args = ["--session-id", sid] if fake_claude_cmd() else claude_args(self.cfg, sid, self.briefing_text())
            self.session = Session(cmd + args, str(C.ROOT), env)
        except Exception as e:
            self.spawn_failed(f"{type(e).__name__}: {str(e)[:160]}")
            return
        try:
            (FL / "child.pid").write_text(str(self.session.pid))
        except OSError:
            pass
        self.ready = False
        self.busy = True
        self.startup_turn = True
        self.turn_started = now()
        self.session_tokens = 0
        self.session.send(self.startup_prompt())
        self.log(f"claude started pid={self.session.pid} session={sid[:8]}")

    def spawn_failed(self, why):
        self.spawn_failures += 1
        wait = min(120.0, self.cfg["respawn_seconds"] * (2 ** min(self.spawn_failures - 1, 5)))
        self.next_spawn = now() + wait
        self.session = None
        self.log(f"cannot start claude ({why}); retry in {wait:.0f}s")

    def startup_prompt(self):
        lines = ["SESSION START (no message to the owner now). First read agent/memory.md completely. Then answer exactly: READY"]
        try:
            recent = [json.loads(x) for x in self.recent_path.read_text(encoding="utf-8").splitlines()[-8:]]
        except Exception:
            recent = []
        if recent:
            lines.append("Context only, the last WhatsApp exchanges with the owner (oldest first):")
            for r in recent:
                lines.append("- owner: " + " / ".join(r.get("owner", []))[:300] + "  |  you answered: " + str(r.get("reply", ""))[:300])
        entries, self.outbox_pos = self.outbox_entries(0)
        day_ago = time.time() - 24 * 3600
        entries = [e for e in entries if (C.parse_ts(e.get("ts"), naive_tz=C.IST) or datetime.now(timezone.utc)).timestamp() > day_ago][-6:]
        if entries:
            lines.append(NOTE_OPERATOR + "\n" + self.format_outbox(entries))
        return "\n".join(lines)

    # ---------------- what the OTHER worker told the owner ----------------
    # The owner has one WhatsApp chat but two writers (this fast lane and the desktop operator). Messages of the desktop operator
    # are copied to agent/state/owner_outbox.jsonl by notify_owner.py / send_owner_file.py (source "operator"); they are shown to
    # Claude here, so "Haa, 3 bar video aaya" can be understood as the answer to the operator's "did the video arrive?".
    def outbox_entries(self, start):
        """(entries with source 'operator' written from byte offset `start` on, new offset)."""
        path = C.STATE / "owner_outbox.jsonl"
        try:
            size = path.stat().st_size
            if size < start:
                start = 0                       # the file was replaced: read it from the top
            with open(path, "rb") as f:
                f.seek(start)
                raw = f.read()
        except OSError:
            return [], start
        cut = raw.rfind(b"\n") + 1               # only complete lines count; a half-written last line is read next time
        end = start + cut
        out = []
        for line in raw[:cut].decode("utf-8", "replace").splitlines():
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if isinstance(e, dict) and e.get("source") == "operator":
                out.append(e)
        return out, end

    @staticmethod
    def format_outbox(entries):
        return "\n".join("- %s %s" % (str(e.get("ts", ""))[11:16], CTRL_RE.sub(" ", str(e.get("text", ""))).replace("\n", " ")[:300]) for e in entries)

    def end_session(self, why):
        s, self.session = self.session, None
        self.ready = False
        self.busy = False
        self.startup_turn = False
        if s:
            self.log(f"claude session ended: {why}")
            s.kill()

    # ---------------- turn handling ----------------
    def classify(self, wamid, item):
        """Instant, model-free handling of the owner's control words. Returns True if the message is finished."""
        text, kind = item["text"].strip(), item["kind"]
        received = item.get("received_at")
        if kind == "reaction":
            self.ledger.mark(wamid, "done", "reaction_ignored")
            return True
        if kind != "text":
            return False
        if PAUSE_RE.match(text):
            self.log("STOP ALL from the owner: stopping the running Claude turn")
            for w, _ in self.batch + list(self.pending):
                self.ledger.mark(w, "done", "stopped_by_owner")   # must not come back after a restart
            self.batch = []
            self.pending.clear()
            self.end_session("owner said STOP ALL")
            self.say(TXT_STOPPED, "stop", [wamid], received=received)
            return True
        if RESUME_RE.match(text):
            paused = self.crm_paused()
            self.say(TXT_RESUMED if paused is False else TXT_RESUME_PENDING, "resume", [wamid], received=received)
            return True
        if STATUS_RE.match(text):
            self.say(self.build_status(), "status", [wamid], received=received)
            return True
        return False

    def crm_paused(self):
        try:
            code, d = C.crm_call("GET", "/flags", timeout=self.cfg["poll_timeout"])
            return d.get("paused") if code == 200 and isinstance(d.get("paused"), bool) else None
        except Exception:
            return None

    def build_status(self):
        parts = ["Status ✅ fast lane chalu hai"]
        try:
            code, d = C.crm_call("GET", "/health", timeout=self.cfg["poll_timeout"])
            if code == 200:
                parts.append("CRM: theek | sending: " + ("PAUSED" if d.get("paused") is True else "chalu") + " | owner routing: " + str(d.get("owner_routing")))
            else:
                parts.append(f"CRM: HTTP {code} (dikkat)")
        except Exception:
            parts.append("CRM: pahunch nahi paa raha")
        caps = C.config()["daily_caps"]
        parts.append("Aaj bheja: email %s/%s, WhatsApp template %s/%s" % (C.used_today("email"), caps.get("email"),
                                                                      C.used_today("whatsapp_template"), caps.get("whatsapp_template")))
        todo = C.STATE / "heartbeat_todo.md"
        try:
            n = sum(1 for ln in todo.read_text(encoding="utf-8").splitlines() if ln.lstrip().startswith("- ["))
        except OSError:
            n = 0
        parts.append(f"Desktop operator ki list me {n} kaam")
        parts.append("Claude session: " + ("ready" if self.ready else "start ho raha hai"))
        if self.usage:
            parts.append("Claude %s limit: %d%% use, reset %s" % (self.window_name(self.usage["window"]), round(self.usage["used"] * 100),
                                                                self.reset_text(self.usage["resets_at"])))
        return "\n".join(parts)

    def next_batch(self):
        batch = []
        while self.pending and len(batch) < self.cfg["max_batch"]:
            batch.append(self.pending.popleft())
        return batch

    def tag_for(self, wamid, item):
        notes = []
        text = item["text"].strip()
        if item["kind"] == "text":
            m = APPROVE_RE.match(text) or REJECT_RE.match(text)
            if m:
                status = "processed"
                try:
                    code, d = C.crm_call("GET", f"/approvals/{m.group(2).upper()}", timeout=self.cfg["poll_timeout"])
                    status = ("approval %s is now %s" % (m.group(2).upper(), d.get("status"))) if code == 200 else "processed"
                except Exception:
                    pass
                notes.append("CRM already processed this command: " + status)
        r = C.parse_ts(item.get("received_at"))
        if r is not None and time.time() - r.timestamp() > self.cfg["stale_minutes"] * 60:
            notes.append("received %d minutes ago" % ((time.time() - r.timestamp()) // 60))
        if self.ledger.items[wamid]["tries"] > 1:     # start_turn() has already counted THIS attempt, so >1 means an earlier one failed
            notes.append("RETRY: an earlier attempt was interrupted; check whether it was already done before repeating anything")
        return "[%s#%s %s%s] %s" % (self.TAG, item["id"], item["kind"], (", " + "; ".join(notes)) if notes else "", tidy_inbound(item["text"]))

    def start_turn(self):
        batch = self.next_batch()
        if not batch:
            return
        for wamid, _ in batch:
            self.ledger.mark(wamid, "try")
        self.batch = batch
        text = "\n".join(self.tag_for(w, it) for w, it in batch)
        entries, self.outbox_pos = self.outbox_entries(self.outbox_pos)
        if entries:
            text = NOTE_OPERATOR + "\n" + self.format_outbox(entries[-5:]) + "\n" + text
        self.busy = True
        self.turn_started = now()
        self.turn_tools = 0
        try:
            self.session.send(text)
        except Exception as e:
            self.log(f"could not write to claude: {type(e).__name__}")
            self.requeue_batch("write failed")
            self.end_session("write failed")

    def requeue_batch(self, why):
        """The running turn did not finish. Try again once; after max_tries tell the owner and give up."""
        again, gave_up = [], []
        for wamid, item in self.batch:
            (gave_up if self.ledger.items[wamid]["tries"] >= self.cfg["max_tries"] else again).append((wamid, item))
        self.batch = []
        for pair in reversed(again):
            self.pending.appendleft(pair)
        if again:
            self.say(TXT_RESTARTING, "alert", once_key="restarting", every=120)
        if gave_up:
            self.say(TXT_GAVE_UP, "alert", [w for w, _ in gave_up])
        self.log(f"turn not finished ({why}): retry={len(again)} gave_up={len(gave_up)}")

    def handle_event(self, e):
        self.session.last_event = now()
        t = e.get("type")
        if t == "assistant":
            for b in (e.get("message", {}).get("content") or []):
                if b.get("type") == "tool_use":
                    self.turn_tools += 1
        elif t == "result":
            self.on_result(e)
        elif t == "rate_limit_event":
            self.on_rate_limit(e.get("rate_limit_info") or {})
        elif t == "system" or t == "auth_status":
            blob = json.dumps(e, ensure_ascii=False).lower()[:2500]
            if "authentication_failed" in blob or (t == "auth_status" and e.get("error")):
                self.say(TXT_CLAUDE_LOGIN, "alert", once_key="login", every=3600)
                self.log("claude reports an authentication problem")

    def on_rate_limit(self, info):
        """Claude sends one of these every turn. ONLY info["status"] says whether a limit was really hit ("allowed",
        "allowed_warning", "rejected"). Other fields such as overageStatus="rejected" just mean 'no extra credits are set up' and
        are normal (the first version of this code alarmed the owner on exactly that - 2026-10-15). `utilization` is the share
        of the window named in rateLimitType that is already used."""
        used, reset = info.get("utilization"), info.get("resetsAt")
        if isinstance(used, (int, float)):
            self.usage = {"window": info.get("rateLimitType"), "used": round(float(used), 2), "resets_at": reset}
        if info.get("status") == "rejected":
            self.say(TXT_CLAUDE_LIMIT, "alert", once_key="limit", every=3600)
            self.log("claude reports the usage limit is reached")
        elif isinstance(used, (int, float)) and used >= 0.9:
            self.say("Dhyan: Claude ka %s limit %d%% use ho chuka hai (reset: %s). Poora bharne par fast lane aur desktop dono ruk jaayenge."
                     % (self.window_name(info.get("rateLimitType")), round(used * 100), self.reset_text(reset)),
                     "alert", once_key="usage_warning", every=12 * 3600)

    @staticmethod
    def window_name(kind):
        return {"seven_day": "weekly", "five_hour": "5-ghante wala"}.get(str(kind), str(kind or "usage"))

    @staticmethod
    def reset_text(epoch):
        try:
            return datetime.fromtimestamp(float(epoch), C.IST).strftime("%d %b, %I:%M %p IST")
        except (TypeError, ValueError, OSError):
            return "pata nahi"

    def on_result(self, e):
        usage = e.get("usage") or {}
        keys = ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens")
        # How big the conversation is NOW = the prompt of the LAST model call of this turn. The top-level usage adds up every
        # model call of the turn (8 tool steps of a 55k context read as 440k): using that rotated the session after every long turn.
        last_call = (usage.get("iterations") or [None])[-1]
        if isinstance(last_call, dict):
            self.session_tokens = sum(int(last_call.get(k) or 0) for k in keys)
        else:
            self.session_tokens = sum(int(usage.get(k) or 0) for k in keys) // max(1, int(e.get("num_turns") or 1))
        was_startup = self.startup_turn
        self.startup_turn = False
        self.busy = False
        failed = bool(e.get("is_error")) or e.get("subtype") not in (None, "success")
        text = str(e.get("result") or "").strip()
        if was_startup:
            self.ready = not failed
            self.spawn_failures = 0 if self.ready else self.spawn_failures
            self.log(f"claude startup turn {'ok' if self.ready else 'FAILED'} ({int(e.get('duration_ms') or 0)} ms, {self.session_tokens} tokens)")
            if failed:
                self.check_error_text(text)
                self.end_session("startup turn failed")
                self.spawn_failed("startup turn failed")
            return
        batch, self.batch = self.batch, []
        received = None
        for _, item in batch:
            received = received or item.get("received_at")
        self.log(f"turn done: {len(batch)} msg, {self.turn_tools} tool calls, {now() - self.turn_started:.1f}s, "
                 f"{int(e.get('num_turns') or 0)} model turns, {self.session_tokens} tokens, cost ${float(e.get('total_cost_usd') or 0):.3f} (session total)")
        if failed:
            self.check_error_text(text)
            self.batch = batch
            self.requeue_batch("claude reported an error")
            self.end_session("turn error")
            return
        wamids = [w for w, _ in batch]
        if text.strip().upper() == "NO_REPLY":
            for w in wamids:
                self.ledger.mark(w, "done", "no_reply")
        elif not text:
            self.say(TXT_NO_ANSWER, "reply", wamids, received=received)
        else:
            self.say(text, "reply", wamids, received=received)

    def check_error_text(self, text):
        low = text.lower()
        if "login" in low or "authenticat" in low or "api key" in low or "oauth" in low:
            self.say(TXT_CLAUDE_LOGIN, "alert", once_key="login", every=3600)
        elif "limit" in low or "quota" in low:
            self.say(TXT_CLAUDE_LIMIT, "alert", once_key="limit", every=3600)

    def timeout_check(self):
        if not (self.busy and self.session):
            return
        elapsed = now() - self.turn_started
        silent = now() - self.session.last_event
        if self.startup_turn:
            if elapsed > 120:
                self.end_session("startup turn took over 2 minutes")
                self.spawn_failed("startup too slow")
            return
        if elapsed > self.cfg["turn_timeout_seconds"]:
            self.log(f"turn exceeded {self.cfg['turn_timeout_seconds']}s: handing it to the desktop operator")
            self.hand_to_desktop(self.batch)
            self.batch = []
            self.end_session("turn timeout")
        elif silent > self.cfg["stall_seconds"]:
            self.log(f"claude silent for {silent:.0f}s inside a turn: restarting it")
            self.requeue_batch("claude stalled")
            self.end_session("stalled")

    def hand_to_desktop(self, batch):
        """A request too long for the fast lane goes to the desktop operator's to-do list, and the owner is told."""
        todo = C.STATE / "heartbeat_todo.md"
        try:
            with open(todo, "a", encoding="utf-8") as f:
                for _, item in batch:
                    f.write("- [%s] fast lane could not finish within %ds - owner request WA#%s (text, trusted): %s\n" % (
                        datetime.now(C.IST).strftime("%Y-%m-%d %H:%M"), self.cfg["turn_timeout_seconds"], item["id"],
                        CTRL_RE.sub(" ", item["text"]).replace("\n", " ")[:300]))
        except OSError as e:
            self.log(f"cannot write the desktop to-do list: {e}")
        self.say(TXT_TIMEOUT, "alert", [w for w, _ in batch])

    def ack_check(self):
        """Nothing answered yet and the owner has waited `ack_after_seconds`: send a short 'got it' (once per message, and
        at most one such text a minute)."""
        if now() - self.last_ack_text < 60:
            return
        waiting = [(w, it) for w, it in (self.batch + list(self.pending))
                   if w not in self.acked_text_for and now() - self.ledger.items[w]["seen"] >= self.cfg["ack_after_seconds"]]
        if not waiting:
            return
        in_turn = any(w == waiting[0][0] for w, _ in self.batch)
        for w, _ in waiting:
            self.acked_text_for.add(w)
        self.last_ack_text = now()
        self.say(TXT_ACK_BUSY if in_turn else TXT_ACK_QUEUED, "ack")

    def rotate_check(self):
        s = self.session
        if not s or self.busy or not self.ready:
            return
        too_old = now() - s.started > self.cfg["rotate_after_hours"] * 3600
        if s.turns >= self.cfg["rotate_after_turns"] or too_old or self.session_tokens > self.cfg["rotate_after_tokens"]:
            self.end_session("rotation (turns=%d, tokens=%d)" % (s.turns, self.session_tokens))

    # ---------------- bookkeeping ----------------
    def write_alive(self):
        s = self.session
        rec = {"pid": os.getpid(), "version": VERSION, "ts": time.time(), "ts_iso": utcnow_iso(), "started": self.started,
               "claude_pid": s.pid if s and s.alive() else None, "claude_ready": bool(self.ready),
               "busy": bool(self.busy), "queue": len(self.pending), "last_poll_ok_ts": self.last_poll_ok,
               "poll_failures": self.poll_failures, "sent_to_owner": self.sent_owner, "spawn_failures": self.spawn_failures,
               "usage": self.usage}
        atomic_write(FL / "alive.json", json.dumps(rec))

    def recover(self):
        """After a restart: everything not finished is handled again; a message that already failed max_tries times is dropped."""
        n = 0
        for wamid, it in self.ledger.pending():
            n += 1
            if it["tries"] >= self.cfg["max_tries"]:
                self.ledger.mark(wamid, "done", "gave_up_after_restart")
                self.say(TXT_GAVE_UP, "alert", once_key="gaveup_" + wamid, every=1)
                continue
            self.pending.append((wamid, {"id": it["id"], "kind": it["kind"], "text": it["text"], "received_at": it["received_at"]}))
        if n:
            self.log(f"recovered {n} unfinished message(s) from the ledger")

    def sweep_new(self):
        while True:
            try:
                wamid, item = self.incoming.get_nowait()
            except queue.Empty:
                return
            if self.classify(wamid, item):
                continue
            self.pending.append((wamid, item))

    # ---------------- main loop ----------------
    def run(self):
        kill_orphan(FL / "child.pid")
        self.log(f"fastlane {VERSION} starting (pid {os.getpid()})")
        C.log_event("fastlane_started", pid=os.getpid())
        self.recover()
        threading.Thread(target=self.sender_loop, daemon=True).start()
        threading.Thread(target=self.poller_loop, daemon=True).start()
        last_alive = 0.0
        while not self.stop.is_set():
            if (FL / "STOP").exists():
                self.log("STOP file found: shutting down")
                break
            self.sweep_new()
            s = self.session
            if s is None:
                if now() >= self.next_spawn and not os.environ.get("FASTLANE_NO_SPAWN"):
                    self.spawn()
            else:
                try:
                    kind, payload = s.events.get(timeout=0.2)
                except queue.Empty:
                    kind = None
                if kind == "event":
                    self.handle_event(payload)
                elif kind == "exit":
                    tail = " | ".join(list(s.stderr_tail)[-3:])
                    self.log(f"claude exited with code {payload}. stderr tail: {tail[:300]}")
                    if self.batch:
                        self.requeue_batch("claude exited")
                    lived = now() - s.started
                    self.end_session(f"exited {payload}")
                    if lived < 30:                       # crashed right after start: do not spin, back off
                        self.spawn_failed("exited after %.0fs" % lived)
                self.timeout_check()
                self.rotate_check()
                if self.session and self.ready and not self.busy and self.pending:
                    self.start_turn()
            self.ack_check()
            if now() - last_alive >= 2:
                self.write_alive()
                last_alive = now()
            if s is None:
                time.sleep(0.2)
        self.shutdown()

    def shutdown(self):
        self.stop.set()
        self.end_session("daemon stopping")
        self.outbox.put(None)
        try:
            (FL / "child.pid").unlink()
        except OSError:
            pass
        try:
            (FL / "alive.json").unlink()
        except OSError:
            pass
        self.log("fastlane stopped")


def cmd_status(_a):
    p = FL / "alive.json"
    if not p.exists():
        print("fastlane: NOT running (no alive.json)")
        return 1
    d = json.loads(p.read_text(encoding="utf-8"))
    age = time.time() - float(d.get("ts", 0))
    print(f"fastlane: {'RUNNING' if age < 15 else 'STALE (no heartbeat for %ds)' % age} pid={d.get('pid')} claude_ready={d.get('claude_ready')} "
          f"busy={d.get('busy')} queue={d.get('queue')} sent_to_owner={d.get('sent_to_owner')} poll_failures={d.get('poll_failures')}")
    return 0 if age < 15 else 1


def main():
    C.start()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", nargs="?", default="run", choices=["run", "status"])
    a = ap.parse_args()
    if a.command == "status":
        sys.exit(cmd_status(a))
    lock = take_instance_lock(FL / "daemon.lock")
    if lock is None:
        print("fastlane is already running (daemon.lock is held). Not starting a second one.")
        sys.exit(1)
    try:
        (FL / "STOP").unlink()
    except OSError:
        pass
    d = Daemon()
    try:
        d.run()
    except KeyboardInterrupt:
        d.shutdown()


if __name__ == "__main__":
    main()
