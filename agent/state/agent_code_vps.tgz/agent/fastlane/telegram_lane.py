# -*- coding: utf-8 -*-
"""telegram_lane.py - the fast lane on TELEGRAM (made to run on the VPS): the owner writes to a Telegram bot and gets an answer in seconds.

Same engine as fastlane.py (durable ledger, one warm headless Claude, locked-down dontAsk session, stall / turn watchdogs, crash backoff,
STOP / RESUME / status instantly without a model); only the way messages come in and go out is different:
  * in:  Telegram long polling (getUpdates). Only the ONE owner account (TELEGRAM_OWNER_ID, a private chat) is listened to; everybody else
         is ignored without an answer. A message is written to the ledger BEFORE the Telegram offset moves past it (crash-safe).
  * out: Claude's final answer goes out with sendMessage; the owner sees "typing..." while Claude works (instead of a "got it" text);
         files go out through send_owner_file.py (OWNER_CHANNEL=telegram).
  * STOP ALL / RESUME / status / ping also work as /stop /resume /status /ping. STOP ALL creates agent/state/PAUSED: every live-send tool
         refuses while that file exists. There is no CRM in this loop (the CRM's approval buttons only understand WhatsApp).

Settings in the env file next to the agent (never print): TELEGRAM_BOT_TOKEN (@BotFather), TELEGRAM_OWNER_ID (numeric id), OWNER_CHANNEL=telegram.
Run:     python agent/fastlane/telegram_lane.py run          Status: python agent/fastlane/telegram_lane.py status
Tests:   agent/tests/test_telegram_lane.py (fake Telegram server + fake Claude)
"""
import argparse
import json
import re
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import fastlane as F  # noqa: E402  (also puts agent/tools on sys.path)
import common as C  # noqa: E402
import notify_owner as N  # noqa: E402
import telegram_api as T  # noqa: E402

TXT_START = ("Namaste! Main Ivinfotech ka AI sales assistant hoon. Mujhse seedha baat kijiye (leads, video, landing page, kuch bhi) "
             "ya sirf \"status\" likhiye. Kisi lead ko kuch bhi bhejne se pehle aapki manzoori zaroor loonga.")
KIND_BY_FIELD = (("voice", "audio", "[voice message]"), ("audio", "audio", "[audio]"), ("video_note", "video", "[video message]"),
                 ("video", "video", "[video]"), ("animation", "video", "[animation]"), ("sticker", "other", "[sticker]"),
                 ("location", "other", "[location]"), ("contact", "other", "[contact card]"))


class TelegramDaemon(F.Daemon):
    TAG = "TG"
    BRIEFING = "briefing_telegram.md"

    def __init__(self, cfg=None):
        super().__init__(cfg)
        user_cfg = C.config().get("fastlane") or {}
        if "ack_after_seconds" not in user_cfg:
            self.cfg["ack_after_seconds"] = 45          # "typing..." already shows that we work; a text only for really slow turns
        self.cfg.setdefault("tg_long_poll_seconds", 25)
        self.owner = T.owner_id()
        self.offset_path = F.FL / "tg_offset.json"
        try:
            self.tg_offset = int(json.loads(self.offset_path.read_text(encoding="utf-8")).get("offset", 0))
        except (OSError, ValueError, TypeError):
            self.tg_offset = 0
        self.last_typing = 0.0
        self.warned = set()

    # ---------------- incoming: Telegram long polling ----------------
    def save_offset(self, offset):
        self.tg_offset = offset
        F.atomic_write(self.offset_path, json.dumps({"offset": offset}))

    @staticmethod
    def describe(msg):
        """(kind, text) of one Telegram message. Text is data: the type tells Claude what it could not see."""
        caption = str(msg.get("caption") or "").strip()
        if msg.get("text") is not None:
            return "text", str(msg["text"])
        if msg.get("photo"):
            return "image", ("[photo] " + caption).strip()
        if msg.get("document"):
            return "document", ("[document: %s] %s" % (str((msg["document"] or {}).get("file_name") or "file")[:80], caption)).strip()
        for field, kind, label in KIND_BY_FIELD:
            if msg.get(field):
                return kind, (label + " " + caption).strip()
        return "other", "[message of a type this lane cannot read]"

    def poller_loop(self):
        delay = 0.0
        while not self.stop.is_set():
            if self.stop.wait(delay):
                return
            try:
                lp = int(self.cfg["tg_long_poll_seconds"])
                code, res = T.call("getUpdates", {"offset": self.tg_offset, "timeout": lp, "allowed_updates": ["message"]}, timeout=lp + 10)
                if not (T.ok(code, res) and isinstance(res.get("result"), list)):
                    raise RuntimeError("Telegram answered HTTP %s %s" % (code, str(res.get("description") or res.get("_error") or "")[:100]))
                if self.poll_failures:
                    self.log("Telegram reachable again after %d failed polls" % self.poll_failures)
                self.poll_failures = 0
                self.last_poll_ok = F.now()
                for upd in res["result"]:
                    self.take_update(upd)
                delay = 0.0 if res["result"] else 0.1
            except Exception as e:  # noqa: BLE001 - unreachable, timeout, 409 (a webhook is set) ...: back off and keep trying
                self.poll_failures += 1
                if self.poll_failures in (1, 5) or self.poll_failures % 60 == 0:
                    self.log("poll failed (%dx): %s: %s" % (self.poll_failures, type(e).__name__, str(e)[:160]))
                delay = min(60.0, 3.0 * (2 ** min(self.poll_failures, 5)))

    def take_update(self, upd):
        uid = upd.get("update_id")
        if not isinstance(uid, int):
            return
        msg = upd.get("message") or {}
        sender, chat = (msg.get("from") or {}).get("id"), msg.get("chat") or {}
        if sender != self.owner or chat.get("type") != "private":
            if sender not in self.warned:
                self.warned.add(sender)
                self.log("ignored a Telegram message from a user who is not the owner (id %s); no answer is sent" % sender)
            self.save_offset(uid + 1)
            return
        key = "tg:%d" % uid
        if not self.ledger.known(key):
            kind, text = self.describe(msg)
            sent = datetime.fromtimestamp(int(msg.get("date") or time.time()), timezone.utc).isoformat(timespec="seconds")
            item = {"id": uid, "kind": kind, "text": text[:4096], "received_at": sent}
            self.ledger.add(key, item)                       # on disk first ...
            self.ledger.mark(key, "acked")
            self.incoming.put((key, item))
            threading.Thread(target=T.typing, daemon=True).start()
            self.log("new owner message #%d kind=%s (%d chars)" % (uid, kind, len(text)))
        self.save_offset(uid + 1)                            # ... then Telegram may forget it

    # ---------------- instant commands ----------------
    @staticmethod
    def command_of(text):
        if not text.startswith("/"):
            return None
        return text[1:].split()[0].split("@")[0].lower() if text[1:].strip() else None

    def crm_paused(self):
        return (C.STATE / "PAUSED").exists()

    def classify(self, wamid, item):
        text = item["text"].strip()
        if item["kind"] == "text":
            cmd = self.command_of(text)
            if cmd == "start":
                self.say(TXT_START, "start", [wamid], received=item.get("received_at"))
                return True
            if cmd == "stop" or F.PAUSE_RE.match(text):
                (C.STATE / "PAUSED").write_text("stopped by the owner on Telegram at %s\n" % F.utcnow_iso(), encoding="utf-8")
                item = dict(item, text="STOP ALL")
            elif cmd == "resume" or F.RESUME_RE.match(text):
                try:
                    (C.STATE / "PAUSED").unlink()
                except OSError:
                    pass
                item = dict(item, text="RESUME")
            elif cmd in ("status", "ping"):
                item = dict(item, text=cmd)
        return super().classify(wamid, item)

    def build_status(self):
        caps = C.config()["daily_caps"]
        parts = ["Status ✅ Telegram agent chalu hai",
                 "sending: " + ("PAUSED" if self.crm_paused() else "chalu"),
                 "Aaj bheja: email %s/%s, WhatsApp template %s/%s" % (C.used_today("email"), caps.get("email"),
                                                                    C.used_today("whatsapp_template"), caps.get("whatsapp_template")),
                 "Claude session: " + ("ready" if self.ready else "start ho raha hai")]
        if self.usage:
            parts.append("Claude %s limit: %d%% use, reset %s" % (self.window_name(self.usage["window"]), round(self.usage["used"] * 100),
                                                                self.reset_text(self.usage["resets_at"])))
        return "\n".join(parts)

    # ---------------- outgoing ----------------
    def ack_check(self):
        """'typing...' lasts ~5 s on Telegram: renew it every 4 s while a turn is running or queued."""
        if (self.busy or self.pending) and F.now() - self.last_typing > 4:
            self.last_typing = F.now()
            threading.Thread(target=T.typing, daemon=True).start()
        super().ack_check()

    def _send_one(self, job):
        text = F.tidy_outbound(job["text"], limit=3800)
        ok = unknown = False
        detail = ""
        for attempt in range(3):
            ok, detail, unknown = T.send_message(text)
            if ok or unknown:
                break
            self.log("telegram send failed (%s); attempt %d" % (detail[:120], attempt + 1))
            time.sleep(2)
        delivered = bool(ok or unknown)
        if delivered:
            self.sent_owner += 1
            N.record_outgoing(text, "telegram", source="fastlane")
        for w in job["wamids"]:
            self.ledger.mark(w, "done", "answered" if delivered else "send_failed")
        latency = None
        if job.get("received"):
            r = C.parse_ts(job["received"])
            if r is not None:
                latency = round(time.time() - r.timestamp(), 1)
        C.log_event("telegram_sent", msg_kind=job["kind"], ok=delivered, chars=len(text), latency_s=latency, detail=(None if delivered else detail[:120]))
        self.log("sent %s ok=%s chars=%d latency=%s" % (job["kind"], delivered, len(text), latency))
        if job["kind"] == "reply" and delivered:
            self._remember(job)


def cmd_status(_a):
    p = F.FL / "alive.json"
    if not p.exists():
        print("telegram lane: NOT running (no alive.json)")
        return 1
    d = json.loads(p.read_text(encoding="utf-8"))
    age = time.time() - float(d.get("ts", 0))
    print("telegram lane: %s pid=%s claude_ready=%s busy=%s queue=%s sent_to_owner=%s poll_failures=%s" % (
        "RUNNING" if age < 15 else "STALE (%ds)" % age, d.get("pid"), d.get("claude_ready"), d.get("busy"), d.get("queue"),
        d.get("sent_to_owner"), d.get("poll_failures")))
    return 0 if age < 15 else 1


def main():
    C.start()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", nargs="?", default="run", choices=["run", "status"])
    a = ap.parse_args()
    if a.command == "status":
        sys.exit(cmd_status(a))
    if not T.configured():
        print("TELEGRAM_BOT_TOKEN and TELEGRAM_OWNER_ID must be set (environment or the env file). Nothing started.")
        sys.exit(2)
    lock = F.take_instance_lock(F.FL / "daemon.lock")
    if lock is None:
        print("the lane is already running (daemon.lock is held). Not starting a second one.")
        sys.exit(1)
    try:
        (F.FL / "STOP").unlink()
    except OSError:
        pass
    d = TelegramDaemon()
    try:
        d.run()
    except KeyboardInterrupt:
        d.shutdown()


if __name__ == "__main__":
    main()
