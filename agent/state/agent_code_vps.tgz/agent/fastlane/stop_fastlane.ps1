# Stops both background programs cleanly (fast lane and operator lane): each finishes its current step, stops its Claude process
# and removes its alive.json.
# Usage (PowerShell):  powershell -NoProfile -ExecutionPolicy Bypass -File agent\fastlane\stop_fastlane.ps1
$repo = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
foreach ($name in @("fastlane", "operator")) {
    $dir = Join-Path $repo ("agent\state\" + $name)
    $alive = Join-Path $dir "alive.json"
    if (-not (Test-Path $alive)) { Write-Host "$name is not running (no alive.json)"; continue }
    $daemonPid = (Get-Content $alive -Raw | ConvertFrom-Json).pid
    New-Item -ItemType File -Force (Join-Path $dir "STOP") | Out-Null
    $stopped = $false
    for ($i = 0; $i -lt 20; $i++) {
        if (-not (Test-Path $alive)) { $stopped = $true; break }
        Start-Sleep -Seconds 1
    }
    if ($stopped) { Write-Host "$name stopped cleanly" }
    else { Write-Host "$name did not stop in 20 s - ending process $daemonPid"; Stop-Process -Id $daemonPid -Force -ErrorAction SilentlyContinue }
}
