# Starts the two background programs in hidden windows: the WhatsApp FAST LANE (instant replies) and the OPERATOR LANE (the
# heartbeat's work in ONE persistent Claude session). Safe to run twice: a second copy of either refuses to start (daemon.lock).
# Usage (PowerShell):  powershell -NoProfile -ExecutionPolicy Bypass -File agent\fastlane\start_fastlane.ps1
$ErrorActionPreference = "Stop"
$repo = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$state = Join-Path $repo "agent\state"

# The subscription login must be used, never a stray API key.
Remove-Item Env:ANTHROPIC_API_KEY -ErrorAction SilentlyContinue
$py = (Get-Command python -ErrorAction Stop).Source

foreach ($lane in @(@("fastlane", "fastlane.py"), @("operator", "operator_lane.py"))) {
    $dir = Join-Path $state $lane[0]
    New-Item -ItemType Directory -Force $dir | Out-Null
    Start-Process -FilePath $py -ArgumentList @(("agent\fastlane\" + $lane[1]), "run") -WorkingDirectory $repo `
        -WindowStyle Hidden -RedirectStandardOutput (Join-Path $dir "daemon.out") -RedirectStandardError (Join-Path $dir "daemon.err")
}

Start-Sleep -Seconds 6
Push-Location $repo
& $py agent\fastlane\fastlane.py status
& $py agent\fastlane\operator_lane.py status
Pop-Location
