# AI Sales Agent — owner quick guide (Hinglish)

## Ye kya hai
Ye folder Claude Code ka "sales operator" ghar hai. Koi fixed pipeline ya LLM-API automation nahi: **main (Claude) har step khud sochta hoon**, 5 sub-agents (`.claude/agents/`: scout, qualifier, creative, outreach, closer) ko kaam deta hoon, aur **tools** (`agent/tools/`) se asli kaam hota hai. CRM (`backend/`) sirf record aur human-handoff ke liye hai.

## WhatsApp fast lane (turant jawab) - 2026-10-15
WhatsApp par aap likhte hain, jawab **seconds** me aata hai (pehle heartbeat se 10 minute lagte the).
- **Kya hai:** `agent/fastlane/fastlane.py` ek chhota always-on program hai (isme koi model nahi). Ye har ~3 second me CRM ka owner-inbox dekhta hai, har message pehle apni ledger file me likhta hai (crash me bhi message nahi khota), phir CRM ko ack deta hai.
- **Instant (bina model ke):** `STOP ALL`, `RESUME`, `status`, `ping` ka jawab program khud deta hai.
- **Baaki sab:** ek hamesha-garam (warm) Claude session ko jaata hai (aapke subscription login se). Uska final jawab seedha WhatsApp par jaata hai. 18 second tak jawab na bane to "Mil gaya" ka chhota text jaata hai (WhatsApp ka "typing..." dikhana is provider par possible nahi: test me "Missing message type" aaya).
- **Is session ki seema (dontAsk + chhoti allow-list):** padh sakta hai, draft bana sakta hai, `crm.py` / `notify_owner.py` / `propose.py` / `suppress.py` aur dry-run chala sakta hai. **Kisi lead ko kuch bhej nahi sakta**, `.env` / secret files nahi padh sakta, tools / `config.json` / `CLAUDE.md` nahi badal sakta. Lambe kaam (Apify, video, deploy) `agent/state/heartbeat_todo.md` me jaate hain aur desktop operator (heartbeat) karta hai.
- **Operator lane (bade kaam, naya session nahi):** `operator_lane.py` fast lane ke saath hi chalta hai. Ye har ~20 second me bina model ke dekhta hai ki kaam hai ya nahi; kaam ho tabhi **ek hi persistent Claude session** ko kaam deta hai (wo pichla kaam yaad rakhta hai, aur idle me kuch kharch nahi). Jo ye nahi kar sakta (Apify, Mobbin, VPS ssh, deploy, live send) uspar ` [needs-desktop]` tag lagta hai; use desktop wala scheduled task (ab har 15 minute, pehle sasta check) uthata hai. Haal: `python agent\fastlane\operator_lane.py status`; log: `agent\state\operator\operator.log`.
- **Video / photo / PDF bhejna:** WhatsApp par likhiye "kal wala video bhejo" (ya "landing page ka screenshot bhejo"): `send_owner_file.py` file ko aapke number par bhejta hai. Sirf `agent/state/assets` aur `agent/state/drafts` ki files, sirf mp4/3gp (16 MB tak), jpg/png (5 MB tak) aur pdf (16 MB tak), sirf jab aapki 24 ghante ki WhatsApp window khuli ho. Window band ho to kuch nahi jaata (email me video nahi jaata); pehle aap koi bhi message likh dijiye.
- **Chalane ka tareeka (PowerShell):** `powershell -ExecutionPolicy Bypass -File agent\fastlane\start_fastlane.ps1`  |  rokne ka: `...\stop_fastlane.ps1`  |  haal: `python agent\fastlane\fastlane.py status`. Log: `agent\state\fastlane\fastlane.log`.
- **PC band ho gaya to?** Fast lane bhi band. Heartbeat (Claude app khula ho to) 10 minute me wahi kaam purane tareeke se kar leta hai. PC chalu hote hi apne aap start karne ke liye Windows "At log on" task chahiye (aapki OK ke baad).
- **Dhyan:** `config.json` me `daily_caps.owner_notify` (abhi 40/din) har WhatsApp jawab/ack ko gintaa hai; zyada baat-cheet ho to is limit ko aap badha dijiye. Ye file sirf aap badalte hain.

## Aap kaise use karenge
1. Claude Code ka session is folder (`AISales_agent_team`) me kholiye (ya phone se Remote Control).
2. Bas boliye: *"Aaj ki shift shuru karo"* / *"AI automation ke liye Gujarat me 5 achhe leads dhundho"* / *"Inbox check karo"* / *"Is lead ka reply likho"*.
3. Main sub-agents se kaam karwaata hoon, aapko leads + page + video + message ke drafts dikhaata hoon.
4. **Bhejne se pehle har baar aapko ek Allow/Deny prompt dikhega** (phone par bhi aata hai). Wahi aapki approval hai. Prompt me likha hoga: kise, kaunsa channel, kya bhej rahe hain, aaj ka count. Deny karenge to main dobara nahi bhejunga, poochunga kya badalna hai.
5. Lead jab interested/ready ho, main aapko brief ke saath batata hoon ki "ek insaan ko ise sambhalna chahiye".

## Safety jo code me hai (tools ke andar)
- Default **dry-run**: `--live` ke bina kuch nahi bhejta.
- Roz ki limit `agent/config.json` me (abhi: total 20, email 20, WhatsApp template 10). Isko sirf aap badalte hain.
- Suppression list, duplicate guard (14 din), send window (9:30–19:00 IST), secrets kabhi print nahi hote, har attempt `agent/state/events.jsonl` me log.
- WhatsApp free-form reply sirf 24 ghante ki window ke andar; uske bahar template chahiye. Reply ki bhi apni daily limit hai (30), ek hi lead ko roz max 6 reply, aur same text do baar nahi jaata.
- **Har live send ke liye owner ka approval code** (`--approval CODE`): `propose.py` aapko WhatsApp par poora message dikhata hai (poora email/number, poora text, har link, template ka asli text) + code. Aap `OK CODE` likhte hain to CRM (server par) code ko approve karta hai. Agent ke paas approve karne ka koi raasta nahi hai.
- **STOP**: lead ne STOP likha to CRM ki do-not-contact list me jaata hai, aur har live send se pehle tools CRM se poochte hain. Agent bhool bhi jaaye to bhi nahi jaata.
- **Timeout = natija pata nahi (UNKNOWN OUTCOME), dobara mat bhejiye; pehle status check kijiye.** Agar WhatsApp/Resend ne request le li par jawab time par nahi aaya (read timeout, connection toot gaya), to message **delivered ho chuka ho sakta hai**. Tool ise "failed" nahi maanta: exit code **3**, screen par `UNKNOWN OUTCOME ... DO NOT retry`, daily count aur duplicate guard me "sent" ki tarah likh deta hai (`sends.jsonl` me `"status":"unknown"`), aur wahi message dobara bhejne se rok deta hai (message me "earlier attempt ... UNKNOWN" likha hota hai). Status check: WhatsApp = BSP dashboard ya lead se poochiye; email = Resend dashboard > Emails; template `create` = `python agent/tools/wa.py templates --name NAME`. DNS fail / connection refused / certificate error / network unreachable jaise errors me request ja hi nahi paati, isliye wo "unknown" nahi hote (normal FAILED, exit 1, retry safe). `notify_owner.py` me WhatsApp timeout ho to email fallback phir bhi chalta hai (owner ko double mile to koi nuksan nahi); email na ho to "MAY have been delivered - do not assume it failed" likha aata hai (exit 3). Agar status dekh kar pakka ho jaaye ki message gaya hi nahi aur dobara bhejna hai, to **owner** `agent/state/sends.jsonl` se woh `"status":"unknown"` wali line hataye (ya subject/text badle) aur naya approval le; daily count ko jaisa hai waisa rehne dein. Test ke liye timeout `AGENT_HTTP_TIMEOUT=1` (seconds) se chhota kiya ja sakta hai (default: WhatsApp 90s, email 40s).
- Agar message itna lamba hai ki aap poora padh nahi sakte (3500 characters se zyada), `propose.py` mana kar deta hai - draft chhota karna padega.

## Trust boundary - ye zaroor padhiye
- **CRM side asli boundary hai**: approve/reject/pause/resume sirf aapke asli WhatsApp message se hota hai (CRM webhook me). Agent ke API me ye karne ka koi route hi nahi.
- **Tools wali gate abhi sirf salah/rule hai, taala nahi**: tools office PC par chalte hain, aur provider keys (Resend, WhatsApp) bhi usi PC par hain. Koi prompt-injected agent tools ko chhod kar seedha provider ko call kar sakta hai. Isliye abhi asli aakhri rakhwala **Claude Code ka Allow/Deny prompt** hai - use band mat kijiye.
- Jab tak send CRM ke andar nahi jaata (contract ka "v2 plan"), ye 4 cheezein aap kar dijiye:
  1. `WHATSAPP_WEBHOOK_SECRET` / `WHATSAPP_APP_SECRET` **sirf VPS ki `.env` me** rakhiye, office PC par kabhi nahi (tools chalna hi mana kar dete hain agar ye mil jaaye).
  2. Office PC par agent ke liye alag `agent/.env` banaiye (`agent/.env.example` dekhiye) - `backend/.env` ki copy nahi.
  3. Claude Code ki settings me deny rules lagaiye (ye aapko khud karna hai, tools ye nahi karte): `Read(./backend/.env)`, `Read(./agent/.env)`, aur `Edit(./agent/config.json)`; closer sub-agent se `Bash` hata dijiye (use sirf KB padhna aur draft likhna hai); shell hook se `curl` / `Invoke-WebRequest` aur `AGENT_CRM_URL=` wale commands roke jaa sakte hain.
  4. nginx me webhook path par sirf WhatsApp provider ke IP allow kijiye aur access log me query string (`?k=...`) mask kijiye.
- `--ignore-window` aur `--skip-remote-check` ab tabhi chalte hain jab command me `AGENT_OWNER_OVERRIDE=1` / `AGENT_TEST_MODE=1` likha ho - isse permission prompt me override saaf dikhta hai.
- `agent/pilot/scripts/wa_send_*.py` aur `wa_tpl_submit.py` purane pilot ke scripts hain jo bina approval ke bhejte/banate the. Ab ye chalne se mana karte hain (jab tak `PILOT_SCRIPT_NO_APPROVAL_GATE=yes` set na ho). Naya kaam `wa.py` + `propose.py` se karein.

## Abhi kya ban chuka hai
- `CLAUDE.md` (mera operating manual), 5 sub-agents, knowledge base (`agent/kb/`: company, services, proof points, objections, pricing policy, tone, playbook).
- Tools: `send_email.py` (Resend), `wa.py` (templates/status/create/send-template/reply), `propose.py` (owner se approval maangna), `notify_owner.py` (owner ko message), `crm.py` (CRM se baat: inbox, replies, handoff, approvals), `suppress.py` (do-not-contact).
- Tests (sab offline, koi network nahi, asli DB/.env/state ko haath nahi lagate):
  - agent: `python -m unittest discover agent/tests -v`  (cwd = repo root; ~2 minute, har tool ek asli subprocess me chalta hai)
  - CRM + end-to-end (asli tools asli CRM ke against): `cd backend` phir `venv\Scripts\python.exe -m pytest tests -q`

## Abhi baaki hai
- `page.py` (landing page deploy with rollback), `video.py` (captions-first video).
- KB me aapke **TODO(owner)** items: exact address, handoff wale insaan ka naam/number, pricing policy, timelines, client/years ke facts, Takshashila figure ki permission.
- Pehla asli test: aapke apne email/number par ek email aur ek WhatsApp template (prompt ke saath).


## Telegram test (PC par, VPS ya BSP ke bina) - owner steps
Maqsad: phone se agent se baat karna aur Allow/Deny dena, aaj hi dekhne ke liye. (Live send abhi band rahega: CRM ka naya code VPS par nahi hai.)
1. **Telegram bot banaiye** (ye sirf aap kar sakte hain): Telegram me `@BotFather` kholiye -> `/newbot` -> naam do -> aapko ek **token** milega. Token kisi ko chat me mat bhejiye (mujhe bhi nahi); sirf step 4 me terminal me paste kijiye.
2. **Claude Code CLI + Bun install** (main kar sakta hoon aapki haan ke baad, npm se): `npm install -g @anthropic-ai/claude-code bun`.
3. **Login:** naya terminal kholiye -> `claude` -> browser me apne **Claude subscription** se sign in. (API key mat dijiye.)
4. Repo folder me (`cd C:\Users\Administrator\Desktop\AISales_agent_team`) `claude` chalaiye, phir: `/plugin install telegram@claude-plugins-official` -> `/telegram:configure <aapka bot token>` -> `/exit`.
5. `agent\start_operator.cmd` double-click karke chalaiye (window khuli rakhiye). Telegram par apne bot ko "hi" bhejiye -> wo ek **pairing code** dega -> terminal me `/telegram:access pair <code>` -> phir `/telegram:access policy allowlist` (sirf aap).
6. Ab Telegram se likhiye: "status", "AI automation ke liye Gujarat me 5 leads dhundho", "KB me kya TODO hai". Mere Allow/Deny prompts aapke Telegram par aayenge.
Dhyan: ye research preview hai; session band hua to messages tab tak nahi sunenge. `ANTHROPIC_API_KEY` is PC par kabhi set mat kijiye.
