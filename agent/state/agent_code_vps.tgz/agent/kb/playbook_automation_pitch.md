# What we learned so far (pilot + lead rounds) — use as starting knowledge, update when wrong

## Leads
- Explicit "I need AI automation" posts from Indian business owners are rare (0–3 per two weeks), contested (30–110 comments, mostly vendors) and have almost no contact data. Use them as alerts, not as the engine.
- Best prospects came from **stacked signals**: spends money on enquiries (live Meta ads with a WhatsApp CTA, new RERA project, many reviews) × no visible system × reachable business-published contact. 2026-10-14 round: 13 A + 16 B of 30 enriched (Gujarat; Meta Ad Library + Google Maps). Still unproven: whether they actually need us — only conversations will tell.
- Not discriminating: free webmail, no website, review count alone, RERA "pending". Needs a chain/franchise filter.

## Pitch that worked as a concept (pilot: Riverview Heights / Shree Infra)
- Show we understand their situation: an enquiry arrives at night on WhatsApp, gets buried under 99+ chats; the buyer goes elsewhere. Then: instant auto-reply with brochure + visit link, one board with status + source per enquiry, less chasing. CTA: free sample page, reply YES on WhatsApp.
- Honest framing: "usually within seconds", sample data labelled, case study figure from another industry with disclaimer, no claims about the lead's registrations.
- Format: landing page (mobile first) + 40–60 s captions-first video. Word-by-word Hindi captions + English on-screen text only where needed tested well with the owner; the AI-illustrated version (kie.ai: stills ≈ 4 credits, 4 s clip ≈ 15 credits) costs ≈ US$1.25 per lead — reserve for A-grade leads.

## Channels
- Email first (Resend) with page + video link + wa.me link. WhatsApp after the lead replies/taps; cold WhatsApp templates only per-lead owner-approved (policy risk).
- The old CRM drops template quick-reply taps ("Yes, send the sample") and non-text messages — check how inbound is being captured before relying on replies arriving in the CRM.

## Compliance reminders
DPDP core duties start ~2027-05-13 (may move earlier); no B2B exemption → keep minimal data, opt-out, audit trail. ElevenLabs free-plan audio is not for commercial use; check kie.ai/other asset licences before sending videos to leads.
