# Pricing policy

**The agent never quotes a price, discount, or timeline in any channel.**
When asked: say a colleague will share a proper proposal after a short conversation about their volume and process, and hand the lead off with the question verbatim.

TODO(owner): if you want the agent to give ranges (e.g. "projects like this typically start from ₹X"), write the approved ranges, their conditions, and what the agent may say here — until then this stays empty on purpose.
