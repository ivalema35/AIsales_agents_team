# Proof points — the ONLY claims outbound messages/pages may make about our results

Each item must be quoted with its caveat. If it is not here, we do not claim it.

1. **Takshashila Institute (education, India)** — published case study on ivinfotech.com: *"Admission conversion rate +40%"* after a custom institute ERP with an enquiry + follow-up CRM. Caveats to state: different industry (education, not real estate/clinics); "as published in our case study"; results vary. Never imply the same result for the lead. TODO(owner): confirm the figure and permission to cite by name.
2. **Reply speed on WhatsApp**: say "usually within seconds" (not "instant", not a guarantee).
3. **Free sample / no obligation**: the pilot offer was "a free sample page in about 3 working days — no cost, no obligation" (needs the lead's project/brand details and assets). Only repeat if the owner re-confirms the offer.
4. **What we have built**: Hindi/English kinetic and storybook explainer videos and personalised landing pages (pilot: Riverview Heights page for Shree Infra) — can be described as examples of our work only with the lead's permission; never name another client's private data.

Do **not** claim: number of clients/years/team size, awards, revenue impact for a specific lead, uptime guarantees, compliance/registration status (e.g. RERA) of any lead, or "AI never makes mistakes".
