# Ivinfotech — company facts (source of truth for replies)

> Items marked **TODO(owner)** are not confirmed yet: the agent must say "a colleague will confirm" instead of guessing.

- **Who:** Ivinfotech (IV Infotech), software company in **Mehsana, Gujarat, India** (address printed in our emails: T-332, S Cube, Radhanpur Rd, opp. Bansari Township, Mehsana, Gujarat 384002). Website: https://www.ivinfotech.com
- **What we do:** custom software for businesses — AI automation (WhatsApp auto-reply, lead follow-up, chatbots, workflow automation), custom CRM/ERP, websites and web apps, mobile apps, e-commerce, digital marketing, domain/product-specific systems (e.g. institute/coaching management, booking/POS).
- **How we work:** built around the business's actual process (not a generic template); we start with a small, concrete first release and extend. TODO(owner): standard engagement model (fixed price vs. monthly, support terms).
- **Team / years / clients:** TODO(owner) — do not state numbers until confirmed.
- **Contact for hand-off:** TODO(owner): name, WhatsApp number, email, calling hours of the human who takes over warm leads.
- **Languages we sell in:** English, Hindi, Gujarati, Hinglish.
- **Sender identity for messages:** "Ivinfotech" + the sender mailbox/WhatsApp business number configured in `backend/.env` (never print it).
