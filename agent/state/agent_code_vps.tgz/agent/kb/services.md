# Services (from the CRM `products` table, 2026-10-14; refine with the owner)

| Service | What it is | One-line value | Typical buyers |
|---|---|---|---|
| **AI automation** | Automation of repetitive processes: customer-support chatbots, automated lead follow-up, document/data processing, workflow automation connecting existing tools — built for the business's specific process | Removes repetitive manual work so staff spend time on what needs a human | Enquiry-heavy local businesses (real estate, clinics, coaching, solar, finance), ops-heavy SMEs |
| **WhatsApp auto-reply + lead board** (a packaging of the above that we pitched in the pilot) | Instant first reply with brochure/visit link, qualification, booking, follow-ups, one board with status + source per enquiry | Every enquiry gets a fast first answer and nothing is forgotten | Businesses that run click-to-WhatsApp ads or get enquiries on WhatsApp |
| **Custom CRM / ERP** | Customers, inventory, sales pipelines, internal operations in one system built around how the business works | Replaces scattered Excel/tools | Multi-team SMEs, manufacturers, institutes |
| **Coaching/institute management** | Staff + parent portals, attendance, leave, holidays, homework, exams, fees across branches | Replaces registers/WhatsApp/Excel with one system for every branch | Coaching classes, tuition institutes, academies |
| **Websites** | Custom business website / web application that converts | A site that generates enquiries, not an online business card | Any SMB |
| **Mobile apps** | Custom Android/iOS apps for customers/staff/operations | An app built around the actual workflow | SMBs with an operational or customer-app need |
| **E-commerce** | Custom online store: catalogue, payments, inventory, orders | A store that fits how the business already sells | Retailers/manufacturers selling online |
| **Digital marketing** | Social media management, paid ads, SEO, content | Consistent managed marketing without an in-house team | Local/online businesses wanting more enquiries |
| **Booking / POS (salons etc.)** | Online + time-slot booking, POS, commission management, one-click reports | — | Salons/barbers and similar |

**Pricing:** see `pricing_policy.md` (agent never quotes). **Timelines:** TODO(owner); in the pilot we promised only "a free sample page in about 3 working days".
