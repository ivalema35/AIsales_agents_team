/* Add lead form: tidy the phone number as it is typed, and ignore a second tap on Save. Works without JS too (the server checks everything). */
(function () {
  var form = document.getElementById("lead-form");
  if (!form) { return; }
  var phone = document.getElementById("f-phone");
  if (phone) {
    phone.addEventListener("input", function () {
      var d = phone.value.replace(/\D/g, "");
      if (d.length > 10 && d.indexOf("91") === 0) { d = d.slice(2); }
      if (d.length > 10 && d.charAt(0) === "0") { d = d.slice(1); }
      d = d.slice(0, 10);
      phone.value = d.length > 5 ? d.slice(0, 5) + " " + d.slice(5) : d;
    });
  }
  var sent = false;
  form.addEventListener("submit", function (e) {
    if (sent) { e.preventDefault(); return; }
    sent = true;
    Array.prototype.forEach.call(form.querySelectorAll(".form-actions .btn"), function (b) { b.classList.add("busy"); });
  });
})();
