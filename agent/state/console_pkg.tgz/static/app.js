/* Agent Console - the only scripts: the mobile menu drawer and the product search. No inline scripts (the CSP forbids them). */
(function () {
  "use strict";
  var sidebar = document.getElementById("sidebar");
  var scrim = document.querySelector(".scrim");
  var openers = document.querySelectorAll("[data-open-nav]");

  function setNav(open) {
    if (!sidebar) return;
    sidebar.classList.toggle("open", open);
    if (scrim) scrim.hidden = !open;
    openers.forEach(function (b) { b.setAttribute("aria-expanded", open ? "true" : "false"); });
    document.body.classList.toggle("nav-open", open);
    if (open) { var first = sidebar.querySelector("a"); if (first) first.focus(); }
    else if (openers[0] && document.activeElement && sidebar.contains(document.activeElement)) { openers[0].focus(); }
  }
  document.querySelectorAll("[data-open-nav]").forEach(function (b) { b.addEventListener("click", function () { setNav(true); }); });
  document.querySelectorAll("[data-close-nav]").forEach(function (b) { b.addEventListener("click", function () { setNav(false); }); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") setNav(false); });

  var toggle = document.querySelector("[data-theme-toggle]");
  if (toggle) {
    toggle.addEventListener("click", function () {
      var root = document.documentElement;
      var current = root.getAttribute("data-theme") || (window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark");
      var next = current === "dark" ? "light" : "dark";
      root.setAttribute("data-theme", next);
      try { localStorage.setItem("console-theme", next); } catch (e) { /* ignore */ }
    });
  }

  // Leads: page reload ke baad chuni hui row list me dikhe, aur khuli hui lead par keyboard/screen-reader focus aaye
  var rowNow = document.querySelector(".lead-list .lead-row.sel");
  if (rowNow && rowNow.scrollIntoView) rowNow.scrollIntoView({ block: "nearest" });
  var detail = document.getElementById("lead-detail");
  if (detail && detail.getAttribute("data-explicit")) detail.focus({ preventScroll: true });

  var input = document.querySelector("[data-filter-target]");
  if (input) {
    var items = document.querySelectorAll(input.getAttribute("data-filter-target"));
    // Har item ka search text pehle se bana lo (tick strip ka text hata kar: warna "page" ya "mail" likhne par har lead match ho jaati)
    var haystack = [];
    items.forEach(function (el) {
      var copy = el.cloneNode(true);
      copy.querySelectorAll(".ticks").forEach(function (n) { n.remove(); });
      haystack.push(copy.textContent.toLowerCase());
    });
    var counter = document.querySelector(input.getAttribute("data-filter-count"));
    var empty = document.querySelector(".no-match");
    input.addEventListener("input", function () {
      var q = input.value.trim().toLowerCase(), shown = 0;
      items.forEach(function (el, i) {
        var hit = !q || haystack[i].indexOf(q) !== -1;
        el.hidden = !hit;
        if (hit) shown++;
      });
      if (counter) counter.textContent = shown;
      if (empty) empty.hidden = shown !== 0;
    });
  }
})();
