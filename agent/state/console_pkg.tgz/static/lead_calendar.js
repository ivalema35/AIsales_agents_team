/* Agent Console - Overview "Leads found, day by day": a month calendar shaded by how many leads were found each day (the density), and, beside it,
   the leads of the selected day. The calendar also drives the KPI cards above it: pick a day and Leads found / Outreached / Replies / Engaged show THAT day
   (the numbers for every day arrive in the same JSON, so a click needs no reload). The data comes as JSON in #lc[data-lc] (the CSP forbids inline scripts);
   no library, no network.
   Mobbin references: Plain / Quo heat-map legend (Less ... More), Emergent / Canny month grid, Calendly list + selected-day panel. */
(function () {
  "use strict";
  var root = document.getElementById("lc");
  if (!root) return;
  var data;
  try { data = JSON.parse(root.getAttribute("data-lc") || "{}"); } catch (e) { return; }
  var days = data.days || {};
  var TODAY = data.today;
  var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  var MON3 = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  var DOW = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  var DOW_LONG = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  var ISO = /^\d{4}-\d{2}-\d{2}$/;
  if (!ISO.test(TODAY || "")) return;

  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function iso(y, m, d) { return y + "-" + pad(m + 1) + "-" + pad(d); }            // m is 0-based
  function parse(s) { var p = s.split("-"); return { y: +p[0], m: +p[1] - 1, d: +p[2] }; }
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined && text !== null) n.textContent = text; return n; }
  function plural(n, one, many) { return n + " " + (n === 1 ? one : many); }
  function weekday(y, m, d) { return (new Date(Date.UTC(y, m, d)).getUTCDay() + 6) % 7; }   // Monday = 0
  function daysIn(y, m) { return new Date(Date.UTC(y, m + 1, 0)).getUTCDate(); }
  function shift(s, n) { var p = parse(s), t = new Date(Date.UTC(p.y, p.m, p.d + n)); return iso(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate()); }
  function nice(s) { var p = parse(s); return p.d + " " + MONTHS[p.m] + " " + p.y; }
  function short(s) { var p = parse(s); return p.d + " " + MON3[p.m]; }
  function count(s) { return days[s] ? days[s].n : 0; }
  function monthKey(y, m) { return y + "-" + pad(m + 1); }
  function validDay(s) { return ISO.test(s || "") && s <= TODAY && s >= "2020-01-01"; }

  var t = parse(TODAY), first = parse(ISO.test(data.first || "") ? data.first : TODAY);
  var minIdx = first.y * 12 + first.m, maxIdx = t.y * 12 + t.m;
  var range = data.range || {};                                          // the period the page was opened with, e.g. "the last 7 days"
  var scope = validDay(data.scope) ? data.scope : "";                    // the day the server already shows in the KPI cards ("" = a range, not one day)

  function dayLabel(s) {
    if (s === TODAY) return "today";
    var p = parse(s);
    return DOW_LONG[weekday(p.y, p.m, p.d)] + ", " + p.d + " " + MONTHS[p.m] + (p.y === t.y ? "" : " " + p.y);
  }
  function rangeView() { var p = parse(validDay(range.to) ? range.to : TODAY); return { y: p.y, m: p.m }; }

  // Opening state: a #day=... link wins; else the day the KPI cards already show (Today); else no day at all (a range such as "7 days": the panel lists its leads).
  var sel = (/^#day=(\d{4}-\d{2}-\d{2})$/.exec(location.hash || "") || [])[1];
  if (!validDay(sel)) sel = scope;
  var view = sel ? { y: parse(sel).y, m: parse(sel).m } : rangeView();
  if (view.y * 12 + view.m < minIdx) minIdx = view.y * 12 + view.m;

  // ---- the KPI cards and the "Showing ..." line above the calendar (rendered by the server; we remember what it showed so "Back" can restore it)
  var cards = Array.prototype.slice.call(document.querySelectorAll("[data-kpi]")).map(function (card) {
    var v = card.querySelector(".kpi-value"), s = card.querySelector("[data-kpi-sub]");
    card.addEventListener("animationend", function () { card.classList.remove("is-flash"); });
    return { card: card, v: v, s: s, v0: v ? v.textContent : "", s0: s ? s.textContent : "" };
  });
  var note = document.getElementById("period-note");
  var note0 = note ? note.innerHTML : "";
  var tabOn = Array.prototype.slice.call(document.querySelectorAll(".period-bar .seg a")).filter(function (a) { return a.hasAttribute("aria-current"); })[0] || null;

  function flash(card) {
    card.classList.remove("is-flash");
    void card.offsetWidth;                                               // lets the browser start the animation again
    card.classList.add("is-flash");
  }

  function applyKpis() {
    var onScope = sel === scope;                                         // same as the server's view: put its numbers back
    var vals = onScope ? null : ((data.kpi && data.kpi[sel]) || data.kpi_empty || null);
    cards.forEach(function (k, i) {
      var pair = vals && vals[i];
      var nv = pair ? String(pair[0]) : k.v0, ns = pair ? String(pair[1]) : k.s0;
      if (k.v && k.v.textContent !== nv) { k.v.textContent = nv; flash(k.card); }
      if (k.s) k.s.textContent = ns;
    });
    if (!note) return;
    if (onScope) {
      if (note.innerHTML !== note0) note.innerHTML = note0;               // our own markup, saved at load
      if (tabOn) tabOn.setAttribute("aria-current", "true");
      return;
    }
    if (tabOn) tabOn.removeAttribute("aria-current");                    // none of Today / 7 days / ... is what the cards show now
    note.textContent = "";
    note.appendChild(document.createTextNode("Showing "));
    note.appendChild(el("strong", "", dayLabel(sel)));
    note.appendChild(document.createTextNode(" - the day picked in the calendar. "));
    var back = el("button", "link-btn", "Back to " + (range.label || "today"));
    back.type = "button";
    back.addEventListener("click", function () { choose(scope, false); });
    note.appendChild(back);
  }

  root.textContent = "";
  var cal = el("div", "lc-cal");
  var panel = el("div", "lc-panel");
  panel.setAttribute("aria-live", "polite");
  root.appendChild(cal);
  root.appendChild(panel);

  function monthStats(y, m) {
    var key = monthKey(y, m) + "-", total = 0, busy = "", busyN = 0, k;
    for (k in days) {
      if (days.hasOwnProperty(k) && k.indexOf(key) === 0) {
        total += days[k].n;
        if (days[k].n > busyN || (days[k].n === busyN && k > busy)) { busyN = days[k].n; busy = k; }
      }
    }
    return { total: total, busy: busy, busyN: busyN };
  }

  function navButton(label, glyph, handler, disabled) {
    var b = el("button", "lc-btn", glyph);
    b.type = "button";
    b.setAttribute("aria-label", label);
    b.disabled = !!disabled;
    b.addEventListener("click", handler);
    return b;
  }

  function go(idx) {
    view = { y: Math.floor(idx / 12), m: idx % 12 };
    render(false);
  }

  function choose(s, focus) {
    sel = s;
    if (s) { var p = parse(s); view = { y: p.y, m: p.m }; } else { view = rangeView(); }
    if (view.y * 12 + view.m < minIdx) minIdx = view.y * 12 + view.m;
    // the address carries the day only when it differs from what the server shows, so a plain reload or the period buttons start clean
    try { history.replaceState(null, "", s && s !== scope ? "#day=" + s : location.pathname + location.search); } catch (e) { /* ignore */ }
    render(!!focus);
  }

  function renderCalendar(focusSel) {
    cal.textContent = "";
    var idx = view.y * 12 + view.m, st = monthStats(view.y, view.m);

    var head = el("div", "lc-head");
    var titles = el("div", "lc-titles");
    titles.appendChild(el("h3", "lc-title", MONTHS[view.m] + " " + view.y));
    titles.appendChild(el("p", "lc-sub", st.total ? plural(st.total, "lead", "leads") + " this month" + (st.busyN > 1 ? " · busiest " + short(st.busy) + " (" + st.busyN + ")" : "") : "No leads this month"));
    var nav = el("div", "lc-nav");
    nav.appendChild(navButton("Previous month", "‹", function () { go(idx - 1); }, idx <= minIdx));
    var tb = el("button", "lc-today", "Today");
    tb.type = "button";
    tb.addEventListener("click", function () { choose(TODAY, true); });
    nav.appendChild(tb);
    nav.appendChild(navButton("Next month", "›", function () { go(idx + 1); }, idx >= maxIdx));
    head.appendChild(titles);
    head.appendChild(nav);
    cal.appendChild(head);

    var grid = el("div", "lc-grid");
    grid.setAttribute("role", "group");
    grid.setAttribute("aria-label", MONTHS[view.m] + " " + view.y + ": leads found per day");
    DOW.forEach(function (n) { var c = el("span", "lc-dow", n); c.setAttribute("aria-hidden", "true"); grid.appendChild(c); });

    var offset = weekday(view.y, view.m, 1), total = daysIn(view.y, view.m), cells = Math.ceil((offset + total) / 7) * 7;
    var start = shift(iso(view.y, view.m, 1), -offset), rendered = [];
    var i, s, info, btn, cls, n, p;
    for (i = 0; i < cells; i++) {
      s = shift(start, i);
      p = parse(s);
      n = count(s);
      info = days[s];
      cls = "lc-day lv" + (info ? info.lv : 0);
      if (p.m !== view.m) cls += " is-out";
      if (s === TODAY) cls += " is-today";
      if (s === sel) cls += " is-sel";
      if (s > TODAY) cls += " is-future";
      btn = el("button", cls);
      btn.type = "button";
      btn.setAttribute("data-day", s);
      btn.setAttribute("aria-pressed", s === sel ? "true" : "false");
      btn.setAttribute("aria-label", nice(s) + ": " + (n ? plural(n, "lead", "leads") + " found" : "no leads") + (s === TODAY ? ", today" : ""));
      btn.appendChild(el("span", "lc-dnum", String(p.d)));
      if (n) btn.appendChild(el("span", "lc-count", String(n)));
      if (s > TODAY) btn.disabled = true;
      btn.tabIndex = -1;
      grid.appendChild(btn);
      rendered.push(btn);
    }
    // the one cell the Tab key lands on: the picked day, else today, else the 1st of the month
    var focusBtn = null;
    [sel, TODAY, iso(view.y, view.m, 1)].forEach(function (want) {
      if (focusBtn || !want) return;
      rendered.forEach(function (b) { if (!focusBtn && b.getAttribute("data-day") === want && !b.disabled) focusBtn = b; });
    });
    if (focusBtn) focusBtn.tabIndex = 0;
    grid.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest(".lc-day") : null;
      if (b && !b.disabled) choose(b.getAttribute("data-day"), false);
    });
    grid.addEventListener("keydown", function (e) {
      var b = e.target.closest ? e.target.closest(".lc-day") : null;
      if (!b) return;
      var step = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 }[e.key];
      if (!step) return;
      e.preventDefault();
      var next = shift(b.getAttribute("data-day"), step);
      if (next > TODAY || next < "2020-01-01") return;
      var np = parse(next);
      if (np.y * 12 + np.m < minIdx) return;
      choose(next, true);
    });
    cal.appendChild(grid);
    if (focusSel && focusBtn) focusBtn.focus();

    var legend = el("div", "lc-legend");
    legend.appendChild(el("span", "lc-less", "Less"));
    [0, 1, 2, 3, 4].forEach(function (l) { var sw = el("span", "lc-sw lv" + l); sw.setAttribute("aria-hidden", "true"); legend.appendChild(sw); });
    legend.appendChild(el("span", "lc-more", "More"));
    legend.appendChild(el("span", "lc-key", "Shaded by the leads found each day. Pick a day to update the numbers above."));
    cal.appendChild(legend);
  }

  // One lead in a list. `when` (optional) is the day it was found, shown in front of the city when the list spans several days.
  function leadRow(l, when) {
    var li = el("li");
    var a = el(l.href ? "a" : "div", "lc-lead");
    if (l.href) a.href = l.href;
    a.appendChild(el("span", "lc-av av-" + (l.av || 1), l.initials || "?"));
    var body = el("span", "lc-lead-body");
    body.appendChild(el("strong", "", l.name));
    var meta = [when, l.city, l.campaign].filter(Boolean).join(" · ");
    if (meta) body.appendChild(el("small", "", meta));
    a.appendChild(body);
    var tags = el("span", "lc-lead-tags");
    tags.appendChild(el("span", "chip " + (l.status_chip || "idle"), l.status_label || "New"));
    if (l.grade) tags.appendChild(el("span", "lc-grade g-" + l.grade, l.grade));
    a.appendChild(tags);
    li.appendChild(a);
    return li;
  }

  function leadList(leads, whenOf) {
    var list = el("ul", "lc-list");
    leads.forEach(function (l, i) { list.appendChild(leadRow(l, whenOf ? whenOf(i) : "")); });
    return list;
  }

  function contactedLine(leads) {
    var contacted = 0;
    leads.forEach(function (l) { if (l.contacted) contacted++; });
    return el("p", "lc-stats", contacted + " contacted · " + (leads.length - contacted) + " not contacted yet");
  }

  // Empty panel: offer the days that do have leads (the latest one, and the busiest if that is another day).
  function jumpButtons(box) {
    var jumps = [];
    if (data.default && data.default !== sel && count(data.default)) jumps.push(["Show the latest leads", data.default]);
    if (data.busiest && data.busiest !== sel && data.busiest !== data.default) jumps.push(["Show the busiest day", data.busiest]);
    jumps.forEach(function (j) {
      var b = el("button", "btn small", j[0] + " (" + short(j[1]) + ", " + plural(count(j[1]), "lead", "leads") + ")");
      b.type = "button";
      b.addEventListener("click", function () { choose(j[1], false); });
      box.appendChild(b);
    });
  }

  function panelHead(kicker, title, n) {
    var head = el("div", "lc-dayhead");
    var left = el("div", "lc-dayhead-text");
    left.appendChild(el("p", "kicker", kicker));
    left.appendChild(el("h3", "lc-daytitle", title));
    head.appendChild(left);
    head.appendChild(el("span", "chip " + (n ? "ok" : "idle"), n ? plural(n, "lead", "leads") + " found" : "No leads"));
    panel.appendChild(head);
  }

  // A picked day: its leads.
  function renderDayPanel() {
    var info = days[sel], n = info ? info.n : 0, p = parse(sel);
    panelHead(DOW_LONG[weekday(p.y, p.m, p.d)] + (sel === TODAY ? " · Today" : ""), nice(sel), n);

    if (!n) {
      var empty = el("div", "lc-empty");
      empty.appendChild(el("p", "lc-empty-title", sel === TODAY ? "No leads found today yet" : "No leads were found on this day"));
      empty.appendChild(el("p", "muted", "The agent adds leads when its research runs. Pick a shaded day to see them, or add one yourself."));
      var add = el("a", "btn primary small", "Add a lead on " + short(sel));
      add.href = addHref(sel);
      empty.appendChild(add);
      jumpButtons(empty);
      panel.appendChild(empty);
      return;
    }
    panel.appendChild(contactedLine(info.leads));
    var list = leadList(info.leads);
    panel.appendChild(list);
    if (list.scrollHeight > list.clientHeight + 2) list.classList.add("is-scroll");    // more leads than fit: the last row fades out to say "scroll"
  }

  // No day picked (the page was opened on a range such as "7 days"): the leads found in that range, newest day first.
  function renderRangePanel() {
    var from = ISO.test(range.from || "") ? range.from : "", to = validDay(range.to) ? range.to : TODAY, rows = [], k, i = 0;
    for (k in days) {
      if (days.hasOwnProperty(k) && (!from || k >= from) && k <= to) {
        days[k].leads.forEach(function (l) { rows.push({ day: k, lead: l, i: i++ }); });
      }
    }
    rows.sort(function (a, b) { return a.day < b.day ? 1 : a.day > b.day ? -1 : a.i - b.i; });
    var leads = rows.map(function (r) { return r.lead; });
    panelHead("Date filter", range.title || "This period", rows.length);

    if (!rows.length) {
      var empty = el("div", "lc-empty");
      empty.appendChild(el("p", "lc-empty-title", "No leads were found in this period"));
      empty.appendChild(el("p", "muted", "Pick a day in the calendar to see its leads and numbers."));
      jumpButtons(empty);
      panel.appendChild(empty);
      return;
    }
    panel.appendChild(contactedLine(leads));
    panel.appendChild(el("p", "lc-hint", "Pick a day in the calendar to see only that day, and its numbers above."));
    var list = leadList(leads, function (idx) { return short(rows[idx].day); });
    panel.appendChild(list);
    if (list.scrollHeight > list.clientHeight + 2) list.classList.add("is-scroll");
  }

  function renderPanel() {
    panel.textContent = "";
    if (sel) renderDayPanel(); else renderRangePanel();
  }

  // The "Add lead" button always adds to the day that is picked in the calendar (today when none is picked).
  function addHref(day) { return "/leads/new?from=overview&date=" + (validDay(day) ? day : TODAY); }
  function updateAddButton() {
    var a = document.getElementById("lc-add");
    if (a) a.setAttribute("href", addHref(sel));
  }

  function render(focusSel) {
    renderCalendar(focusSel);
    renderPanel();
    applyKpis();
    updateAddButton();
  }
  render(false);

  // A #day=... address typed or pasted while the page is already open (a link to a day): follow it. replaceState in choose() never fires this, so there is no loop.
  window.addEventListener("hashchange", function () {
    var h = (/^#day=(\d{4}-\d{2}-\d{2})$/.exec(location.hash || "") || [])[1];
    if (validDay(h) && h !== sel) choose(h, false);
  });
})();
