/* Runs in <head>, before the page is painted, so the saved light/dark choice never flashes. With no saved choice the system setting decides (CSS). */
(function () {
  "use strict";
  try {
    var saved = localStorage.getItem("console-theme");
    if (saved === "light" || saved === "dark") document.documentElement.setAttribute("data-theme", saved);
  } catch (e) { /* private mode: the system setting is used */ }
})();
