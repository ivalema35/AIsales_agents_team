# -*- coding: utf-8 -*-
"""Overview ka "Leads found, day by day" calendar ke liye pure helpers (koi Flask/DB nahi, isliye aasaani se test hote hain). Used by console/app.py (route /).

Har din ke liye: us din kitni leads mili (density -> calendar ka rang) aur wo leads kaun si thi (right panel). Page ko ek hi JSON milta hai (data-lc attribute),
baaki month badalna / din chunna browser me hota hai (static/lead_calendar.js), isliye click par page reload nahi hota.

"Lead kis din mili": pehle agent ka likha `researched` date (YYYY-MM-DD...; wahi din jab research hua), warna entry banne ka din (IST). Future ya ajeeb date ignore.
"""
import re
from datetime import date, datetime, timezone

import leads_view as lv

MIN_SCALE = 4          # ek akeli lead wala din halka rehta hai: gehra rang tab jab ek din me kaafi leads hon
DATE_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})")


def _iso_day(value):
    """'2026-10-15' ya '2026-10-28 (daily run ...)' -> date, warna None."""
    m = DATE_RE.match(value.strip()) if isinstance(value, str) else None
    if not m:
        return None
    try:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def found_day(entry, tz, today):
    """Lead ka 'mili' wala din (date) ya None. Future date (aaj se aage) aur 2020 se purani date ko sahi nahi maante."""
    data = entry.get("data") if isinstance(entry.get("data"), dict) else {}
    day = _iso_day(data.get("researched"))
    if day is None:
        moment = lv.parse_time(entry.get("created_at"))
        day = moment.astimezone(tz).date() if moment else None
    if day is None or day > today or day.year < 2020:
        return None
    return day


def group_by_day(items, tz, today):
    """Entries (activities) ko unke IST din ke hisaab se baantta hai -> {"2026-10-27": [entry, ...]}. Overview ke KPI cards har din ke liye isi se bante hain.
    Aaj se aage ka din, 2020 se purana din, aur jis entry ka time samajh na aaye, wo chhod diye jaate hain."""
    out = {}
    for item in items:
        moment = lv.parse_time(item.get("created_at"))
        if moment is None:
            continue
        day = moment.astimezone(tz).date()
        if day > today or day.year < 2020:
            continue
        out.setdefault(day.isoformat(), []).append(item)
    return out


def level_for(n, scale):
    """Leads ki ginti -> rang ka level 0..4 (0 = koi lead nahi)."""
    if n <= 0:
        return 0
    ratio = n / float(scale)
    return 1 if ratio <= 0.25 else 2 if ratio <= 0.5 else 3 if ratio <= 0.75 else 4


def avatar_class(seed):
    """Naam / campaign se ek stable rang (1..6): Python ka hash() har run me badalta hai, isliye apna simple checksum."""
    return 1 + sum(ord(c) for c in str(seed or "?")) % 6


def lead_lite(entry, href=""):
    p = lv.prepare_light(entry)
    return {"id": p["id"], "name": p["name"], "initials": p["initials"], "city": p["city"], "campaign": p["campaign"], "grade": p["grade"],
            "status": p["status"], "status_label": p["status_label"], "status_chip": p["status_chip"], "contacted": bool(p["contacted"]),
            "href": href, "av": avatar_class(p["campaign"] or p["name"])}


def _order(item):
    return (lv.GRADE_RANK.get(item["grade"], 9), item["name"].lower())


def build(lead_entries, today, tz, href_for=None):
    """Lead entries -> ek dict jo template JSON bana ke JS ko deta hai.
    days = {"2026-10-27": {"n": 4, "lv": 2, "leads": [..]}}, peak = sabse zyada leads ek din me, total, default = jo din pehle khulta hai
    (aaj agar aaj leads mili, warna aakhri din jab leads mili, warna aaj), first = sabse purana din (month navigation ki seema)."""
    href_for = href_for or (lambda _eid: "")
    grouped = {}
    for entry in lead_entries:
        day = found_day(entry, tz, today)
        if day is not None:
            grouped.setdefault(day.isoformat(), []).append(lead_lite(entry, href_for(entry.get("id"))))
    days = {iso: {"n": len(items), "leads": sorted(items, key=_order)} for iso, items in grouped.items()}
    peak = max((d["n"] for d in days.values()), default=0)
    scale = max(peak, MIN_SCALE)
    for d in days.values():
        d["lv"] = level_for(d["n"], scale)
    today_iso = today.isoformat()
    busiest = max(days.items(), key=lambda kv: (kv[1]["n"], kv[0]))[0] if days else ""
    return {"today": today_iso, "first": min(days) if days else today_iso, "default": today_iso if today_iso in days else (max(days) if days else today_iso),
            "busiest": busiest, "peak": peak, "total": sum(d["n"] for d in days.values()), "days": days}
