# -*- coding: utf-8 -*-
"""Leads page ke liye pure helper functions (koi Flask/DB nahi) - isliye aasaani se test ho jaate hain. Used by console/app.py (route /leads).

Lead entries agent likhta hai, to koi bhi field kabhi bhi missing ya galat type ka ho sakta hai: `prepare()` har entry ko ek safe view-model me badalta hai
(text hamesha string, lists hamesha list of string, links sirf tab jab scheme safe ho). Template sirf isi view-model ko dekhta hai.
"""
import math
import re
from datetime import datetime, timedelta, timezone

GRADE_RANK = {"A": 0, "B": 1, "C": 2}
# "Hunger" = kitni pyaas (pain) hai, SIRF public evidence se; agent score + reasons likhta hai. Hungry pehle (unhe pehle message jaata hai), phir Warm, phir Cold.
LANG_LABEL = {"en": "English", "gu": "Gujarati", "hi": "Hindi"}
TIER_RANK = {"hungry": 0, "warm": 1, "cold": 2}
TIER_LABEL = {"hungry": "Hungry", "warm": "Warm", "cold": "Cold"}
TIER_CHIP = {"hungry": "ok", "warm": "warn", "cold": "idle"}
# status -> chip colour (CSS classes in app.css: ok / warn / bad / idle / neutral)
STATUS_CHIP = {"new": "idle", "researched": "idle", "ready": "warn", "queued": "warn", "approved": "warn", "contacted": "ok", "sent": "ok",
               "replied": "ok", "interested": "ok", "meeting": "ok", "won": "ok", "lost": "bad", "rejected": "bad", "do_not_contact": "bad", "hold": "warn"}
NEXT_STEP = {"new": "Needs research", "researched": "Waiting for your review", "ready": "Ready for your OK", "queued": "Queued to send", "approved": "Approved to send",
             "contacted": "Waiting for a reply", "sent": "Waiting for a reply", "replied": "Needs a human reply", "interested": "Book a call"}
# Status ka seedha, non-tech bhasha me matlab (list ki row aur "Where it stands" me dikhta hai)
STAGE_PLAIN = {"new": "New, not researched yet", "researched": "Not contacted yet", "ready": "Message ready for your OK", "queued": "Queued to send", "approved": "Approved, sending soon",
               "contacted": "Message sent, waiting for a reply", "sent": "Message sent, waiting for a reply", "replied": "Replied: needs a human reply",
               "interested": "Interested: book a call", "meeting": "Call booked", "won": "Won", "lost": "Lost", "hold": "On hold", "rejected": "Do not contact",
               "do_not_contact": "Do not contact"}
# In statuses me hum pakka jaante hain ki abhi koi message nahi gaya / gaya hai. Agent apne naye status bana sakta hai: unke liye "Not contacted yet" kabhi nahi dikhate.
NOT_CONTACTED = {"new", "researched", "ready", "queued", "approved", "hold"}
CONTACTED = {"contacted", "sent", "replied", "interested", "meeting", "won", "lost"}
KIND_LABEL = {"email": "Email", "phone": "Phone", "mobile": "Mobile", "tel": "Phone", "whatsapp": "WhatsApp", "form": "Form", "url": "Link", "website": "Website",
              "site": "Website", "link": "Link", "facebook": "Facebook", "facebook_page": "Facebook page", "instagram": "Instagram", "linkedin": "LinkedIn",
              "maps": "Google Maps", "google_maps": "Google Maps", "contact_person": "Contact person", "address": "Address"}

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"\+?\d[\d\s\-().]{8,17}\d")
URL_KINDS = {"form", "url", "website", "site", "link", "facebook", "facebook_page", "instagram", "linkedin", "maps", "google_maps"}
ICONS = {"email": "mail", "whatsapp": "chat", "phone": "phone", "mobile": "phone", "tel": "phone"}


def text(value, limit=800):
    """Kisi bhi value ko safe, trimmed string banata hai. dict/list jaisi cheezein ignore (khali string)."""
    if isinstance(value, bool) or value is None or isinstance(value, (dict, list, tuple, set)):
        return ""
    s = re.sub(r"\s+", " ", str(value)).strip()
    return s if len(s) <= limit else s[: limit - 1].rstrip() + "..."


def text_list(value, limit=600, maxn=12):
    """String ya list -> list of non-empty trimmed strings (max maxn). Pehle slice karte hain, taaki bahut lambi list se bekaar kaam na ho."""
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, (list, tuple)):
        return []
    out = [text(v, limit) for v in list(value)[: maxn * 3]]
    return [v for v in out if v][:maxn]


def grade_of(data):
    g = text(data.get("grade"), 8).upper()
    return g if g in GRADE_RANK else ("X" if g == "REJECT" else "")


def tier_of(data):
    t = text(data.get("hunger_tier") or data.get("tier"), 12).lower()
    return t if t in TIER_RANK else ""


def score_of(value):
    """0-10 ka int, warna None (agent ne kuch bhi likha ho)."""
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
        return max(0, min(10, int(round(number)))) if math.isfinite(number) else None     # JSON me NaN / Infinity bhi aa sakte hain
    except (TypeError, ValueError, OverflowError):
        return None


def initials(name):
    words = re.findall(r"[A-Za-z0-9]+", text(name, 80))
    return ("".join(w[0] for w in words[:2]) or "?").upper()


def safe_url(value):
    """Sirf http(s) link jisme space/quote/angle bracket na ho; baaki sab (javascript:, data:, mailto: ...) khali."""
    v = text(value, 400)
    return v if re.match(r"^https?://[^\s<>\"']+$", v, re.I) else ""


def _phone(value):
    """Pehla phone number -> (digits with country code, is_toll_free). Pehchan na ho to ("", False): tab sirf plain text dikhta hai, galat link nahi banta."""
    m = PHONE_RE.search(text(value, 200))
    if not m:
        return "", False
    raw = m.group(0).strip()
    d = re.sub(r"\D", "", raw)
    if raw.startswith("+"):                                  # +91 97144 42928 : country code likha hua hai
        return (d, False) if 10 <= len(d) <= 15 else ("", False)
    if d.startswith("00"):                                   # 0091 ...
        d = d[2:]
        return (d, False) if 10 <= len(d) <= 15 else ("", False)
    if len(d) == 11 and d.startswith("1800"):                # India toll-free: sirf India ke andar se lagta hai, +91 prefix nahi
        return d, True
    if len(d) == 10:                                         # 97144 42928
        return "91" + d, False
    if len(d) == 11 and d.startswith("0"):                   # 0261 2345678 (STD landline) ya 09714442928: leading 0 hatao
        return "91" + d[1:], False
    if len(d) == 12 and d.startswith("91"):                  # 919714442928 (plus ke bina)
        return d, False
    return "", False


def contact_link(kind, value):
    """(href, icon_name) for one contact. href is "" when no safe link can be made (the value is then shown as plain text)."""
    k = text(kind, 30).lower().replace(" ", "_")
    icon = ICONS.get(k, "globe" if k in URL_KINDS else "users")
    if k == "email":
        m = EMAIL_RE.search(text(value, 200))
        return ("mailto:" + m.group(0) if m else ""), icon
    if k == "whatsapp":
        d, toll_free = _phone(value)
        return ("https://wa.me/" + d if d and not toll_free else ""), icon
    if k in ("phone", "mobile", "tel"):
        d, toll_free = _phone(value)
        return (("tel:" + d if toll_free else "tel:+" + d) if d else ""), icon
    return (safe_url(value) if k in URL_KINDS else ""), icon


def _kind_label(kind):
    k = text(kind, 30).lower().replace(" ", "_")
    return KIND_LABEL.get(k) or (k.replace("_", " ").capitalize() if k else "Contact")


def _contacted(value, status):
    """True / False / None (= pata nahi). Agent 'contacted' ko bool, 0/1, "yes", ya date string ke roop me likh sakta hai."""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str) and value.strip():
        return value.strip().lower() not in ("false", "no", "0", "none", "null", "n")
    if status in CONTACTED:
        return True
    if status in NOT_CONTACTED:
        return False
    return None


def slug_of(d):
    """The landing-page slug of a lead (page_slug, or the last part of page_url .../campaign/<slug>): the key of its engagement entry."""
    m = re.search(r"(?:/campaign/|^)([a-z0-9][a-z0-9-]{5,60})/?$", text(d.get("page_slug") or d.get("page_url"), 200))
    return m.group(1) if m else ""


ENG_LABEL = {"hot": "Hot signal", "engaged": "Engaged", "read": "Read it", "delivered": "Delivered", "sent": "Sent", "failed": "Not delivered", "stopped": "Asked to stop"}
ENG_CHIP = {"hot": "ok", "engaged": "ok", "read": "warn", "delivered": "idle", "sent": "idle", "failed": "bad", "stopped": "bad"}
IST = timezone(timedelta(hours=5, minutes=30))


def parse_time(value):
    """ISO time string -> timezone-aware datetime, ya None. Garbage, galat type aur 9999 jaise saal (astimezone me OverflowError) - kuch bhi crash nahi karta.
    Timezone na likha ho to UTC maante hain (agent hamesha UTC 'Z' likhta hai)."""
    if not isinstance(value, str) or not value.strip() or len(value) > 40:
        return None
    try:
        moment = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
        if moment.tzinfo is None:
            moment = moment.replace(tzinfo=timezone.utc)
        moment.astimezone(IST)
        return moment
    except (ValueError, OverflowError, OSError):
        return None


def ist_label(value):
    """2026-10-16T09:39:35Z -> '16 Oct, 3:09 PM' (IST); anything unreadable -> ''."""
    moment = parse_time(value if isinstance(value, str) else str(value))
    if moment is None:
        return ""
    moment = moment.astimezone(IST)
    return "%d %s, %d:%02d %s" % (moment.day, MONTHS[moment.month - 1], (moment.hour % 12) or 12, moment.minute, "AM" if moment.hour < 12 else "PM")


def engagement_chip(entry):
    """Small chip for the list row, or None."""
    d = entry.get("data") if isinstance(entry, dict) and isinstance(entry.get("data"), dict) else None
    level = text(d.get("level"), 20) if d else ""
    return {"level": level, "label": ENG_LABEL[level], "chip": ENG_CHIP[level]} if level in ENG_LABEL else None


def prepare_engagement(entry):
    """The 'Since we messaged them' card: headline, next step and a short plain-English timeline. Every string is clipped; nothing is trusted as HTML."""
    d = entry.get("data") if isinstance(entry, dict) and isinstance(entry.get("data"), dict) else None
    chip = engagement_chip(entry)
    if not d or not chip:
        return None
    signals = []
    for s in (d.get("signals") if isinstance(d.get("signals"), list) else [])[:30]:
        if isinstance(s, dict) and text(s.get("text"), 200):
            signals.append({"when": ist_label(s.get("at")), "text": text(s.get("text"), 200)})
    return {**chip, "headline": text(d.get("headline"), 220), "next": text(d.get("next"), 260), "signals": signals, "updated": ist_label(d.get("updated") or entry.get("updated_at"))}


# =====================================================================================================================
# JOURNEY: WhatsApp jaise "kitna aage gaya" (sent -> delivered -> read ...) har channel ke liye. Input = engagement entry ka `data`
# (agent/engagement/engagement_sync.py likhta hai, har 5 min). Rule: koi step tabhi "done" hota hai jab data usse PROVE kare - khali, None, galat type ya
# kachra value kabhi "done" nahi banti. Kuch bhi galat ho to crash nahi, bas wo step "pending" rehta hai.
# =====================================================================================================================
# Meta ke delivery-failure codes ka seedha matlab (owner ko code nahi, wajah dikhani hai)
WA_FAIL_REASON = {
    131049: "Meta did not deliver this marketing message (the person has not engaged with business messages recently)",
    131026: "That number cannot receive WhatsApp messages (not on WhatsApp, or an old app)",
    131050: "They opted out of marketing messages",
    131047: "The 24-hour reply window is closed",
}
EMAIL_STATUSES = ("sent", "delivered", "opened", "clicked", "bounced", "failed", "complained")
DEMO_RESULTS = ("yes", "person", "done", "later", "unclear", "stopped")
DEMO_RESULT_WORDS = {"yes": "Said yes, contact me", "person": "Asked to talk to a person", "done": "Went through it", "later": "Said not now", "unclear": "Answers were unclear"}
STATE_WORD = {"done": "", "pending": "not yet", "failed": "failed", "skipped": "not reached"}
STOP_RE = re.compile(r"^\s*(stop|unsubscribe)\b(?:\s+(?:sending|messaging|messages?|texting|contacting|emailing|please|now|all|it|this)\b.*|[\s.!]*)$", re.I)   # "STOP", "Stop sending me messages" yes; "Stop by tomorrow" / "Stopping by" no                    # engagement_sync bhi STOP isi tarah pehchanta hai
WA_WAIT_MINUTES = 30                                         # itni der tak delivered/read/failed kuch na aaye to "waiting for WhatsApp" likhte hain


def _dict(value):
    return value if isinstance(value, dict) else {}


def _yes(value):
    """Sirf asli True (ya int 1) - "yes" / "true" jaisi strings ya 2, 3.5 kabhi proof nahi."""
    return value is True or (type(value) is int and value == 1)


def _count(value, cap=1000000):
    """Number (int / float) -> 0..cap ka int. String, bool, list, NaN, Infinity - sab 0 (proof nahi)."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return 0
    try:
        return max(0, min(cap, int(value)))
    except (TypeError, ValueError, OverflowError):
        return 0


def _good_time(value):
    """Value ek asli ISO time ho to wahi string, warna ''. Yehi "proof" hai ki wo cheez hui."""
    return value.strip() if parse_time(value) is not None else ""


def _good_times(value, maxn=60):
    """List of ISO time strings -> sirf valid wale, purane pehle."""
    if not isinstance(value, list):
        return []
    good = [_good_time(v) for v in value[:maxn]]
    return sorted((v for v in good if v), key=parse_time)


def meta_code(value):
    """Meta error code (int, ya digits wali string) -> int, warna None."""
    if isinstance(value, bool):
        return None
    if isinstance(value, str) and re.fullmatch(r"\d{1,9}", value.strip()):
        return int(value.strip())
    if isinstance(value, int) and 0 <= value <= 999999999:
        return value
    return None


def wa_fail_reason(code):
    """Meta code -> plain-English wajah. Naya/unknown code bhi number ke saath dikhta hai, taaki koi support se pooch sake."""
    number = meta_code(code)
    if number in WA_FAIL_REASON:
        return WA_FAIL_REASON[number]
    return "WhatsApp could not deliver it (code %s)" % (number if number is not None else "unknown")


def _facts(raw):
    """Engagement data -> chhote, safe, flat facts (bool / count / valid ISO string). Journey, ticks aur pipeline teeno yahin se padhte hain."""
    d = _dict(raw)
    web, demo, mail = _dict(d.get("web")), _dict(d.get("demo")), _dict(d.get("email"))
    f = {}
    # ---- WhatsApp
    wa_times = _good_times(d.get("wa_sent_times"))
    first = _good_time(d.get("wa_sent_at")) or (wa_times[0] if wa_times else "")
    if not first and "wa_sent_at" not in d and not mail:         # purani entry: sirf sent_at, aur email nahi -> wo WhatsApp ka hi send hai
        first = _good_time(d.get("sent_at"))
    f["wa_first"] = first
    f["wa_count"] = max(len(wa_times), 1 if first else 0)
    f["wa_delivered_at"], f["wa_read_at"] = _good_time(d.get("delivered_at")), _good_time(d.get("read_at"))
    f["wa_read"] = bool(f["wa_read_at"])
    f["wa_delivered"] = bool(f["wa_delivered_at"]) or f["wa_read"]       # read ho gaya to deliver ho hi chuka hai
    failed = _dict(d.get("failed"))
    f["wa_failed"] = {"at": _good_time(failed.get("at")), "code": failed.get("code")} if failed else None
    f["wa_sent"] = bool(first or f["wa_delivered"] or f["wa_failed"])     # delivered / failed tabhi hota hai jab send hua ho
    # ---- Email
    mail_times = _good_times(mail.get("sent_times"))
    f["mail_first"] = _good_time(mail.get("sent_at")) or (mail_times[0] if mail_times else "")
    status = text(mail.get("status"), 20).lower()
    f["mail_status"] = status if status in EMAIL_STATUSES else "sent"
    f["mail"] = bool(f["mail_first"] or f["mail_status"] != "sent")
    f["mail_count"] = max(len(mail_times), _count(mail.get("count"), 1000))
    f["mail_event_at"], f["mail_delivered_at"] = _good_time(mail.get("event_at")), _good_time(mail.get("delivered_at"))
    f["spam"] = f["mail_status"] == "complained"
    # ---- Landing page (hamare apne web log se)
    f["opens"] = _count(web.get("opens"), 100000)
    f["first_open"] = _good_time(web.get("first_open"))
    f["mobile"], f["in_whatsapp"] = _yes(web.get("mobile")), _yes(web.get("in_whatsapp"))
    f["video_depth"] = 4 if _yes(web.get("video_end")) else 3 if _yes(web.get("video_p75")) else 2 if _yes(web.get("video_p50")) else 1 if _yes(web.get("video_p25")) else 0
    f["video"] = _yes(web.get("video_played")) or f["video_depth"] > 0
    f["calc"] = _yes(web.get("calc"))
    cta = web.get("cta")
    f["cta"] = isinstance(cta, list) and any(text(c, 40) for c in cta[:20])
    f["cta_at"] = _good_time(web.get("cta_at"))
    f["page_opened"] = bool(f["opens"] or f["first_open"] or f["video"] or f["calc"] or f["cta"])      # video / calculator / button ke beacons bhi page khulne ka saboot hain
    # ---- Conversation
    taps = []
    for t in (d.get("taps") if isinstance(d.get("taps"), list) else [])[:60]:
        raw_label = _dict(t).get("label")
        label = text(raw_label, 60) if isinstance(raw_label, str) else ""         # sirf asli string label proof hai (float nan / list / None nahi)
        if label:
            taps.append({"at": _good_time(t.get("at")), "label": label, "stop": bool(STOP_RE.match(label))})
    f["taps_real"] = [t for t in taps if not t["stop"]]
    f["taps_stop"] = [t for t in taps if t["stop"]]
    result = text(demo.get("result"), 12).lower()
    f["demo_result"] = result if result in DEMO_RESULTS else ""
    f["demo_started"], f["demo_finished_at"], f["demo_updated_at"] = _good_time(demo.get("started_at")), _good_time(demo.get("finished_at")), _good_time(demo.get("updated_at"))
    f["demo_step"], f["demo_status"] = text(demo.get("step"), 30), text(demo.get("status"), 20).lower()
    f["demo"] = bool(f["demo_started"] or f["demo_step"] or f["demo_status"] or f["demo_result"])
    f["demo_reached"] = _yes(demo.get("reached_cta"))
    f["demo_finished"] = f["demo_result"] in DEMO_RESULT_WORDS or (f["demo"] and f["demo_reached"])
    f["handoff"] = _yes(d.get("handoff"))
    f["person"] = f["demo_result"] in ("yes", "person") or f["handoff"]
    f["stopped"] = _yes(d.get("stopped")) or f["demo_result"] == "stopped" or bool(f["taps_stop"])
    f["replied"] = bool(f["taps_real"]) or f["demo"] or f["handoff"]       # demo sirf tab shuru hota hai jab unhone khud likha / button dabaya
    # ---- Overall
    f["any_sent"] = bool(f["wa_sent"] or f["mail"] or _good_time(d.get("sent_at")))
    channels = []                                                           # kya hamare try kiye har channel ne dum tod diya?
    if f["wa_sent"]:
        channels.append(bool(f["wa_failed"]) and not f["wa_delivered"])
    if f["mail"]:
        channels.append(f["mail_status"] in ("bounced", "failed"))
    f["all_dead"] = bool(channels) and all(channels)
    return f


def _progress(f):
    """Sabse aage ka stage -> (rank, key, plain text). Stopped / spam / sab-failed ho to wo sabse upar dikhta hai."""
    if f["cta"]:
        page_text = "Tapped the WhatsApp button on their page"
    elif f["video_depth"] >= 4:
        page_text = "Watched the whole video"
    elif f["video"]:
        page_text = "Played the video"
    elif f["calc"]:
        page_text = "Used the calculator"
    elif f["page_opened"]:
        page_text = "Opened their page"
    else:
        page_text = "Clicked a link in the email"
    ladder = (
        (1, "sent", "Message sent", f["any_sent"]),
        (2, "delivered", "Delivered", f["wa_delivered"] or f["mail_status"] in ("delivered", "opened", "clicked")),
        (3, "read", "Read the message" if f["wa_read"] else "Opened the email", f["wa_read"] or f["mail_status"] in ("opened", "clicked")),
        (4, "page", page_text, f["page_opened"] or f["mail_status"] == "clicked"),
        (5, "replied", "Replied or tapped a button", f["replied"]),
        (6, "demo", "Started the demo", f["demo"]),
        (7, "demo_done", "Finished the demo", f["demo_finished"]),
        (8, "person", "Asked for a person", f["person"]),
    )
    rank, key, label = 0, "none", "Nothing sent yet"
    for r, k, t, proven in ladder:
        if proven and r > rank:
            rank, key, label = r, k, t
    if f["stopped"]:
        return rank, "stopped", "Asked to stop"
    if f["spam"]:
        return rank, "stopped", "Marked our email as spam"
    if rank <= 1 and f["all_dead"]:
        return rank, "failed", "Could not be delivered"
    return rank, key, label


def _step(label, state, glyph="", at="", detail=""):
    """Ek step. Time aur glyph sirf done/failed me aate hain; `aria` screen-reader ke liye poori line ("Delivered, 16 Oct, 4:34 PM")."""
    at = at if state in ("done", "failed") else ""
    glyph = "x" if state == "failed" else (glyph if state == "done" else "")
    spoken = label + (", " + STATE_WORD[state] if STATE_WORD[state] else "") + (", " + at if at else "") + (". " + detail if detail else "")
    return {"label": label, "state": state, "glyph": glyph, "at": at, "detail": detail, "aria": spoken}


def _group(key, title, steps, summary, chip, note=""):
    return {"key": key, "title": title, "steps": steps, "summary": summary, "chip": chip, "note": note}


def _wa_group(f, now):
    delivered, read, failed = f["wa_delivered"], f["wa_read"], f["wa_failed"]
    failed = failed if failed and not delivered else None                  # delivered ho chuka hai to failure kisi doosre send ka hai
    steps = [_step("Sent", "done", "1", ist_label(f["wa_first"]), "Sent %d times" % f["wa_count"] if f["wa_count"] > 1 else "")]
    note = ""
    if delivered:
        steps.append(_step("Delivered", "done", "2", ist_label(f["wa_delivered_at"])))
    elif failed:
        steps.append(_step("Delivered", "failed", "x", ist_label(failed["at"]), wa_fail_reason(failed["code"])))
    else:
        first = parse_time(f["wa_first"])
        waiting = first is not None and (now - first) > timedelta(minutes=WA_WAIT_MINUTES)
        steps.append(_step("Delivered", "pending", detail="Sent: waiting for WhatsApp to confirm delivery" if waiting else ""))
    if read:
        steps.append(_step("Read", "done", "2blue", ist_label(f["wa_read_at"])))
    else:
        steps.append(_step("Read", "skipped" if failed else "pending"))
    if f["wa_failed"] and delivered:
        note = "Another message we sent could not be delivered: " + wa_fail_reason(f["wa_failed"]["code"])
    summary, chip = ("Read", "ok") if read else ("Delivered", "idle") if delivered else ("Not delivered", "bad") if failed else ("Sent", "idle")
    return _group("wa", "WhatsApp message", steps, summary, chip, note)


def _mail_group(f):
    status = f["mail_status"]
    rank = {"sent": 0, "delivered": 1, "opened": 2, "clicked": 3}.get(status)
    event = ist_label(f["mail_event_at"])
    steps = [_step("Sent", "done", "1", ist_label(f["mail_first"]), "Sent %d times" % f["mail_count"] if f["mail_count"] > 1 else "")]
    note = "Mail apps often open emails by themselves, so an open does not prove it was read: a page visit is the surer sign"
    if status in ("bounced", "failed"):
        steps += [_step("Delivered", "failed", "x", event, "Bounced: that address does not accept mail"), _step("Opened", "skipped"), _step("Clicked", "skipped")]
        return _group("email", "Email", steps, "Bounced", "bad")
    if status == "complained":                                              # spam complaint tabhi aati hai jab mail inbox me pahunchi ho
        steps += [_step("Delivered", "done", "2", ist_label(f["mail_delivered_at"])), _step("Marked as spam", "failed", "x", event, "Marked our email as spam")]
        return _group("email", "Email", steps, "Marked as spam", "bad")
    steps.append(_step("Delivered", "done" if rank >= 1 else "pending", "2", ist_label(f["mail_delivered_at"]) or (event if status == "delivered" else "")))
    # grey ticks only: the BLUE double tick means "read" on WhatsApp and nothing about an email open proves a person read it (review 2026-10-19)
    steps.append(_step("Opened", "done" if rank >= 2 else "pending", "2", event if status == "opened" else ""))
    steps.append(_step("Clicked", "done" if rank >= 3 else "pending", "2", event if status == "clicked" else ""))
    summary, chip = {"clicked": ("Clicked", "ok"), "opened": ("Opened", "idle"), "delivered": ("Delivered", "idle")}.get(status, ("Sent", "idle"))
    return _group("email", "Email", steps, summary, chip, note)


def _page_group(f):
    opened = f["page_opened"]
    parts = []
    if f["opens"]:
        parts.append("once" if f["opens"] == 1 else "%d times" % f["opens"])
    if opened and f["in_whatsapp"]:
        parts.append("from WhatsApp")
    if opened and f["mobile"]:
        parts.append("on a phone")
    video_words = {4: "Watched to the end", 3: "75% watched", 2: "50% watched", 1: "25% watched"}.get(f["video_depth"], "Started playing")
    steps = [
        _step("Opened the page", "done" if opened else "pending", "check", ist_label(f["first_open"]), ", ".join(parts)),
        _step("Played the video", "done" if f["video"] else "pending", "check", "", video_words if f["video"] else ""),
        _step("Used the calculator", "done" if f["calc"] else "pending", "check"),
        _step("Tapped the WhatsApp button on the page", "done" if f["cta"] else "pending", "check", ist_label(f["cta_at"])),
    ]
    summary = "Tapped the WhatsApp button" if f["cta"] else "Played the video" if f["video"] else "Opened the page" if opened else "Not opened yet"
    return _group("page", "Landing page", steps, summary, "ok" if opened else "idle")


def _chat_group(f):
    stop = f["stopped"]
    todo = "skipped" if stop else "pending"                              # STOP ke baad baaki steps kabhi nahi honge
    real = f["taps_real"]
    if f["replied"]:
        at = real[0]["at"] if real and real[0]["at"] else f["demo_started"]
        detail = ""
        if len(real) == 1:
            detail = '"%s"' % text(real[0]["label"], 40)
        elif real:
            detail = '%d messages, latest "%s"' % (len(real), text(real[-1]["label"], 40))
        steps = [_step("Replied or tapped a button", "done", "check", ist_label(at), detail)]
    else:
        steps = [_step("Replied or tapped a button", todo)]
    steps.append(_step("Started the demo", "done", "check", ist_label(f["demo_started"])) if f["demo"] else _step("Started the demo", todo))
    if f["demo_finished"]:
        steps.append(_step("Finished the demo", "done", "check", ist_label(f["demo_finished_at"] or f["demo_updated_at"]),
                           DEMO_RESULT_WORDS.get(f["demo_result"]) or "Reached the last step"))
    elif f["demo"] and not stop:
        steps.append(_step("Finished the demo", "pending", detail=("Last step reached: " + f["demo_step"]) if f["demo_step"] else ""))
    else:
        steps.append(_step("Finished the demo", todo))
    if f["person"]:
        steps.append(_step("Asked for a person", "done", "check", ist_label(f["demo_finished_at"] or f["demo_updated_at"]), "Hand-off is open: reply to them on WhatsApp" if f["handoff"] else ""))
    else:
        steps.append(_step("Asked for a person", todo))
    if stop:
        stop_at = f["taps_stop"][0]["at"] if f["taps_stop"] else (f["demo_finished_at"] or f["demo_updated_at"])
        steps.append(_step("Asked to stop", "failed", "x", ist_label(stop_at), "Do not message them again"))
        summary, chip = "Asked to stop", "bad"
    else:
        summary, chip = (("Asked for a person", "ok") if f["person"] else ("Finished the demo", "ok") if f["demo_finished"] else ("In the demo", "ok") if f["demo"]
                         else ("Replied", "ok") if f["replied"] else ("No reply yet", "idle"))
    return _group("chat", "Conversation", steps, summary, chip)


def _ticks(f):
    """List-row ke liye chhoti strip: har channel ka ek glyph (2blue = nili do tick, 2 = do tick, 1 = ek tick, x = fail, dot = hua, check = pura hua, - = abhi nahi)."""
    ticks = []
    if f["wa_sent"]:
        failed = f["wa_failed"] and not f["wa_delivered"]
        glyph, word = ("2blue", "read") if f["wa_read"] else ("2", "delivered") if f["wa_delivered"] else ("x", "not delivered") if failed else ("1", "sent")
        ticks.append({"ch": "WA", "glyph": glyph, "title": "WhatsApp: " + word})
    if f["mail"]:
        glyph, word = {"clicked": ("2", "clicked"), "opened": ("2", "opened"), "delivered": ("2", "delivered"), "bounced": ("x", "bounced"),
                       "failed": ("x", "bounced"), "complained": ("x", "marked as spam")}.get(f["mail_status"], ("1", "sent"))
        ticks.append({"ch": "Mail", "glyph": glyph, "title": "Email: " + word})
    ticks.append({"ch": "Page", "glyph": "dot" if f["page_opened"] else "-", "title": "Landing page: " + ("opened" if f["page_opened"] else "not opened yet")})
    if f["stopped"]:
        demo = ("x", "asked to stop")
    elif f["demo_finished"]:
        demo = ("check", "finished")
    elif f["demo"]:
        demo = ("dot", "started, not finished")
    else:
        demo = ("-", "not started")
    ticks.append({"ch": "Demo", "glyph": demo[0], "title": "Demo: " + demo[1]})
    return ticks


def journey(engagement_data, now=None):
    """Engagement data -> {"groups": [...], "furthest": "plain text", "furthest_key": "...", "ticks": [...]}.
    groups = WhatsApp message, Email, Landing page, Conversation (jo hua / jo bheja gaya wahi dikhte hain); har group: {key, title, steps:[{label, state, glyph, at, detail, aria}],
    summary, chip, note}. state = done | pending | failed | skipped. Kuch bheja hi nahi gaya ho to groups khali hain. `now` sirf tests ke liye."""
    f = _facts(engagement_data)
    now = now or datetime.now(timezone.utc)
    now = now if now.tzinfo else now.replace(tzinfo=timezone.utc)
    groups = []
    if f["wa_sent"]:
        groups.append(_wa_group(f, now))
    if f["mail"]:
        groups.append(_mail_group(f))
    if f["any_sent"] or f["page_opened"]:
        groups.append(_page_group(f))
    if f["any_sent"] or f["replied"] or f["stopped"]:
        groups.append(_chat_group(f))
    _rank, key, label = _progress(f)
    return {"groups": groups, "furthest": label, "furthest_key": key, "ticks": _ticks(f) if groups else []}


# ---------------------------------------------------------------------------------------------------------------------
# PIPELINE: Overview ka funnel aur Leads ka `stage` filter - dono yahi ek function use karte hain, taaki ginti aur list hamesha match karein.
# Har lead sirf EK stage me gini jaati hai (jahan wo abhi hai): lead ka status aur engagement dono dekhkar jo zyada aage ho wahi.
# ---------------------------------------------------------------------------------------------------------------------
PIPELINE = (
    ("researched", "Researched", "Not contacted yet, or every message failed"),
    ("contacted", "Contacted", "Sent, not delivered yet"),
    ("delivered", "Delivered", "Reached them, no reaction yet"),
    ("engaged", "Engaged", "Opened the page or clicked a link"),
    ("replied", "Replied", "Wrote back or asked for a person"),
    ("meeting", "Meeting or later", "Call booked or won"),
)
PIPELINE_LABEL = {key: label for key, label, _sub in PIPELINE}
PIPELINE_LABEL["closed"] = "Closed"
CLOSED_STATUSES = {"lost", "rejected", "do_not_contact"}


def pipeline_stage(lead_data, engagement_data):
    """(lead.data, engagement.data) -> researched | contacted | delivered | engaged | replied | meeting | closed."""
    lead = _dict(lead_data)
    status = text(lead.get("status"), 30).lower().replace(" ", "_") or "new"
    f = _facts(engagement_data)
    rank, _key, _label = _progress(f)
    if status in ("meeting", "won"):
        return "meeting"
    if status in CLOSED_STATUSES or f["stopped"] or f["spam"]:
        return "closed"
    if _dict(engagement_data).get("level") == "failed":
        return "researched"                                                  # every channel failed (bounce / not on WhatsApp): they were NOT reached, so not "contacted"
    by_status = 4 if status in ("replied", "interested") else 1 if _contacted(lead.get("contacted"), status) else 0
    by_data = 4 if rank >= 5 else 3 if rank == 4 else 2 if rank in (2, 3) else 1 if rank == 1 else 0
    return PIPELINE[max(by_status, by_data)][0]


def pipeline_counts(pairs):
    """[(lead.data, engagement.data or None), ...] -> {stage: how many leads}, closed bhi."""
    counts = {key: 0 for key, _label, _sub in PIPELINE}
    counts["closed"] = 0
    for lead_data, engagement_data in pairs:
        counts[pipeline_stage(lead_data, engagement_data)] += 1
    return counts


def prepare_light(entry):
    """List ke liye halka view-model: sirf chhote fields (lambi text ko haath bhi nahi lagate). Lead khulne par prepare() poora banata hai."""
    d = entry.get("data") if isinstance(entry.get("data"), dict) else {}
    status = text(d.get("status"), 30).lower().replace(" ", "_") or "new"
    contacted = _contacted(d.get("contacted"), status)
    tier = tier_of(d)
    return {
        "id": entry.get("id"), "key": entry.get("key") or "",
        "name": text(d.get("name"), 120) or entry.get("key") or "Unnamed lead", "initials": initials(d.get("name") or entry.get("key")),
        "city": text(d.get("city"), 80), "product": text(d.get("product"), 120),
        "campaign": text(d.get("campaign"), 160), "campaign_key": text(d.get("campaign_key"), 160),
        "grade": grade_of(d), "status": status, "status_label": status.replace("_", " ").capitalize(), "status_chip": STATUS_CHIP.get(status, "idle"),
        "stage": STAGE_PLAIN.get(status) or status.replace("_", " ").capitalize(), "contacted": contacted, "not_contacted": contacted is False,
        "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "tier_chip": TIER_CHIP.get(tier, "idle"), "hunger_score": score_of(d.get("hunger_score")),
        "summary": text(d.get("summary"), 140), "slug": slug_of(d),
        "language": text(d.get("language"), 4).lower() if text(d.get("language"), 4).lower() in LANG_LABEL else "",
        "language_label": LANG_LABEL.get(text(d.get("language"), 4).lower(), ""),
    }


MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


def short_date(value):
    """2026-10-16 -> "16 Oct" (non-tech ke liye chhota); kuch aur likha ho to jaisa hai waisa."""
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", value or "")
    return "%d %s" % (int(m.group(3)), MONTHS[int(m.group(2)) - 1]) if m and 1 <= int(m.group(2)) <= 12 else (value or "")


def _history(value):
    """[{date, text}] ya sirf strings -> list of {date, text}, nayi pehle."""
    out = []
    for h in (value if isinstance(value, list) else [])[:40]:
        if isinstance(h, dict):
            when, what = text(h.get("date") or h.get("when"), 24), text(h.get("text") or h.get("what"), 300)
        else:
            when, what = "", text(h, 300)
        if what:
            out.append({"date": when, "label": short_date(when), "text": what})
    return sorted(out, key=lambda x: x["date"], reverse=True)


def prepare(entry):
    """Console entry (type=lead) -> poora safe view-model (sirf kholi hui lead ke liye)."""
    d = entry.get("data") if isinstance(entry.get("data"), dict) else {}
    v = prepare_light(entry)
    contacts, seen = [], set()
    for c in (d.get("contacts") if isinstance(d.get("contacts"), list) else [])[:12]:
        if not isinstance(c, dict):
            continue
        href, icon = contact_link(c.get("kind"), c.get("value"))
        value = text(c.get("value"), 200)
        if value and (_kind_label(c.get("kind")), value) not in seen:          # same number/email listed twice: show once
            seen.add((_kind_label(c.get("kind")), value))
            contacts.append({"kind": _kind_label(c.get("kind")), "value": value, "href": href, "icon": icon,
                             "source": safe_url(c.get("source")) or safe_url(c.get("source_url")), "note": text(c.get("note"), 300)})
    reasons = text_list(d.get("hunger_reasons"), 420, 10)
    # "Kyun chahiye" ke 3 chhote points: agent ne `why_hungry` diya to wahi, warna hunger_reasons ki pehli 3 plus-lines (sign hata kar)
    why = text_list(d.get("why_hungry"), 170, 5) or [re.sub(r"^\+\d+\s*", "", r)[:170] for r in reasons if r.startswith("+")][:3]
    v.update({
        "legal_name": text(d.get("legal_name"), 240), "language_note": text(d.get("language_note"), 400),
        "next_step": text(d.get("next_step"), 160) or NEXT_STEP.get(v["status"], ""),
        "decision_maker": text(d.get("decision_maker"), 400), "size_cues": text(d.get("size_cues"), 500),
        "facts": text_list(d.get("observed_facts") or d.get("evidence"), 900, 10), "assumptions": text_list(d.get("hypotheses"), 500, 6),
        "case_for": text(d.get("case_for"), 2000), "case_against": text(d.get("case_against"), 2000),
        "ability_to_pay": text(d.get("ability_to_pay"), 600), "resistance": text(d.get("resistance"), 800),
        "best_angle": text(d.get("best_angle"), 1800), "best_channel": text(d.get("best_channel"), 1100),
        "hunger_reasons": reasons, "hunger_gaps": text_list(d.get("hunger_gaps"), 420, 8), "proof_level": text(d.get("proof_level"), 300), "why": why,
        "history": _history(d.get("history")), "contacts": contacts, "researched": text(d.get("researched"), 20), "note": text(d.get("note"), 400),
        "updated_at": entry.get("updated_at") or "",
    })
    return v


def sort_key(lead):
    return (TIER_RANK.get(lead["tier"], 3), -(lead["hunger_score"] or 0), GRADE_RANK.get(lead["grade"], 3), lead["name"].lower())


# =====================================================================================================================
# OVERVIEW: "Needs your attention" aur "Coming up" ke follow-ups. Sab kuch LIVE data se nikalta hai (engagement cards har 5 min me sync hote hain, sent activity,
# lead status), isliye ye apne aap update hota hai - kisi ko haath se "done" nahi karna padta (2026-10-22: purane handoffs 5 din tak chipke rehte the).
# =====================================================================================================================
FOLLOW_UP_DAYS = 3                      # kisi ko message gaya aur 3 din tak koi reaction nahi: ek chhota follow-up due
ATTENTION_ICON = {"reply": "reply", "stop": "alert", "hot": "activity", "due": "send", "failed": "alert", "handoff": "alert"}


def last_touch(engagement_data, extra_times=()):
    """Aakhri baar kab hamne is lead ko message bheja (WhatsApp ya email): engagement card ke send times + (optional) sent-activity ke times. Kabhi nahi to None."""
    d = _dict(engagement_data)
    mail = _dict(d.get("email"))
    raw = list(_good_times(d.get("wa_sent_times"))) + list(_good_times(mail.get("sent_times")))
    raw += [t for t in (_good_time(d.get("wa_sent_at")), _good_time(mail.get("sent_at")), _good_time(d.get("sent_at"))) if t]
    moments = [m for m in (parse_time(t) for t in raw) if m] + [m for m in extra_times if isinstance(m, datetime)]
    return max(moments) if moments else None


def short_name(name):
    """'Shyamal Group - Shyamal Park Lane' -> 'Shyamal Park Lane' (project naam, chhota dikhane ke liye)."""
    name = text(name, 100)
    return name.split(" - ", 1)[1].strip() if " - " in name else name


def build_attention(leads, eng_by_slug, sent_times_by_name, now=None, follow_up_days=FOLLOW_UP_DAYS):
    """Lead entries + engagement entries (slug -> entry) + {lead name (lower): [datetime, ...]} of messages we sent -> {"items": [...], "followups": [...]}.
    items = kaun si lead ko abhi aapki zarurat hai, sabse zaroori pehle: reply (0), asked to stop (1) / hot (1), follow-up due (2), not delivered (3).
    followups = har us lead ki due date jise bheja gaya par koi reaction nahi (Coming up tile ke liye). Closed / meeting wali leads ko chhodte hain."""
    now = now or datetime.now(timezone.utc)
    items, followups = [], []
    for lead in leads:
        d = _dict(lead.get("data"))
        name = text(d.get("name"), 100)
        if not name:
            continue
        status = text(d.get("status"), 30).lower().replace(" ", "_")
        if status in CLOSED_STATUSES or status in ("meeting", "won"):
            continue
        slug = slug_of(d)
        eng = eng_by_slug.get(slug) if slug else None
        ed = _dict(eng.get("data")) if eng else {}
        f = _facts(ed) if eng else None
        touch = last_touch(ed, sent_times_by_name.get(name.lower(), ()))
        stamp = parse_time(ed.get("updated")) or touch or now
        headline, nxt = text(ed.get("headline"), 200), text(ed.get("next"), 200)
        kind = ""
        if f and f["stopped"]:
            kind, detail, prio = "stop", "Asked to stop. Do not message them again.", 1
        elif f and (f["person"] or f["replied"]):
            kind, detail, prio = "reply", headline or "Wrote back. Answer them now.", 0
        elif f and text(ed.get("level"), 20) in ("hot", "engaged"):
            kind, detail, prio = "hot", headline or "Opened the page.", 1
        elif f and text(ed.get("level"), 20) == "failed":
            kind, detail, prio = "failed", headline or "The message could not be delivered.", 3
        if kind:
            items.append({"kind": kind, "lead_id": lead.get("id"), "name": name, "detail": detail, "next": nxt if kind == "hot" else "", "ts": stamp, "prio": prio})
        if touch and kind in ("", "hot"):
            due = touch + timedelta(days=follow_up_days)
            followups.append({"lead_id": lead.get("id"), "name": name, "due": due, "touch": touch})
            if kind == "" and now >= due:
                days = max(follow_up_days, (now - touch).days)
                items.append({"kind": "due", "lead_id": lead.get("id"), "name": name, "next": "", "ts": touch, "prio": 2,
                              "detail": "No reaction %d days after the last message. Send one short follow-up." % days})
    items.sort(key=lambda i: (i["prio"], -i["ts"].timestamp()))
    followups.sort(key=lambda i: (i["due"], i["name"].lower()))
    return {"items": items, "followups": followups}
