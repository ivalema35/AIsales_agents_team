# -*- coding: utf-8 -*-
"""Month calendar for the Campaigns page: pure functions, no Flask, no database (easy to test).

Events come from entries the agent writes:
  campaign  data.start / data.end (dates "YYYY-MM-DD"; end optional) -> a bar spanning those days; data.milestones [{date, label}] -> one-day markers
  event     data.date (or start/end), data.title, data.campaign, data.status/kind  -> a free-form item the agent plans (e.g. "Send batch 2")
A campaign without a start date has no place on the calendar and is listed as "Unscheduled".

The month is drawn week by week. Every event that touches a week becomes one bar segment (column start, span, lane). At most MAX_LANES
lanes are drawn per week; the rest is counted per day as "+N more" (like Klaviyo / Buffer). On phones the bars are replaced by dots + the agenda.
"""
import calendar as pycal
from datetime import date, datetime, timedelta

MAX_LANES = 3
STATUS_ORDER = {"active": 0, "paused": 1, "draft": 2, "done": 3}


def parse_date(value):
    """'2026-10-23' or a full ISO timestamp -> date, else None."""
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value).strip().replace("Z", "+00:00")).date()
    except (TypeError, ValueError):
        return None


def parse_month(text, today):
    """'2026-10' -> (2026, 10); anything else -> the month of `today`."""
    try:
        y, m = str(text).split("-")
        y, m = int(y), int(m)
        if 2000 <= y <= 2100 and 1 <= m <= 12:
            return y, m
    except (TypeError, ValueError, AttributeError):
        pass
    return today.year, today.month


def shift_month(year, month, delta):
    index = year * 12 + (month - 1) + delta
    return index // 12, index % 12 + 1


def collect_events(campaigns, events):
    """-> (events, unscheduled campaigns). Each event: {title, start, end, status, kind, campaign}."""
    out, unscheduled = [], []
    for c in campaigns:
        d = c["data"]
        name = str(d.get("name") or c["key"] or "Campaign")
        status = str(d.get("status") or "draft")
        start = parse_date(d.get("start"))
        end = parse_date(d.get("end")) or start
        if start is None:
            unscheduled.append({"title": name, "status": status})
        else:
            if end < start:
                start, end = end, start
            out.append({"title": name, "start": start, "end": end, "status": status, "kind": "campaign", "campaign": name})
        ms = d.get("milestones")
        for m in ms if isinstance(ms, list) else []:
            when = parse_date((m or {}).get("date")) if isinstance(m, dict) else None
            if when:
                out.append({"title": "%s: %s" % (name, m.get("label") or "milestone"), "start": when, "end": when, "status": "milestone", "kind": "milestone", "campaign": name})
    for e in events:
        d = e["data"]
        start = parse_date(d.get("start") or d.get("date"))
        if start is None:
            continue
        end = parse_date(d.get("end")) or start
        if end < start:
            start, end = end, start
        out.append({"title": str(d.get("title") or d.get("text") or "Event"), "start": start, "end": end,
                    "status": str(d.get("status") or "event") if str(d.get("status") or "event") in STATUS_ORDER else "event",
                    "kind": "event", "campaign": str(d.get("campaign") or "")})
    return out, unscheduled


def build_month(year, month, events, today):
    """The data the template draws: weeks of 7 days, plus the bar segments of every week."""
    weeks_out = []
    for week in pycal.Calendar(firstweekday=0).monthdatescalendar(year, month):          # Monday first
        first, last = week[0], week[6]
        segs = []
        for ev in events:
            if ev["end"] < first or ev["start"] > last:
                continue
            s, e = max(ev["start"], first), min(ev["end"], last)
            segs.append({"col": (s - first).days + 1, "span": (e - s).days + 1, "title": ev["title"], "status": ev["status"], "kind": ev["kind"],
                         "left": ev["start"] < first, "right": ev["end"] > last, "_s": s, "_e": e})
        segs.sort(key=lambda g: (g["col"], -g["span"], STATUS_ORDER.get(g["status"], 9), g["title"]))
        lanes, hidden = [], {}
        for g in segs:
            placed = False
            for i, taken in enumerate(lanes):
                if all(g["col"] + g["span"] <= a or g["col"] >= a + b for a, b in taken):
                    taken.append((g["col"], g["span"]))
                    g["lane"], placed = i + 1, True
                    break
            if not placed and len(lanes) < MAX_LANES:
                lanes.append([(g["col"], g["span"])])
                g["lane"], placed = len(lanes), True
            if not placed:
                g["lane"] = 0
                for k in range(g["col"], g["col"] + g["span"]):
                    hidden[k] = hidden.get(k, 0) + 1
        days = []
        for idx, d in enumerate(week):
            covering = [ev for ev in events if ev["start"] <= d <= ev["end"]]
            statuses = []
            for ev in sorted(covering, key=lambda v: STATUS_ORDER.get(v["status"], 9)):
                if ev["status"] not in statuses:
                    statuses.append(ev["status"])
            days.append({"date": d.isoformat(), "num": d.day, "in_month": d.month == month, "is_today": d == today, "weekend": d.weekday() >= 5,
                         "dots": statuses[:3], "count": len(covering), "more": hidden.get(idx + 1, 0)})
        weeks_out.append({"days": days, "bars": [g for g in segs if g["lane"]]})
    py, pm = shift_month(year, month, -1)
    ny, nm = shift_month(year, month, 1)
    return {"label": date(year, month, 1).strftime("%B %Y"), "weeks": weeks_out, "prev": "%04d-%02d" % (py, pm), "next": "%04d-%02d" % (ny, nm),
            "is_current": (year, month) == (today.year, today.month), "weekdays": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]}


def agenda(events, today, horizon_days=45, limit=12):
    """Upcoming and running items, soonest first, with a human 'when'."""
    items = []
    for ev in events:
        if ev["end"] < today or ev["start"] > today + timedelta(days=horizon_days):
            continue
        if ev["start"] <= today <= ev["end"] and ev["start"] != ev["end"]:
            when = "Running until %s" % ev["end"].strftime("%d %b")
        elif ev["start"] == today:
            when = "Today"
        elif ev["start"] == today + timedelta(days=1):
            when = "Tomorrow"
        elif ev["start"] == ev["end"]:
            when = ev["start"].strftime("%a %d %b")
        else:
            when = "%s - %s" % (ev["start"].strftime("%d %b"), ev["end"].strftime("%d %b"))
        items.append({"when": when, "title": ev["title"], "status": ev["status"], "kind": ev["kind"], "sort": (max(ev["start"], today), ev["title"])})
    items.sort(key=lambda i: i["sort"])
    return items[:limit]
