# -*- coding: utf-8 -*-
"""email_hooks.py - Resend ke webhook events (sent / delivered / opened / clicked / bounced / complained) ko console me `email_event` entries ke roop me rakhta hai.

Kyun: pehle email ka status PC se haath se push hota tha (email_status.py). Webhook se Resend khud, asli samay ke saath, server ko batata hai, PC ki zaroorat nahi.
Resend webhook Svix ke tareeke se sign hota hai: header svix-id, svix-timestamp, svix-signature ("v1,<base64>" ek ya zyada, space se alag).
Signed content = "<id>.<timestamp>.<raw body>", key = base64decode(secret ka "whsec_" ke baad ka hissa), signature = base64(HMAC-SHA256). Timestamp 5 minute ke andar hona chahiye
(replay se bachav). Signature galat / secret set nahi = event kabhi store nahi hota. Sirf standard library.

Is file me Flask nahi hai: `handle()` ek seedha function hai (test karna aasan); app.py bas route lagata hai aur `store` callback deta hai."""
import base64
import hashlib
import hmac
import json
import re
import time
from datetime import datetime, timezone

TOLERANCE_SECONDS = 300                 # Svix ki default: 5 minute
MIN_KEY_BYTES = 16                      # Resend's real signing keys are 24+ bytes
MAX_BODY = 64 * 1024
EVENT_TYPES = {"email.sent", "email.delivered", "email.delivery_delayed", "email.bounced", "email.complained", "email.opened", "email.clicked", "email.failed"}
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,255}$")


def _secret_key(secret):
    """'whsec_<base64>' -> raw key bytes, or None if the secret is missing / not in that shape."""
    text = str(secret or "").strip()
    if not text.startswith("whsec_"):
        return None
    try:
        key = base64.b64decode(text[len("whsec_"):], validate=True)
    except (ValueError, TypeError):
        return None
    return key if len(key) >= MIN_KEY_BYTES else None          # an empty / tiny key ("whsec_" alone after a cut-off paste) is guessable: refuse it, never verify with it


def sign(secret, msg_id, timestamp, body):
    """The signature Resend/Svix would send (used by the tests and by nothing else)."""
    key = _secret_key(secret)
    content = ("%s.%s." % (msg_id, timestamp)).encode("utf-8") + body
    return "v1," + base64.b64encode(hmac.new(key, content, hashlib.sha256).digest()).decode("ascii")


def verify(secret, headers, body, now=None):
    """True only for a correctly signed, fresh request. Never raises."""
    key = _secret_key(secret)
    if key is None or not isinstance(body, (bytes, bytearray)):
        return False
    msg_id, stamp, given = (str(headers.get(h) or "") for h in ("svix-id", "svix-timestamp", "svix-signature"))
    if not (msg_id and stamp and given) or len(msg_id) > 200:
        return False
    try:
        age = abs((now if now is not None else time.time()) - int(stamp))
    except (ValueError, OverflowError):                        # "not a number" and absurdly huge numbers are both just "bad request"
        return False
    if age > TOLERANCE_SECONDS:
        return False
    expected = sign(secret, msg_id, stamp, bytes(body)).encode("ascii")
    for part in given.split(" "):
        part = part.strip()
        try:
            candidate = part.encode("ascii")                   # a non-ASCII signature must not crash compare_digest (it raises TypeError on str with non-ASCII)
        except UnicodeEncodeError:
            continue
        if part and hmac.compare_digest(expected, candidate):
            return True
    return False


def _iso(value):
    """Any ISO-ish time from Resend -> 'YYYY-MM-DDTHH:MM:SS+00:00' in UTC, or None."""
    try:
        d = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    d = d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    return d.astimezone(timezone.utc).isoformat(timespec="seconds")


def parse_event(payload, msg_id):
    """Resend event JSON -> (key, created_at, data) for one `email_event` entry, or None when it is not an email event we use. Every text is clipped, nothing is trusted."""
    if not isinstance(payload, dict):
        return None
    etype = str(payload.get("type") or "")
    data = payload.get("data")
    if etype not in EVENT_TYPES or not isinstance(data, dict):
        return None
    email_id = str(data.get("email_id") or "")[:80]
    to = data.get("to")
    first = (to[0] if isinstance(to, list) and to else to) or ""
    first = str(first).strip().lower()
    if not email_id or not EMAIL_RE.match(first):
        return None
    at = _iso(payload.get("created_at")) or _iso(data.get("created_at"))
    if at is None:
        return None
    detail = ""
    if isinstance(data.get("bounce"), dict):
        detail = " ".join(str(data["bounce"].get(k) or "") for k in ("type", "subType", "message")).strip()
    elif isinstance(data.get("click"), dict):
        detail = "clicked a link"
    out = {"source": "resend", "type": etype, "email_id": email_id, "to": first, "subject": str(data.get("subject") or "")[:150], "at": at, "detail": detail[:200]}
    return str(msg_id)[:120], at, out


def handle(raw_body, headers, secret, store, now=None):
    """The whole webhook in one function. Returns (http_status, message). `store(key, created_at, data)` saves one entry (an upsert by key, so Resend's retries cannot duplicate).
    503 = secret not set yet (Resend retries later), 401 = bad signature, 400 = unreadable, 200 = stored or an event type we do not use."""
    if _secret_key(secret) is None:
        return 503, "webhook secret is not configured"
    if not isinstance(raw_body, (bytes, bytearray)) or len(raw_body) > MAX_BODY:
        return 400, "bad body"
    if not verify(secret, headers, raw_body, now):
        return 401, "bad signature"
    try:
        payload = json.loads(bytes(raw_body).decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return 400, "not json"
    parsed = parse_event(payload, headers.get("svix-id"))
    if parsed is None:
        return 200, "ignored"
    key, created_at, data = parsed
    store(key, created_at, data)
    return 200, "stored"
