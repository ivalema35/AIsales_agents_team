# -*- coding: utf-8 -*-
"""The owner's "Add lead" form: pure helpers (no Flask) so they are easy to test.

The owner types a few simple fields; we turn them into one `lead` entry in the same shape the agent writes, so the Leads page, filters and the
pipeline treat it like any other lead. Nothing here sends a message or contacts anyone.
"""
import re
import secrets
from datetime import date, datetime

import leads_view as lv

GRADES = (("A", "A - very good fit"), ("B", "B - good fit"), ("C", "C - not sure yet"))
SOURCES = ("Google Maps", "Instagram", "Facebook", "Referral or someone I know", "Walked in / phoned us", "Other")
DEFAULT_PRODUCT = "Booking + proof page, Google profile clean-up and monthly upkeep, WhatsApp booking set-up"
EMAIL_RE = re.compile(r"^[^@\s<>\"']{1,64}@[^@\s<>\"']{1,200}\.[A-Za-z]{2,}$")


def squash(text):
    return re.sub(r"[^a-z0-9]", "", str(text or "").lower())


def clean_text(value, limit):
    """One line, no control characters, trimmed to `limit` characters."""
    return re.sub(r"\s+", " ", re.sub(r"[\x00-\x1f\x7f]", " ", str(value or ""))).strip()[:limit]


def normalise_phone(raw):
    """-> (display '+91 98765 43210', ten digits) or (None, message). Indian mobile numbers only (10 digits starting 6-9)."""
    digits = re.sub(r"\D", "", str(raw or ""))
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    elif len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]
    elif len(digits) == 13 and digits.startswith("091"):
        digits = digits[3:]
    if len(digits) != 10 or digits[0] not in "6789":
        return None, "This number does not look right. Write a 10-digit mobile number, for example 98765 43210."
    return "+91 %s %s" % (digits[:5], digits[5:]), digits


def normalise_link(raw):
    """A website or Instagram link. '@handle' becomes an Instagram link. -> (kind, url) or (None, message). Empty is fine -> ('', '')."""
    value = clean_text(raw, 300)
    if not value:
        return "", ""
    if value.startswith("@") and re.match(r"^@[A-Za-z0-9._]{1,30}$", value):
        return "instagram", "https://www.instagram.com/%s/" % value[1:]
    if value.startswith("/") or " " in value:
        return None, "This link does not look right. Paste a website link, or an Instagram handle like @studioname."
    if not re.match(r"^[a-z][a-z0-9+.-]*:", value, re.I):
        value = "https://" + value                                  # "studio.in" -> https://studio.in
    url = lv.safe_url(value)
    if not url:
        return None, "This link does not look right. Paste a website link, or an Instagram handle like @studioname."
    return ("instagram" if "instagram.com" in url.lower() else "website"), url


def existing_phones(lead_rows):
    """ten digits -> (lead id, name) for every number we already hold, so the same studio is never added twice."""
    seen = {}
    for entry in lead_rows:
        data = entry["data"] or {}
        for c in data.get("contacts") or []:
            if isinstance(c, dict) and str(c.get("kind", "")).lower() in ("phone", "mobile", "whatsapp", "tel"):
                for run in re.findall(r"\d[\d \-]{8,}\d", str(c.get("value", ""))):
                    d = re.sub(r"\D", "", run)
                    d = d[-10:] if len(d) >= 10 else d
                    if len(d) == 10:
                        seen.setdefault(d, (entry["id"], str(data.get("name") or "a lead")))
    return seen


DAY_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})$")


def parse_day(text, today):
    """'2026-11-03' -> date, or None when it is not a real day, is after `today`, or is before 2020."""
    m = DAY_RE.match(str(text or "").strip())
    if not m:
        return None
    try:
        d = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None
    return d if date(2020, 1, 1) <= d <= today else None


def validate(form, lead_rows, campaigns, today=None):
    """-> (values, errors, duplicate). `values` echoes the cleaned input for re-showing the form; `errors` maps field -> message;
    `duplicate` is (lead id, name) when the number or the name+city is already a lead."""
    f = {k: clean_text(form.get(k, ""), 600 if k == "note" else 300) for k in
         ("name", "phone", "city", "campaign", "grade", "owner_name", "link", "email", "source", "note", "date")}
    today = today or datetime.now().date()
    errors, duplicate = {}, None
    if not f["name"]:
        errors["name"] = "Write the business name."
    elif len(f["name"]) > 80:
        errors["name"] = "The name is too long (up to 80 characters)."
    phone_display, phone_digits = normalise_phone(f["phone"])
    if phone_display is None:
        errors["phone"] = phone_digits
    if not f["city"]:
        errors["city"] = "Write the city or area."
    elif len(f["city"]) > 60:
        errors["city"] = "The city is too long (up to 60 characters)."
    day = parse_day(f["date"], today) if f["date"] else today
    if day is None:
        errors["date"] = "Pick a day that is today or earlier."
    f["date"] = day.isoformat() if day else f["date"]
    if f["grade"] not in dict(GRADES):
        f["grade"] = "C"
    if f["source"] and f["source"] not in SOURCES:
        f["source"] = "Other"
    if f["campaign"] and f["campaign"] not in {c["key"] for c in campaigns}:
        errors["campaign"] = "Choose a campaign from the list."
    link_kind, link_url = normalise_link(f["link"])
    if link_kind is None:
        errors["link"] = link_url
    if f["email"] and not EMAIL_RE.match(f["email"]):
        errors["email"] = "This email does not look right."
    if not errors:
        held = existing_phones(lead_rows)
        if phone_digits in held:
            duplicate = held[phone_digits]
        else:
            same = [(e["id"], str((e["data"] or {}).get("name"))) for e in lead_rows
                    if squash((e["data"] or {}).get("name")) == squash(f["name"]) and squash((e["data"] or {}).get("city")) == squash(f["city"])]
            duplicate = same[0] if same else None
    f["phone_display"], f["link_kind"], f["link_url"] = phone_display, link_kind, link_url
    return f, errors, duplicate


def build_entry(values, campaigns, today=None, peer_product=""):
    """The `lead` entry (type, key, tags, data) for a validated form."""
    today = values.get("date") or today or datetime.now().strftime("%Y-%m-%d")      # the day the lead is put on in the dashboard calendar
    camp = next((c for c in campaigns if c["key"] == values["campaign"]), None)
    where = values["source"] or "not said"
    facts = ["Added by the owner in the console on %s. Where it was found: %s.%s" % (today, where, (" Note: " + values["note"]) if values["note"] else "")]
    contacts = [{"kind": "phone", "value": values["phone_display"], "source": "Added by the owner (console form)",
                 "note": "Typed by the owner; WhatsApp and owner-vs-front-desk not checked."}]
    if values["email"]:
        contacts.append({"kind": "email", "value": values["email"], "source": "Added by the owner (console form)", "note": ""})
    if values["link_url"]:
        contacts.append({"kind": values["link_kind"], "value": values["link_url"], "source": "Added by the owner (console form)", "note": ""})
    if values["owner_name"]:
        contacts.append({"kind": "contact_person", "value": values["owner_name"], "source": "Added by the owner (console form)", "note": ""})
    slug = re.sub(r"[^a-z0-9]+", "-", values["name"].lower()).strip("-")[:40] or "lead"
    data = {
        "name": values["name"], "city": values["city"],
        "product": peer_product or (camp or {}).get("product") or DEFAULT_PRODUCT,
        "campaign": (camp or {}).get("name", ""), "campaign_key": (camp or {}).get("key", ""),
        "grade": values["grade"], "status": "new", "contacted": False,
        "researched": "%s (added by the owner in the console)" % today,
        "language": "EN", "best_channel": "The owner's own WhatsApp 1:1, or the approved template after a re-check of the listing.",
        "contacts": contacts, "observed_facts": facts, "hypotheses": [],
        "case_against": "Added by hand: not researched or checked yet.", "verification": "Added by the owner; nothing verified yet.",
        "added_by": "owner",
    }
    return {"type": "lead", "key": "owner-%s-%s" % (slug, secrets.token_hex(3)), "tags": ["owner-added", "added-" + today], "data": data}
