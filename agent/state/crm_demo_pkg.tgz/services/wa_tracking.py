"""WhatsApp delivery / read tracking for the messages the AGENT sends (templates sent by agent/tools/wa.py).

Why: Meta tells us "delivered", "read" and "failed" for every message ONCE, in a status callback on the webhook. The CRM only kept those
for messages IT sent (OutreachLog rows). The agent's own template sends are not in OutreachLog, so those callbacks were thrown away --
and a status that is not stored can never be asked for again. This stores them as small events in agent_activity (kind wa_delivered /
wa_read / wa_failed), tied to the lead through the wamid + project that wa.py logs when it sends (kind template_sent).

No message is ever sent from here. Failures are logged and swallowed (a status callback must never break the webhook).
"""
from __future__ import annotations

import json
import logging
import re

from database.models import AgentActivity
from services import agent_service

logger = logging.getLogger(__name__)

TRACKED = ("delivered", "read", "failed")


def _token(wamid) -> str:
    return re.sub(r"[^A-Za-z0-9._=-]", "", str(wamid or ""))[:120]


def _payload(row) -> dict:
    try:
        data = json.loads(row.payload_json or "{}")
        return data if isinstance(data, dict) else {}
    except ValueError:
        return {}


def record_agent_message_status(db, status: dict) -> bool:
    """One Meta status callback. Returns True when it was stored as an event (a message the agent sent, a status we track, not seen before)."""
    try:
        return _record(db, status)
    except Exception:  # noqa: BLE001
        db.rollback()
        logger.exception("wa_tracking failed (ignored)")
        return False


def _record(db, status) -> bool:
    wamid = _token(status.get("id"))
    kind = status.get("status")
    if not wamid or kind not in TRACKED:
        return False
    sent = (db.query(AgentActivity).filter(AgentActivity.kind == "template_sent", AgentActivity.payload_json.like('%"' + wamid + '"%'))
            .order_by(AgentActivity.id.desc()).limit(5).all())
    origin = next((row for row in sent if _payload(row).get("wamid") == wamid), None)
    if origin is None:
        return False                                   # not a message the agent sent (or sent before wamids were logged)
    event_kind = "wa_" + kind
    already = (db.query(AgentActivity.id).filter(AgentActivity.kind == event_kind, AgentActivity.lead_ref == origin.lead_ref,
                                                 AgentActivity.payload_json.like('%"' + wamid + '"%')).first())
    if already:
        return False                                   # a retried callback
    info = _payload(origin)
    payload = {"wamid": wamid, "status": kind, "project": info.get("project"), "template": info.get("template")}
    if kind == "failed":
        errors = status.get("errors") or []
        first = errors[0] if errors and isinstance(errors[0], dict) else {}
        payload["error_code"] = first.get("code")
        payload["error"] = str(first.get("title") or first.get("message") or "")[:200]
    words = {"delivered": "reached the phone", "read": "was opened (read)", "failed": "could not be delivered"}
    agent_service.add_event(db, origin.lead_ref, "whatsapp", "in", event_kind, "WhatsApp: the template message %s" % words[kind], payload)
    return True
