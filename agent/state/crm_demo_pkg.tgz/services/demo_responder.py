"""The WhatsApp DEMO RESPONDER: the first-minute automatic reply for a lead who taps "Yes, send the demo"
(the template's quick-reply button) or writes "send the demo" (the landing page's WhatsApp button pre-fills it).

What it is: a FIXED conversation, no AI anywhere. The lead gets a short sample of what THEIR buyers would get: an intro with
question 1, two more quick questions as tap-buttons (type, best time), a site-visit time, a sample "hot buyer" card, and then a
plain offer ("Yes, contact me" / "No, thanks"). Every word the lead can receive is in TEXTS below -- nothing is generated.

Where it runs: INSIDE the CRM webhook (api/inbound.py), on the VPS, so it works 24/7 and answers in about a second, with no
dependency on the owner's PC or on any Claude session. It only ever REPLIES to someone who wrote first (inside the 24 hour
window); it never sends a first message to anybody.

Safety rails (each one is tested in tests/test_demo_responder.py):
  * OFF by default. The mode flag `demo_mode` is off | test | on and is changed ONLY by the owner's own WhatsApp message
    ("DEMO ON" / "DEMO TEST" / "DEMO OFF", services/owner_channel.py) -- the agent cannot switch it on.
  * "STOP ALL" (the existing `paused` flag) silences it at once. Suppressed numbers are never answered.
  * test mode answers only the owner and the numbers in DEMO_TEST_NUMBERS.
  * only a webhook request that PASSED the secret check is trusted.
  * caps: sessions per number per day, sessions and messages per day overall, messages per session, an unknown-answer limit.
  * a webhook retry (same wamid) is ignored (demo_seen UNIQUE); every state change is a compare-and-set, and at most ONE active
    demo exists per number (partial unique index), so two workers or a double tap can never send a question twice.
  * the lead's own words are NEVER echoed back: the project name comes from our own list (services/demo_projects.json).
  * every kind of "no" (STOP, "no thanks", "don't message me", "band karo", ...) ends the demo with ONE message and puts the
    number on the do-not-contact list; "not now / later" ends it politely without that.
  * any unexpected error is logged and swallowed: the old webhook flow (inbound handling, owner commands) must never break.
  * the owner's own test runs (DEMO RUN, or his own tap on the template) never alert, never hand off, never suppress his number,
    and never swallow his normal chat with the agent.
"""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests
from sqlalchemy import func, text as sql_text
from sqlalchemy.exc import IntegrityError

from cognition.hard_classifiers import is_autoreply, is_optout
from config import Config
from database.models import AgentHandoff, DemoSeen, DemoSession, OwnerInbox
from services import agent_service
from services.whatsapp_message import TEXT_KINDS, describe_message, normalize_wa_number

logger = logging.getLogger(__name__)

MODE_FLAG = "demo_mode"            # agent_flags key: off | test | on
MODES = ("off", "test", "on")

# ---- caps -----------------------------------------------------------------------------------------------------------
MAX_SESSIONS_PER_PHONE_PER_DAY = 2
MAX_SESSIONS_PER_DAY = 40
MAX_MESSAGES_PER_DAY = 400
MAX_MESSAGES_PER_SESSION = 20
MAX_UNRECOGNISED = 2               # unclear answers that get a nudge; the next one ends the demo (no hand-off)
MAX_RESENDS = 2                    # "send the demo" again / "hello?" while a question is open: how often the question is repeated
SESSION_HOURS = 23                 # WhatsApp's free-reply window is 24 h from the lead's last message; stay inside it
OWNER_SESSION_MINUTES = 30         # the owner's own test runs expire quickly so they never linger and catch his normal chat
SEEN_KEEP_DAYS = 7
MAX_TEXT = 1000                    # inbound text is clipped before any regular expression runs

IST = timezone(timedelta(hours=5, minutes=30))

# ---- every word the lead can receive -----------------------------------------------------------------------------------
TEXTS = {
    "intro": ("Hello, this is IV Infotech, Mehsana. You asked for our demo, so here it is: an automatic WhatsApp chat made for {project}. "
              "No person is typing.\n\nPlay a buyer and tap 3 answers, about 1 minute. Nothing is scheduled and nothing is shared.\n\n"
              "Reply STOP to end it, or PERSON to talk to our team."),
    "q_budget": "Question 1 of 3\nAs a buyer, what budget are you looking at?",
    "q_type": "Question 2 of 3\nWhich type do you want?",
    "q_time": "Question 3 of 3\nWhen is the best time to visit the site?",
    "q_slot": "Last step. Pick a site-visit time (sample)",
    "card": ("That is the demo. For each buyer, your team would see a card like this:\n\n"
             "SAMPLE BUYER - {project}\nBudget: {budget}\nType: {type}\nBest time: {time}\nVisit: {slot}\nStatus: {status}\n\n"
             "Nothing is scheduled and nothing was shared with anyone. Your team can open any chat and reply."),
    "q_cta": "Would you like this for {project}, with your own brochure and on your own number?",
    "yes": "Thank you. A person from IV Infotech will message you on this chat during working hours. Reply STOP if you change your mind.",
    "person": "Sure. A person from IV Infotech will message you on this chat during working hours. Reply STOP if you change your mind.",
    "no": "No problem. Thank you for your time. We will not message you on WhatsApp about this again.",
    "stop": "Done. We will not send you any more WhatsApp messages. Sorry for the trouble.",
    "later": "No problem. If you want the demo again, just write 'send the demo'. Reply STOP if you do not want any more messages.",
    "unknown": "Sorry, this automatic demo only understands the options below. Please tap one, or reply PERSON to talk to our team. Reply STOP to end it.",
    "unknown_end": "I could not follow that, so I will stop here. Write 'send the demo' to start again, or reply PERSON if you want our team to message you.",
    "about": ("IV Infotech (Mehsana) builds automatic WhatsApp replies for real-estate developers: an instant reply to every enquiry, a few "
              "questions, a site-visit time and one simple list for your team. This chat is a free sample. Please tap one option below to "
              "continue, or reply STOP to end."),
    "lettered": "Reply with the letter:",
    "owner_done": "Test run finished. Nothing was suppressed and no hand-off was created.",
}

TIMES = ["Morning", "Afternoon", "Evening"]
SLOT_HOUR = {"Morning": "11 AM", "Afternoon": "3 PM", "Evening": "6 PM"}
CTA = ["Yes, contact me", "No, thanks"]
GENERIC_PROJECT = {"name": "your project", "types": ["2 BHK", "3 BHK"], "budget": ["Up to 75 lakh", "75 lakh to 1.5 cr", "Above 1.5 crore"]}

_TRIGGER_RE = re.compile(r"\bsend\s+(me\s+)?(the\s+)?demo\b", re.IGNORECASE)
_NEGATED_TRIGGER_RE = re.compile(r"\b(don'?t|dont|do\s+not|never|no\s+need\s+to|not|no)\b(\W+\w+){0,2}?\W+send\b", re.IGNORECASE)
_PERSON_RE = re.compile(r"\b(talk|speak|connect(\s+me)?)\s+(to|with)\s+(a|an|your|the|some)?\s*(real\s+)?(person|human|someone|team|executive|manager|agent)\b"
                        r"|^\W*(person|human|agent)\W*$|\bcall\s*(me|back)\b", re.IGNORECASE)
# every kind of "no, stop": the CRM's own list (is_optout) PLUS what it misses ("no, thanks" with a comma, curly apostrophes, Hindi/Gujarati)
_HARD_STOP_RE = re.compile(r"\b(stop|unsubscribe|unsub|opt\s*out|remove\s+(me|my\s+number)|leave\s+me\s+alone|no\s+more|not\s+interested|"
                           r"do\s*n'?o?t\s+(message|text|contact|call|disturb|send|whatsapp)|mat\s+(bhejo|karo|kro)|band\s*(karo|kro|kar\s*do)|"
                           r"bandh\s*karo|nathi\s+joitu|nahi\s+chahiye|nahin\s+chahiye|no\s*,?\s*thank(s|\s+you)?|no\s+thx)\b"
                           r"|बंद|बन्द|नहीं\s*चाहिए|બંધ|નથી\s*જોઈતું", re.IGNORECASE)
_LATER_RE = re.compile(r"^\W*(not\s+now|later|maybe|abhi\s+nahi|baad\s+me|will\s+think|let\s+me\s+think|i\s+will\s+think|i'?ll\s+think)\b", re.IGNORECASE)
_PLAIN_NO_RE = re.compile(r"^\W*(no|nope|nahi|nahin|ના|नहीं|नही)\W*$", re.IGNORECASE)
_ABOUT_RE = re.compile(r"\b(what\s+is\s+this|what'?s\s+this|who\s+are\s+you|who\s+is\s+this|what\s+do\s+you\s+do|kya\s+hai|kaun\s+ho|kon\s+ho|more\s+info|details)\b", re.IGNORECASE)
_YES_WORDS = {"yes", "yes please", "ok", "okay", "haan", "ha", "han", "sure", "yep", "yeah", "હા", "हाँ", "हां", "हा"}
_NO_WORDS = {"no", "nahi", "nahin", "nope", "ના", "नहीं", "नही"}
_FLOW = ["budget", "type", "time", "slot", "cta"]
_LETTERS = "abc"


# =====================================================================================================================
# small helpers (pure)
# =====================================================================================================================
def _apos(text) -> str:
    return str(text or "").replace("’", "'").replace("‘", "'").replace("`", "'")


def _norm(text) -> str:
    """Lower-case words (Latin, Devanagari and Gujarati letters kept), single spaces."""
    return " ".join(re.findall(r"[a-z0-9ऀ-ॿ઀-૿]+", _apos(text).lower()))


def _compact(text) -> str:
    return _norm(text).replace(" ", "")


def _clip_title(label: str) -> str:
    return str(label)[:20]          # WhatsApp button titles are at most 20 characters


def _mask(phone: str) -> str:
    digits = re.sub(r"\D", "", str(phone or ""))
    return ("+%s ******%s" % (digits[:2], digits[-4:])) if len(digits) >= 8 else "unknown"


def _projects() -> dict:
    """Our own project list (normalised name -> settings). Built by agent/pages/build_demo_config.py from the landing-page data."""
    path = Path(getattr(Config, "DEMO_PROJECTS_PATH", "") or Path(__file__).with_name("demo_projects.json"))
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:  # noqa: BLE001 - a missing/bad file means "generic project", never a crash
        logger.warning("demo_projects.json unreadable, using the generic project")
        return {}


def _project_by_key(key) -> dict:
    hit = _projects().get(str(key or ""))
    return dict(hit, key=str(key)) if isinstance(hit, dict) and hit.get("name") else dict(GENERIC_PROJECT, key="generic")


def _project_for_text(text) -> dict:
    """'Yes, send the demo for BRIJ Sandalwood' -> that project's settings, found in OUR list; anything else -> generic.
    The words after 'for' are only a key into our list; they are never sent back to anybody."""
    match = re.search(r"\bdemo\s+for\s+(.{1,80})$", str(text or ""), re.IGNORECASE | re.DOTALL)
    if not match:
        return dict(GENERIC_PROJECT, key="generic")
    return _project_by_key(re.sub(r"[^a-z0-9]", "", match.group(1).lower()))


def visit_slots(time_label=None, now=None) -> list:
    """Two sample visit times (IST): the first Saturday and the first Sunday at least two days ahead, in DATE order, at the hour that
    matches the answer to 'best time' (Morning 11 AM, Afternoon 3 PM, Evening 6 PM). Labels fit a 20-character button."""
    today = (now or datetime.now(IST)).date()
    hour = SLOT_HOUR.get(time_label, "11 AM")
    days = []
    for weekday in (5, 6):
        day = today + timedelta(days=2)
        while day.weekday() != weekday:
            day += timedelta(days=1)
        days.append(day)
    return ["%s, %s" % (day.strftime("%a %d %b"), hour) for day in sorted(days)]


def match_option(text, options):
    """The index of the option the lead meant (the tapped button's title, its words, a lone letter A-C, or a number that STARTS the
    label such as '3' for '3 BHK'), or None when it is unclear or ambiguous. A bare number never means 'the 3rd button'."""
    t = _norm(text)
    if not t or not options:
        return None
    normed = [_norm(o) for o in options]
    compact = _compact(text)
    exact = [i for i, o in enumerate(normed) if t == o or compact == o.replace(" ", "")]
    if len(exact) == 1:
        return exact[0]
    if len(t) == 1 and t in _LETTERS and _LETTERS.index(t) < len(options):
        return _LETTERS.index(t)
    by_number = [i for i, o in enumerate(normed) if t.isdigit() and o.split()[:1] == [t]]
    if len(by_number) == 1:
        return by_number[0]
    if len(t) >= 4 and not t.isdigit():
        loose = [i for i, o in enumerate(normed) if o and (t in o or o in t)]
        if len(loose) == 1 and not re.search(r"\b(not|no|dont|don't|never)\b", t):
            return loose[0]
    return None


def is_trigger(kind, text) -> bool:
    if kind in TEXT_KINDS:
        s = _apos(text)
        return bool(_TRIGGER_RE.search(s)) and not _NEGATED_TRIGGER_RE.search(s) and not _HARD_STOP_RE.search(s)
    return False


def _yes_no(text):
    """YES or NO only for a WHOLE message that is a yes/no word; 'ok thanks, will think about it' is neither."""
    t = _norm(text)
    if t in _YES_WORDS:
        return "yes"
    if t in _NO_WORDS:
        return "no"
    return None


def _is_hard_stop(typed) -> bool:
    s = _apos(typed)
    return bool(is_optout(s) or _HARD_STOP_RE.search(s))


def _only_noise(typed) -> bool:
    """Emoji, punctuation or nothing: not an answer and not worth a reply."""
    return not re.search(r"[A-Za-z0-9ऀ-ॿ઀-૿]", str(typed or ""))


# =====================================================================================================================
# sending (the only place that talks to the provider; tests replace _post)
# =====================================================================================================================
def _messages_url() -> str:
    return "%s/%s/%s/messages" % (Config.WHATSAPP_API_BASE_URL, Config.WHATSAPP_API_VERSION, Config.WHATSAPP_PHONE_ID)


def _credentials_ok() -> bool:
    return bool(Config.WHATSAPP_TOKEN and Config.WHATSAPP_PHONE_ID)


def _post(payload: dict) -> dict:
    if not _credentials_ok():
        raise RuntimeError("WhatsApp credentials not configured")
    resp = requests.post(_messages_url(), headers={"Authorization": "Bearer %s" % Config.WHATSAPP_TOKEN, "Content-Type": "application/json"},
                         json=payload, timeout=(3, 6))
    resp.raise_for_status()
    try:
        data = resp.json()
        return data if isinstance(data, dict) else {}
    except ValueError:
        return {}


def _wamid(response):
    messages = (response or {}).get("messages") or []
    return messages[0].get("id") if messages and isinstance(messages[0], dict) else None


def _send_text(to: str, body: str):
    return _wamid(_post({"messaging_product": "whatsapp", "to": to, "type": "text", "text": {"body": body[:4000]}}))


def _send_buttons(to: str, body: str, labels: list):
    """Tap-buttons (up to 3). If the provider refuses an interactive message, the same question goes out as lettered text
    (the answer matcher accepts 'A', 'B', 'C'), so the demo still works. Returns the wamid of what was sent (or None)."""
    labels = [_clip_title(label) for label in labels][:3]
    payload = {"messaging_product": "whatsapp", "to": to, "type": "interactive", "interactive": {
        "type": "button", "body": {"text": body[:1000]},
        "action": {"buttons": [{"type": "reply", "reply": {"id": "d%d" % (i + 1), "title": label}} for i, label in enumerate(labels)]}}}
    try:
        return _wamid(_post(payload))
    except requests.HTTPError as exc:
        status = getattr(exc.response, "status_code", 0)
        if 400 <= status < 500:
            logger.warning("interactive message refused (http %s); sending lettered text instead", status)
            lines = ["%s. %s" % (_LETTERS[i].upper(), label) for i, label in enumerate(labels)]
            return _send_text(to, "%s\n\n%s\n%s" % (body, TEXTS["lettered"], "\n".join(lines)))
        raise


# =====================================================================================================================
# flags, caps, state
# =====================================================================================================================
def get_mode(db) -> str:
    value, _ = agent_service.get_flag(db, MODE_FLAG)
    return value if value in MODES else "off"


def _test_numbers() -> set:
    return {n for n in (normalize_wa_number(p) for p in str(getattr(Config, "DEMO_TEST_NUMBERS", "") or "").split(",")) if n}


def _now_iso() -> str:
    return agent_service.now_iso()


def _since(hours: float) -> str:
    return agent_service.to_iso(agent_service.utc_now() - timedelta(hours=hours))


def _caps_ok(db, phone: str) -> bool:
    lead_sessions = DemoSession.source != "owner"
    per_phone = db.query(func.count(DemoSession.id)).filter(DemoSession.phone == phone, DemoSession.created_at >= _since(24), lead_sessions).scalar() or 0
    total = db.query(func.count(DemoSession.id)).filter(DemoSession.created_at >= _since(24), lead_sessions).scalar() or 0
    messages = db.query(func.coalesce(func.sum(DemoSession.msgs_sent), 0)).filter(DemoSession.updated_at >= _since(24), lead_sessions).scalar() or 0
    return per_phone < MAX_SESSIONS_PER_PHONE_PER_DAY and total < MAX_SESSIONS_PER_DAY and messages < MAX_MESSAGES_PER_DAY


def _active_session(db, phone: str):
    """The one open demo of this number. A lead's lives 23 h from its last activity, the owner's own test run only 30 minutes."""
    rows = (db.query(DemoSession).filter(DemoSession.phone == phone, DemoSession.status == "active")
            .order_by(DemoSession.id.desc()).all())
    for row in rows:
        window = _since(OWNER_SESSION_MINUTES / 60.0) if row.source == "owner" else _since(SESSION_HOURS)
        if row.updated_at >= window:
            return row
    return None


def _recent_finished_session(db, phone: str):
    return (db.query(DemoSession).filter(DemoSession.phone == phone, DemoSession.status.in_(("handed_off", "done")),
                                         DemoSession.source != "owner", DemoSession.updated_at >= _since(SESSION_HOURS))
            .order_by(DemoSession.id.desc()).first())


def _suppressed(db, phone: str) -> bool:
    return bool(agent_service.contact_suppression(db, phone=phone).get("suppressed"))


def _mark_seen(db, wamid) -> bool:
    """False = this inbound message was already handled (a webhook retry). Written first, so two workers racing on the same retry
    cannot both continue."""
    if not wamid:
        return False
    db.add(DemoSeen(wamid=str(wamid)[:200], ts=_now_iso()))
    try:
        db.commit()
        return True
    except IntegrityError:
        db.rollback()
        return False


def _answers(session) -> dict:
    try:
        data = json.loads(session.answers or "{}")
        return data if isinstance(data, dict) else {}
    except ValueError:
        return {}


def _public_answers(session) -> dict:
    return {k: v for k, v in _answers(session).items() if not k.startswith("_")}


def _cas(db, session, expect_step: str, **fields) -> bool:
    """Compare-and-set: change the session ONLY if it is still active and still at `expect_step`. False = another worker (or an earlier
    message of the same lead) already moved it; the caller must stop and send nothing."""
    fields["updated_at"] = _now_iso()
    changed = (db.query(DemoSession).filter(DemoSession.id == session.id, DemoSession.step == expect_step, DemoSession.status == "active")
               .update(fields, synchronize_session=False))
    db.commit()
    db.refresh(session)
    return changed == 1


def _touch(db, session, **fields) -> None:
    fields["updated_at"] = _now_iso()
    db.query(DemoSession).filter(DemoSession.id == session.id).update(fields, synchronize_session=False)
    db.commit()
    db.refresh(session)


def _bump(db, session, sent: int) -> None:
    if sent:
        db.query(DemoSession).filter(DemoSession.id == session.id).update(
            {"msgs_sent": DemoSession.msgs_sent + sent, "updated_at": _now_iso()}, synchronize_session=False)
        db.commit()
        db.refresh(session)


def _still_active(db, session) -> bool:
    db.refresh(session)
    return session.status == "active"


def _event(db, kind, summary, session=None, extra=None) -> None:
    payload = {"project": getattr(session, "project_name", None), "step": getattr(session, "step", None)}
    payload.update(extra or {})
    try:
        agent_service.add_event(db, "demo:%s" % _mask(getattr(session, "phone", "")), "whatsapp", "in", kind, summary, payload)
    except Exception:  # noqa: BLE001
        db.rollback()
        logger.exception("could not write a demo activity event")


def _alert_owner(db, text: str) -> None:
    """A short WhatsApp note to the owner when something needs a person. Works only inside the owner's own 24 h window; the hand-off row
    is written anyway, so the agent and the CRM to-do inbox still show it. Always called AFTER the lead's own messages."""
    try:
        from services import owner_channel
        owners = sorted(owner_channel.owner_numbers())
        if owners and agent_service.owner_last_seen(db).get("within_24h"):
            _send_text(owners[0], text)
    except Exception:  # noqa: BLE001
        logger.exception("owner alert failed")


def _reply_deadline(session) -> str:
    try:
        moment = agent_service.parse_iso(session.last_inbound_at or session.updated_at) + timedelta(hours=24)
        return moment.astimezone(IST).strftime("%H:%M")
    except Exception:  # noqa: BLE001
        return "within 24 hours"


def _suppress(db, phone: str) -> None:
    """Puts the number on the CRM's do-not-contact list (the same list the STOP handling uses)."""
    try:
        from services.outreach.suppression import add_suppression
        add_suppression(db, "WHATSAPP", phone, "STOP")
    except Exception:  # noqa: BLE001
        db.rollback()
        logger.exception("demo responder: could not suppress a number that said no")


def _handoff(db, session, reason: str, priority="high") -> None:
    """Hand-off row + CRM to-do first, then the owner's WhatsApp note (with the answers and the 24 h reply deadline). Never for owner runs."""
    answers = _public_answers(session)
    brief = "Demo answers so far: %s" % json.dumps(answers, ensure_ascii=False)
    try:
        agent_service.create_handoff(db, "demo:%s" % _mask(session.phone), "%s (demo)" % session.project_name, "+" + session.phone,
                                     reason, brief, priority)
    except Exception:  # noqa: BLE001
        db.rollback()
        logger.exception("could not write the demo hand-off")
    wants = " | ".join(str(answers[k]) for k in ("budget", "type", "time", "slot") if k in answers) or "no answers yet"
    _alert_owner(db, "DEMO lead - %s\n+%s %s.\nWants: %s\nReply on WhatsApp before %s IST (24 h rule): wa.me/%s"
                 % (session.project_name, session.phone, reason, wants, _reply_deadline(session), session.phone))


# =====================================================================================================================
# the conversation
# =====================================================================================================================
def _question(session):
    """(text, button labels) for the session's current step."""
    cfg = _project_by_key(session.project_key)
    step = session.step
    if step == "budget":
        return TEXTS["q_budget"], list(cfg["budget"])
    if step == "type":
        return TEXTS["q_type"], list(cfg["types"][:2]) + ["Not sure yet"]
    if step == "time":
        return TEXTS["q_time"], list(TIMES)
    if step == "slot":
        slots = _answers(session).get("_slots") or visit_slots(_answers(session).get("time"))      # frozen when first asked (a day change must not break the buttons)
        return TEXTS["q_slot"], list(slots) + ["Another time"]
    return TEXTS["q_cta"].format(project=cfg["name"]), list(CTA)


def _step_options(session):
    return _question(session)[1]


def _card_text(session) -> str:
    cfg = _project_by_key(session.project_key)
    a = _answers(session)
    slot = a.get("slot", "")
    other = slot.lower().startswith("another")
    return TEXTS["card"].format(project=cfg["name"], budget=a.get("budget", "-"), type=a.get("type", "-"), time=a.get("time", "-"),
                                slot="no time picked yet" if other else slot,
                                status="WARM (no visit time yet)" if other else "HOT (picked a visit time)")


def _send_question(db, session, prefix=None) -> int:
    """Sends the current question (optionally with a line in front of it) and remembers its wamid, so a tap on an OLD question is recognised."""
    text, labels = _question(session)
    body = "%s\n\n%s" % (prefix, text) if prefix else text
    wamid = _send_buttons(session.phone, body, labels)
    if wamid:
        _touch(db, session, last_q=wamid)
    return 1


def start_session(db, phone: str, project: dict, source: str):
    """Creates the demo and sends ONE message (intro + question 1). Returns the session, or None when caps / an open demo say no."""
    owner_run = source == "owner"
    now = _now_iso()
    # tidy: open demos past their own window are closed (else the one-open-demo index would block a new one), old seen-ids are
    # dropped (the table must not grow forever)
    for row in db.query(DemoSession).filter(DemoSession.phone == phone, DemoSession.status == "active").all():
        window = _since(OWNER_SESSION_MINUTES / 60.0) if row.source == "owner" else _since(SESSION_HOURS)
        if row.updated_at < window:
            row.status = "expired"
    db.query(DemoSeen).filter(DemoSeen.ts < _since(SEEN_KEEP_DAYS * 24)).delete(synchronize_session=False)
    db.commit()
    if not owner_run and not _caps_ok(db, phone):
        logger.info("demo responder: caps reached, not starting a demo for %s", _mask(phone))
        _cap_notice(db)
        return None
    session = DemoSession(phone=phone, project_key=project.get("key", "generic"), project_name=project["name"], step="budget",
                          answers="{}", status="active", unrecognised=0, msgs_sent=0, needs_resend=1, source=source,
                          created_at=now, updated_at=now, last_inbound_at=now)
    db.add(session)
    try:
        db.commit()
    except IntegrityError:                         # one open demo per number (partial unique index): a second trigger at the same instant
        db.rollback()
        logger.info("demo responder: a demo is already open for %s", _mask(phone))
        return None
    _event(db, "demo_started", "A lead started the demo (%s)" % source, session)
    try:
        intro_and_q1 = "%s\n\n%s" % (TEXTS["intro"].format(project=project["name"]), TEXTS["q_budget"])
        wamid = _send_buttons(phone, intro_and_q1, _step_options(session))
        _touch(db, session, needs_resend=0, last_q=wamid)
        _bump(db, session, 1)
    except Exception:  # noqa: BLE001 - provider trouble: needs_resend stays 1, so the lead's next message resends the first question
        logger.exception("demo responder: sending the first message failed")
    return session


def _cap_notice(db) -> None:
    """One note a day when a cap stops a demo, so a flood (or a very good day) is noticed instead of silently ignored."""
    from database.models import AgentActivity
    if db.query(AgentActivity.id).filter(AgentActivity.kind == "demo_cap_hit", AgentActivity.ts >= _since(24)).first():
        return
    try:
        agent_service.add_event(db, "demo", "whatsapp", "in", "demo_cap_hit", "A demo cap was reached: new demo requests get no answer today", None)
        _alert_owner(db, "DEMO cap reached today: new 'send the demo' requests are not answered. Reply to those leads yourself, or ask me to raise the cap.")
    except Exception:  # noqa: BLE001
        db.rollback()


def _close(db, session, status: str, text_key: str, event_kind: str, event_summary: str, suppress=False, handoff=None, priority="high") -> bool:
    """Ends the demo exactly once (compare-and-set), writes the hand-off BEFORE the lead-facing message, then sends ONE closing message.
    The owner's own test runs skip the hand-off, the suppression and the alerts and end with a plain 'test finished' note."""
    if not _cas(db, session, session.step, status=status):
        return False                                # someone else already moved or closed it
    owner_run = session.source == "owner"
    if handoff and not owner_run:
        _handoff(db, session, handoff, priority)
    if suppress and not owner_run:
        _suppress(db, session.phone)
    try:
        _send_text(session.phone, TEXTS[text_key])
        _bump(db, session, 1)
        if owner_run:
            _send_text(session.phone, TEXTS["owner_done"])
    except Exception:  # noqa: BLE001
        logger.exception("demo responder: closing message failed")
    _event(db, event_kind, event_summary, session, {"answers": _public_answers(session)})
    return True


def _advance(db, session, label: str) -> None:
    """A valid answer arrived for the current step: store it and send what comes next (compare-and-set: a double tap does it once)."""
    old_step = session.step
    answers = _answers(session)
    answers[old_step] = label
    next_step = _FLOW[_FLOW.index(old_step) + 1]
    if next_step == "slot":
        answers["_slots"] = visit_slots(answers.get("time"))
    if not _cas(db, session, old_step, answers=json.dumps(answers, ensure_ascii=False), step=next_step, unrecognised=0, needs_resend=1):
        return
    sent = 0
    try:
        if next_step == "cta":
            _send_text(session.phone, _card_text(session))
            sent += 1
        if _still_active(db, session):
            sent += _send_question(db, session)
            _touch(db, session, needs_resend=0)
    except Exception:  # noqa: BLE001 - needs_resend stays 1: the lead's next message resends the question
        logger.exception("demo responder: sending the next question failed")
    _bump(db, session, sent)


def _resend_current(db, session, prefix=None) -> None:
    answers = _answers(session)
    resends = answers.get("_resends", 0)
    if resends >= MAX_RESENDS and not session.needs_resend:
        return                                     # a repeated "send the demo" never becomes a flood
    answers["_resends"] = resends + 1
    _touch(db, session, answers=json.dumps(answers, ensure_ascii=False))
    try:
        _bump(db, session, _send_question(db, session, prefix))
        _touch(db, session, needs_resend=0)
    except Exception:  # noqa: BLE001
        logger.exception("demo responder: resend failed")
        _touch(db, session, needs_resend=1)


def _is_stale_tap(session, msg, kind, typed) -> bool:
    """A tap on an OLD question or a double tap on an answer already given: ignored silently (never counted as unclear)."""
    if kind not in ("button", "interactive"):
        return False
    context = (msg.get("context") or {}).get("id")
    if context and session.last_q and context != session.last_q:
        return True
    earlier = {_norm(v) for k, v in _public_answers(session).items() if k != session.step}
    return _norm(typed) in earlier and match_option(typed, _step_options(session)) is None


def _on_session_message(db, session, msg, kind: str, typed: str) -> None:
    """One more message from someone who is inside a demo. `typed` = what the person actually wrote or tapped (for photos, voice notes,
    documents and locations only the caption, never our placeholder text)."""
    typed = _apos(typed)[:MAX_TEXT]
    is_text = kind in TEXT_KINDS
    if _is_hard_stop(typed):                         # every kind of "no, stop": one message, and the number goes on the do-not-contact list
        _close(db, session, "stopped", "stop", "demo_stopped", "The lead stopped the demo", suppress=True)
        return
    if typed and is_autoreply(typed):
        return                                       # another business's auto-responder: never answer a robot (no loops)
    if is_text and _LATER_RE.search(typed):
        _close(db, session, "done", "later", "demo_later", "The lead said not now / later")
        return
    if is_text and _PERSON_RE.search(typed):
        _close(db, session, "handed_off", "person", "demo_person", "The lead asked for a person", handoff="asked to talk to a person during the demo")
        return
    if (session.msgs_sent or 0) >= MAX_MESSAGES_PER_SESSION:
        return                                       # per-demo message cap: silence
    if is_text and _only_noise(typed):
        return                                       # a thumbs-up or a stray emoji is not an answer
    if _is_stale_tap(session, msg, kind, typed):
        return
    if is_trigger(kind, typed) or session.needs_resend:
        _resend_current(db, session)
        return

    if is_text:
        if session.step == "cta":
            answer = _yes_no(typed)
            if answer is None:
                index = match_option(typed, CTA)
                answer = {0: "yes", 1: "no"}.get(index) if index is not None else None
            if answer == "yes":
                _close(db, session, "handed_off", "yes", "demo_yes", "The lead said yes, contact me", handoff="finished the demo and said YES, contact me")
                return
            if answer == "no":
                _close(db, session, "done", "no", "demo_no", "The lead declined at the end of the demo", suppress=True)
                return
        else:
            index = match_option(typed, _step_options(session))
            if index is not None:
                _advance(db, session, _step_options(session)[index])
                return
            if _PLAIN_NO_RE.search(typed):
                _close(db, session, "done", "later", "demo_later", "The lead said no during the demo")
                return
        if _ABOUT_RE.search(typed) and not _answers(session).get("_about"):
            answers = _answers(session)
            answers["_about"] = 1
            _touch(db, session, answers=json.dumps(answers, ensure_ascii=False))
            try:
                _bump(db, session, _send_question(db, session, prefix=TEXTS["about"]))
            except Exception:  # noqa: BLE001
                logger.exception("demo responder: about-reply failed")
            return

    # not one of the options
    unknown = (session.unrecognised or 0) + 1
    if unknown > MAX_UNRECOGNISED:
        _close(db, session, "done", "unknown_end", "demo_unclear", "Too many unclear answers: the demo ended")
        return
    _touch(db, session, unrecognised=unknown)
    try:
        _bump(db, session, _send_question(db, session, prefix=TEXTS["unknown"]))
    except Exception:  # noqa: BLE001
        logger.exception("demo responder: unknown-answer message failed")


# =====================================================================================================================
# entry points called from api/inbound.py
# =====================================================================================================================
def maybe_handle_lead_message(db, msg: dict, sender: str, kind: str, text: str, trusted: bool) -> None:
    """A lead's WhatsApp message, AFTER the normal inbound handling (so a STOP is already suppressed). Never raises."""
    try:
        _handle_lead_message(db, msg, sender, kind, text, trusted)
    except Exception:  # noqa: BLE001
        db.rollback()
        logger.exception("demo responder failed (ignored; the normal inbound flow is unaffected)")


def _typed_text(msg) -> tuple:
    """(kind, what the person really typed or tapped): placeholders like '[document: stop.pdf]' are NOT typed text."""
    kind, text, caption = describe_message(msg)
    return kind, (text if kind in TEXT_KINDS else (caption or ""))


def _handle_lead_message(db, msg, sender, kind, text, trusted) -> None:
    if not trusted:
        return
    mode = get_mode(db)
    if mode == "off" or agent_service.is_paused(db):
        return
    kind, typed = _typed_text(msg)
    if kind in ("reaction", "sticker"):
        return                                       # a thumbs-up or a sticker never starts, advances or counts as anything
    typed = _apos(typed)[:MAX_TEXT]
    phone = re.sub(r"\D", "", str(msg.get("from") or ""))         # answer exactly the number the provider reported
    if not phone:
        return
    session = _active_session(db, phone)
    trigger = is_trigger(kind, typed)
    finished = _recent_finished_session(db, phone) if session is None else None
    if session is None and not trigger and not (finished and _is_hard_stop(typed)):
        return                                       # only ever a reply: no demo has been asked for
    if mode == "test" and phone not in _test_numbers():
        return
    if not _credentials_ok():
        logger.warning("demo responder: WhatsApp credentials are not configured, nothing can be sent")
        return
    if not _mark_seen(db, msg.get("id")):
        return                                       # webhook retry
    if session is None and finished is not None and _is_hard_stop(typed):
        _stop_after_finish(db, finished, phone)      # "STOP" after the demo ended: ONE acknowledgement + the hand-off card is cancelled
        return
    if _suppressed(db, phone) and not (session and _is_hard_stop(typed)):
        return                                       # opted out earlier (or just now, with no demo running): silence
    if session is None:
        project = _project_for_text(typed)
        context_id = (msg.get("context") or {}).get("id")
        if project.get("key") == "generic" and context_id:
            project = _project_from_template_message(db, context_id) or project
        start_session(db, phone, project, "button" if kind in ("button", "interactive") else "text")
        return
    _touch(db, session, last_inbound_at=_now_iso())
    _on_session_message(db, session, msg, kind, typed)


def _stop_after_finish(db, finished, phone: str) -> None:
    """The lead said STOP after the demo had already ended (e.g. after 'Yes, contact me'): acknowledge once, cancel the open hand-off."""
    _suppress(db, phone)
    db.query(DemoSession).filter(DemoSession.id == finished.id).update({"status": "stopped", "updated_at": _now_iso()}, synchronize_session=False)
    db.query(AgentHandoff).filter(AgentHandoff.contact == "+" + phone, AgentHandoff.status == "open").update({"status": "cancelled"}, synchronize_session=False)
    db.commit()
    try:
        _send_text(phone, TEXTS["stop"])
    except Exception:  # noqa: BLE001
        logger.exception("demo responder: stop acknowledgement failed")
    _event(db, "demo_stopped", "The lead said STOP after the demo; the hand-off was cancelled", finished)


def _project_from_template_message(db, wamid):
    """The lead tapped a button on OUR template message: the agent logged that send (wamid + project) in agent_activity
    (agent/tools/wa.py), so the project is found without trusting anything the lead typed."""
    from database.models import AgentActivity
    token = re.sub(r"[^A-Za-z0-9._=-]", "", str(wamid))[:120]
    if not token:
        return None
    rows = (db.query(AgentActivity).filter(AgentActivity.kind == "template_sent", AgentActivity.payload_json.like('%"' + token + '"%'))
            .order_by(AgentActivity.id.desc()).limit(5).all())
    for row in rows:
        try:
            payload = json.loads(row.payload_json) or {}
        except ValueError:
            continue
        if payload.get("wamid") == token:                              # exact match (a LIKE wildcard can never pick a wrong row)
            key = re.sub(r"[^a-z0-9]", "", str(payload.get("project", "")).lower())
            hit = _projects().get(key)
            if isinstance(hit, dict) and hit.get("name"):
                return dict(hit, key=key)
    return None


# ---- the owner's own commands (DEMO ON / OFF / TEST / STATUS / RUN / STOP) and the owner testing the flow from his phone ------
_OWNER_RUN_RE = re.compile(r"^\s*demo\s+run(?:\s+(.{1,80}?))?\s*[.!]*\s*$", re.IGNORECASE)


def after_owner_message(db, msg: dict, outcome: str) -> None:
    """Called after the owner's message was stored and any command applied. Sends the owner a confirmation, starts or continues an
    owner-run demo. Never raises. Plain chat with the agent is NEVER consumed."""
    try:
        _owner_message(db, msg, outcome)
    except Exception:  # noqa: BLE001
        db.rollback()
        logger.exception("demo responder (owner path) failed (ignored)")


def _mark_owner_row_processed(db, wamid) -> None:
    """The demo consumed this owner message: the agent must not answer it as if it were a chat with the owner."""
    db.query(OwnerInbox).filter(OwnerInbox.wamid == wamid, OwnerInbox.processed_at.is_(None)).update({"processed_at": _now_iso()}, synchronize_session=False)
    db.commit()


def _tables_ok(db) -> bool:
    try:
        db.execute(sql_text("SELECT 1 FROM demo_sessions LIMIT 1"))
        db.execute(sql_text("SELECT 1 FROM demo_seen LIMIT 1"))
        return True
    except Exception:  # noqa: BLE001
        db.rollback()
        return False


def status_text(db) -> str:
    if not _tables_ok(db):
        return "Demo responder: the database tables are missing (run migrate.py). Nothing will be sent."
    sessions = db.query(func.count(DemoSession.id)).filter(DemoSession.created_at >= _since(24), DemoSession.source != "owner").scalar() or 0
    messages = db.query(func.coalesce(func.sum(DemoSession.msgs_sent), 0)).filter(DemoSession.updated_at >= _since(24)).scalar() or 0
    mode = get_mode(db)
    note = " PAUSED by STOP ALL: nothing is sent until RESUME." if agent_service.is_paused(db) else ""
    note += "" if _credentials_ok() else " WhatsApp credentials are missing: nothing can be sent."
    return "Demo responder: mode %s.%s Last 24 h: %d demos started by leads, %d messages sent." % (mode.upper(), note, sessions, messages)


def _owner_text_is_demo_answer(session, kind, typed) -> bool:
    """Owner TEXT counts as a demo answer only when it is plainly one (an option, a whole-message STOP/PERSON, yes/no at the end)."""
    if is_trigger(kind, typed):
        return True
    if _norm(typed) in ("stop", "person"):
        return True
    if session.step == "cta" and _yes_no(typed):
        return True
    return match_option(typed, _step_options(session)) is not None


def _owner_message(db, msg, outcome) -> None:
    if outcome == "duplicate":
        return
    wamid = msg.get("id")
    phone = re.sub(r"\D", "", str(msg.get("from") or ""))
    kind, typed = _typed_text(msg)
    typed = _apos(typed)[:MAX_TEXT]
    if outcome in ("demo-on", "demo-off", "demo-test", "demo-status"):
        _mark_owner_row_processed(db, wamid)
        _send_text(phone, "Demo responder is OFF. Nobody gets the automatic demo." if (outcome == "demo-off" and _tables_ok(db)) else status_text(db))
        return
    if outcome == "demo-stop":
        _mark_owner_row_processed(db, wamid)
        session = _active_session(db, phone)
        if session is not None and session.source == "owner":
            _touch(db, session, status="stopped")
        _send_text(phone, "Your test demo is ended.")
        return
    if outcome == "demo-run":
        _mark_owner_row_processed(db, wamid)
        match = _OWNER_RUN_RE.match(typed or "")
        project = _project_for_text("send the demo for " + (match.group(1) if match and match.group(1) else "Pride Aura"))
        session = _active_session(db, phone)
        if session is not None:
            _touch(db, session, status="stopped")
        if start_session(db, phone, project, "owner") is None:
            _send_text(phone, "Could not start the test demo. Try again in a minute.")
        return
    if outcome != "stored":
        return
    session = _active_session(db, phone)
    if session is None or session.source != "owner":
        # the owner taps "Yes, send the demo" on the template (or types "send the demo"): he sees what a lead sees
        if is_trigger(kind, typed):
            _mark_owner_row_processed(db, wamid)
            if _mark_seen(db, wamid):
                context_id = (msg.get("context") or {}).get("id")
                project = _project_for_text(typed)
                if project.get("key") == "generic" and context_id:
                    project = _project_from_template_message(db, context_id) or project
                start_session(db, phone, project, "owner")
        return
    consume = kind in ("button", "interactive") or (kind == "text" and _owner_text_is_demo_answer(session, kind, typed))
    if not consume:
        return                                        # ordinary chat with the agent: left alone, the agent reads it as always
    _mark_owner_row_processed(db, wamid)
    if _mark_seen(db, wamid):
        _touch(db, session, last_inbound_at=_now_iso())
        _on_session_message(db, session, msg, kind, typed)
